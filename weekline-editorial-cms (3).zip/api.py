#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from app import run_cgi

if __name__ == "__main__":
    run_cgi()
