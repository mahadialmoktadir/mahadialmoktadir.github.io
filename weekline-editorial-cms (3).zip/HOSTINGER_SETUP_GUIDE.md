# WEEKLINE | CSB NEWS USA LLC — Hostinger Deployment, Python 3 CMS & Backup Guide

## 1. Quick 1-Click Extraction in Hostinger (`public_html/`)
1. Log into **Hostinger hPanel** → **Websites** → **File Manager** → open `public_html/`.
2. Upload `weekline-editorial-cms.zip` directly into `public_html/`, right-click it → **Extract** → enter `.` (current folder).
3. Verify folder permissions:
   - `public_html/data/` → `755` (`store.json` and `weekline_cms.sqlite3` inside → `644` or `664`)
   - `public_html/uploads/` → `755`
   - `public_html/backups/` → `755`
   - `public_html/api.py`, `public_html/app.py`, `public_html/passenger_wsgi.py`, `public_html/backup_manager.py` → `755`

## 2. Python 3 CMS Engine + Universal PHP Bridge
This package includes a dual-engine Python 3 + PHP CMS backend so your website runs forever on any Hostinger plan:
- **Python 3 WSGI / Passenger (`app.py` & `passenger_wsgi.py`)**: For Hostinger Python App / Cloud / VPS. Syncs all edits to both `data/store.json` and relational SQLite3 (`data/weekline_cms.sqlite3`), and creates automatic rolling backups in `backups/`.
- **Python 3 CGI (`api.py`)**: Executable Python CGI script configured via `.htaccess` (`AddHandler cgi-script .py`).
- **Universal Bridge (`api.php`)**: Automatic zero-configuration bridge so even standard shared hosting works the second you extract the ZIP.
- **Automated & CLI Backups (`backup_manager.py`)**: Run `python3 backup_manager.py --create` via SSH or Cron Job anytime, or use the **🐍 Python CMS & Full Backup** tab inside the CMS Dashboard to download/restore full `.json` backups in 1 click.

## 3. CMS Login Credentials (`https://yourdomain.com/cms` or `#cms`)
- **Master Super Admin (Hidden)**:
  - Username: `SpecialCorrespondentMahadiAlMoktadir`
  - Password: `oiimialawwraaSpecialCorrespondentMahadiAlMoktadir@1517`
- **Operational ID #1 — Editorial Desk (50 Published Essays)**:
  - Username: `WEEKLINE_DESK`
  - Password: `WeeklineDesk@CSB2026#Editorial`
- **Operational ID #2 — Contributor (13 Published Essays — 1 per category)**:
  - Username: `MahadiAlMoktadir`
  - Password: `MahadiContributor@2026#`
- **Operational ID #3 — Editor 1**:
  - Username: `Editor1`
  - Password: `Editor1@Weekline2026#`
- **Operational ID #4 — Editor 2**:
  - Username: `Editor2`
  - Password: `Editor2@Weekline2026#`
- **Operational ID #5 — Chairman (CSB NEWS USA LLC Treasury & SEO)**:
  - Username: `ChairmanCSBNewsUSA`
  - Password: `Chairman@CSBNewsUSA2026#`
