// WEEKLINE Editorial & Hostinger CMS Application Logic — CSB NEWS USA LLC
(function() {
  var STORAGE_KEY = 'weekline_cms_state_v10';
  var uniqueWebpCache = {};
  var state = null;
  var hostingerApiAvailable = false;
  var activeApiEndpoint = 'api.py';
  var currentView = 'home'; // 'home' | 'article' | 'profile' | 'contributors' | 'cms'
  var activeCategory = 'ALL';
  var currentPage = 1;
  var profileCurrentPage = 1;
  var draggedSectionIndex = null;
  var tempCustomBlockImgUri = '';
  var tempMotionAdImgUri = '';
  var editingMultiCatArtId = null;
  var serverBackupsList = [
    { filename: 'weekline_master_backup_2026-10-30.json', sizeKB: 388.4, modifiedAt: '2026-10-30 09:45:00 UTC' },
    { filename: 'weekline_cms_backup_2026-10-30.sqlite3', sizeKB: 412.0, modifiedAt: '2026-10-30 09:45:00 UTC' },
    { filename: 'auto_backup_latest.json', sizeKB: 388.4, modifiedAt: 'Live Auto-Rolling Snapshot' }
  ];
  var searchQuery = '';
  var currentArticleId = null;
  var currentProfileUserId = null;
  var currentUser = null;
  var activeCmsTab = 'overview';
  var editingArticleId = null;
  var editingSubmissionId = null;
  var tempWriteAvatarUri = '';
  var tempWriteFeaturedUri = '';
  var tempCmsFeaturedUri = '';
  var tempNewUserAvatarUri = '';
  var tempProfileAvatarUri = '';

  // Support Us Modal State
  var activeSupportCategory = 'CARD';
  var supportInputAmount = 50;
  var supportInputCurrency = 'USD';
  var lastCompletedReceipt = null;

  // Email Verification Modal State
  var verifyingUserId = null;
  var activeVerificationCode = '';

  var CROP_WINDOWS = [
    [0.00, 0.00, 1.00, 1.00],
    [0.00, 0.04, 0.82, 0.86],
    [0.18, 0.04, 1.00, 0.86],
    [0.09, 0.10, 0.91, 0.92],
    [0.00, 0.14, 0.85, 0.99],
    [0.15, 0.00, 1.00, 0.85],
    [0.05, 0.02, 0.80, 0.77],
    [0.20, 0.16, 0.96, 0.92]
  ];
  var GRADE_FILTERS = [
    "contrast(1.06) saturate(1.04)",
    "contrast(1.09) saturate(0.95) sepia(0.08)",
    "contrast(1.12) saturate(0.92) hue-rotate(-6deg)",
    "contrast(1.08) saturate(0.88) sepia(0.15)",
    "contrast(1.15) saturate(1.08) brightness(0.99)",
    "contrast(1.07) saturate(1.02) brightness(1.03)"
  ];

  function getPhotoLib() {
    return window.WEEKLINE_PHOTOS || window.WEEKLINE_PHOTO_LIB || {};
  }

  function resolvePhoto(ref) {
    var lib = getPhotoLib();
    var fallbackIcon = lib.weekline_icon || lib.csb_logo || 'assets/weekline_icon.webp';
    if (!ref) return fallbackIcon;
    if (ref.indexOf('@artwebp:') === 0) {
      var parts = ref.split(':');
      var artId = parts[1];
      var baseKey = parts[2];
      if (lib[artId]) return lib[artId];
      if (uniqueWebpCache[artId]) return uniqueWebpCache[artId];
      return lib[baseKey] || lib.p_maritime || fallbackIcon;
    }
    if (ref.indexOf('@photo:') === 0) {
      var key = ref.slice(7);
      if (key === 'logo') return lib.csb_logo || lib.logo || fallbackIcon;
      return lib[key] || lib.p_maritime || fallbackIcon;
    }
    return ref;
  }

  function getArticleCategories(art) {
    if (!art) return ['Weekline Exclusive'];
    if (Array.isArray(art.categories) && art.categories.length > 0) {
      return art.categories;
    }
    if (art.category) return [art.category];
    return ['Weekline Exclusive'];
  }

  function articleHasCategory(art, catName) {
    if (!art || !catName) return false;
    if (catName === 'ALL') return true;
    var cats = getArticleCategories(art);
    return cats.indexOf(catName) !== -1 || art.category === catName;
  }

  function renderArticleCategoriesBadgesHtml(art) {
    var cats = getArticleCategories(art);
    return '<div class="multi-cat-row">' + cats.map(function(c) {
      var safeJsCat = String(c).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      return '<button type="button" class="cat-badge-bold" onclick="event.stopPropagation();filterByCategory(\'' + safeJsCat + '\')" title="Explore ' + escapeHtml(c) + '"><strong>' + escapeHtml(c) + '</strong></button>';
    }).join('') + '</div>';
  }

  function syncCategoryNavBarDom() {
    if (!state || !Array.isArray(state.categories)) return;
    var grid = document.getElementById('mainCategoryGrid3x3');
    if (!grid) return;
    var nonExcl = state.categories.filter(function(c) { return c !== 'Weekline Exclusive'; });
    grid.innerHTML = nonExcl.map(function(c) {
      var safeJsCat = String(c).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      var activeCls = (currentView === 'home' && activeCategory === c) ? 'category-cell active-cat' : 'category-cell';
      return '<button type="button" class="' + activeCls + '" data-cat-btn="' + escapeHtml(c) + '" onclick="filterByCategory(\'' + safeJsCat + '\')">' + escapeHtml(c) + '</button>';
    }).join('');
  }

  function initUniqueArticleWebpEngine() {
    if (!state || !state.articles) return;
    var lib = getPhotoLib();
    var byBase = {};
    for (var i = 0; i < state.articles.length; i++) {
      var fi = state.articles[i].featuredImage || "";
      if (fi.indexOf("@artwebp:") === 0) {
        var pts = fi.split(":");
        var bKey = pts[2];
        if (!byBase[bKey]) byBase[bKey] = [];
        byBase[bKey].push({ artId: pts[1], cropIdx: parseInt(pts[3], 10) || 0, gradeIdx: parseInt(pts[4], 10) || 0 });
      }
    }
    Object.keys(byBase).forEach(function(bKey) {
      var srcUri = lib[bKey] || lib.p_maritime;
      if (!srcUri) return;
      var img = new Image();
      img.onload = function() {
        var list = byBase[bKey];
        var c = document.createElement("canvas");
        c.width = 720;
        c.height = 480;
        var ctx = c.getContext("2d");
        for (var j = 0; j < list.length; j++) {
          var item = list[j];
          var cw = CROP_WINDOWS[item.cropIdx % CROP_WINDOWS.length];
          var sx = Math.floor(img.width * cw[0]);
          var sy = Math.floor(img.height * cw[1]);
          var sw = Math.max(40, Math.floor(img.width * (cw[2] - cw[0])));
          var sh = Math.max(40, Math.floor(img.height * (cw[3] - cw[1])));
          ctx.save();
          ctx.clearRect(0, 0, 720, 480);
          ctx.filter = GRADE_FILTERS[item.gradeIdx % GRADE_FILTERS.length];
          ctx.drawImage(img, sx, sy, sw, sh, 0, 0, 720, 480);
          ctx.filter = "none";
          ctx.strokeStyle = "rgba(6, 13, 58, 0.12)";
          ctx.lineWidth = 2;
          ctx.strokeRect(1, 1, 718, 478);
          ctx.restore();
          var webpOut = c.toDataURL("image/webp", 0.86);
          uniqueWebpCache[item.artId] = webpOut;
          var domImgs = document.querySelectorAll('[data-art-img="' + item.artId + '"]');
          for (var k = 0; k < domImgs.length; k++) {
            domImgs[k].src = webpOut;
          }
        }
      };
      img.src = srcUri;
    });
  }

  function loadState() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        var parsed = JSON.parse(raw);
        if (parsed && parsed.articles && parsed.articles.length >= 60 && parsed.categories && parsed.categories.indexOf('History, Religion & Culture') !== -1 && parsed.users && parsed.paymentConfig && parsed.siteConfig && parsed.adsConfig) {
          state = parsed;
        }
      }
    } catch (e) {}
    if (!state) {
      state = JSON.parse(JSON.stringify(window.WEEKLINE_INITIAL_DB));
      saveStateLocal();
    }
    normalizeStateArticlesCategories();
    if (window.location.protocol.indexOf('http') === 0) {
      callBackendApi('load&_t=' + Date.now(), 'GET', null, function(serverData) {
        if (serverData && serverData.articles && serverData.users) {
          hostingerApiAvailable = true;
          if (!serverData.siteConfig && window.WEEKLINE_INITIAL_DB) serverData.siteConfig = JSON.parse(JSON.stringify(window.WEEKLINE_INITIAL_DB.siteConfig));
          if (!serverData.adsConfig && window.WEEKLINE_INITIAL_DB) serverData.adsConfig = JSON.parse(JSON.stringify(window.WEEKLINE_INITIAL_DB.adsConfig));
          state = serverData;
          normalizeStateArticlesCategories();
          saveStateLocal();
          applySiteConfigToDom();
          syncCategoryNavBarDom();
          renderMainView();
        }
      });
    }
  }

  function normalizeStateArticlesCategories() {
    if (!state || !state.articles) return;
    for (var i = 0; i < state.articles.length; i++) {
      var a = state.articles[i];
      if (a.category === 'History' || a.category === 'Religion & Culture') {
        a.category = 'History, Religion & Culture';
      }
      if (!Array.isArray(a.categories) || a.categories.length === 0) {
        a.categories = [a.category || 'Weekline Exclusive'];
      } else {
        a.categories = a.categories.map(function(c) {
          return (c === 'History' || c === 'Religion & Culture') ? 'History, Religion & Culture' : c;
        });
      }
      a.category = a.categories[0];
    }
  }

  function callBackendApi(actionQuery, method, bodyObj, onSuccess) {
    if (window.location.protocol.indexOf('http') !== 0) return;
    var pyUrl = ['api', '.py?action='].join('') + actionQuery;
    var phpUrl = ['api', '.php?action='].join('') + actionQuery;
    var opts = { method: method || 'GET', cache: 'no-store' };
    if (bodyObj) {
      opts.headers = { 'Content-Type': 'application/json' };
      opts.body = JSON.stringify(bodyObj);
    }
    fetch(pyUrl, opts)
      .then(function(r) {
        if (r.ok) {
          activeApiEndpoint = 'api.py (Python 3 CMS)';
          return r.json();
        }
        throw new Error('Fallback to PHP bridge');
      })
      .then(function(data) {
        if (onSuccess && data) onSuccess(data);
      })
      .catch(function() {
        fetch(phpUrl, opts)
          .then(function(r2) { return r2.ok ? r2.json() : null; })
          .then(function(data2) {
            if (onSuccess && data2) onSuccess(data2);
          })
          .catch(function() {});
      });
  }

  function saveStateLocal() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {}
  }

  function saveState() {
    normalizeStateArticlesCategories();
    saveStateLocal();
    callBackendApi('save', 'POST', state);
  }

  window.showToast = function(msg) {
    var box = document.getElementById('toastContainer');
    if (!box) return;
    var el = document.createElement('div');
    el.className = 'toast-item';
    el.textContent = msg;
    box.appendChild(el);
    setTimeout(function() {
      if (el.parentNode) el.parentNode.removeChild(el);
    }, 4500);
  };

  function isLoggedSuperAdmin() {
    return !!(currentUser && (currentUser.isHiddenSuper || currentUser.username === 'SpecialCorrespondentMahadiAlMoktadir'));
  }

  function canViewArticleAnalytics() {
    return !!(currentUser && (isLoggedSuperAdmin() || currentUser.role === 'Administrator'));
  }

  function isLoggedChairmanOrSuper() {
    return !!(currentUser && (isLoggedSuperAdmin() || currentUser.role === 'Chairman'));
  }

  function canManageEditorial() {
    if (!currentUser) return false;
    return isLoggedSuperAdmin() || currentUser.role === 'Chairman' || currentUser.role === 'Editorial Desk' || currentUser.role === 'Administrator' || currentUser.role === 'Editor';
  }

  function canEditOrDeleteArticle(art) {
    if (!currentUser || !art) return false;
    if (isLoggedSuperAdmin()) return true;
    if (art.authorId === currentUser.id) return true;
    var artAuthor = getUserById(art.authorId);
    if (artAuthor && (!artAuthor.canLogin || artAuthor.status === 'pending_approval') && canManageEditorial()) {
      return true;
    }
    return false;
  }

  function getVisibleUsersForCurrentContext() {
    if (!state || !state.users) return [];
    return state.users.filter(function(u) {
      if (u.isHiddenSuper && !isLoggedSuperAdmin()) return false;
      return true;
    });
  }

  function getPublicContributorsList() {
    if (!state || !state.users) return [];
    return state.users.filter(function(u) {
      if (u.isHiddenSuper) return false;
      if (u.role === 'Chairman') return false;
      if (u.status === 'pending_approval') return false;
      return true;
    });
  }

  function getUserById(uid) {
    if (!uid || !state || !state.users) return null;
    for (var i = 0; i < state.users.length; i++) {
      if (state.users[i].id === uid) return state.users[i];
    }
    for (var j = 0; j < state.users.length; j++) {
      if (state.users[j].id === 'u_weekline_desk') return state.users[j];
    }
    return state.users[0];
  }

  function getPlatformIconSvg(key) {
    var icons = {
      truthSocial: '<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M4 5h16v3.5h-6.2V19h-3.6V8.5H4V5zm13.5 10.5h3V19h-3v-3.5z"/></svg>',
      instagram: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4.5"/><circle cx="17.5" cy="6.5" r="1.2" fill="currentColor"/></svg>',
      x: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
      facebook: '<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M14 13.5h2.5l1-4H14v-2c0-1.03 0-2 2-2h1.5V2.14c-.326-.043-1.557-.14-2.857-.14C11.928 2 10 3.657 10 6.7v2.8H7v4h3V22h4v-8.5z"/></svg>',
      tumblr: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M14.563 24c-5.093 0-7.031-3.756-7.031-6.411V9.747H5.116V6.648c3.63-1.313 4.512-4.596 4.71-6.469C9.84.051 9.941 0 9.999 0h3.517v6.114h4.801v3.633h-4.82v7.47c.016 1.001.375 2.371 2.207 2.371h.09c.631-.02 1.486-.205 1.936-.419l1.156 3.425c-.436.636-2.4 1.374-4.156 1.404h-.168z"/></svg>',
      threads: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10c4.2 0 7.7-2.4 9.2-5.9M15.5 10.5c0-2.2-1.6-3.5-3.8-3.5-2.3 0-4 1.6-4 4s1.7 4 4 4c2.1 0 3.8-1.3 3.8-3.5v-1c0 2.8 1.5 4.5 3.3 4.5 1.7 0 2.7-1.5 2.7-4C21.5 6.5 17.5 3 12 3"/></svg>',
      youtube: '<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>'
    };
    return icons[key] || '';
  }

  var PLATFORM_META = [
    { key: 'truthSocial', label: 'Truth Social' },
    { key: 'instagram', label: 'Instagram' },
    { key: 'x', label: 'X' },
    { key: 'facebook', label: 'Facebook' },
    { key: 'tumblr', label: 'Tumblr' },
    { key: 'threads', label: 'Threads' },
    { key: 'youtube', label: 'YouTube' }
  ];

  window.shareArticleOnPlatform = function(platformKey, articleId) {
    var art = null;
    for (var i = 0; i < state.articles.length; i++) {
      if (state.articles[i].id === articleId) { art = state.articles[i]; break; }
    }
    if (!art) return;
    var shareUrl = (state.seoConfig.canonicalUrl || 'https://weekline-editorial-demo.vastnewt128.chatgpt.site/') + '#article=' + encodeURIComponent(art.id);
    var shareText = art.title + ' (' + art.category + ')';
    var encUrl = encodeURIComponent(shareUrl);
    var encText = encodeURIComponent(shareText);
    var targetUrl = '';

    if (platformKey === 'truthSocial') {
      targetUrl = 'https://truthsocial.com/share?text=' + encText + '&url=' + encUrl;
    } else if (platformKey === 'x') {
      targetUrl = 'https://twitter.com/intent/tweet?text=' + encText + '&url=' + encUrl;
    } else if (platformKey === 'facebook') {
      targetUrl = 'https://www.facebook.com/sharer/sharer.php?u=' + encUrl;
    } else if (platformKey === 'tumblr') {
      targetUrl = 'https://www.tumblr.com/widgets/share/tool?canonicalUrl=' + encUrl + '&title=' + encodeURIComponent(art.title) + '&caption=' + encodeURIComponent(art.subtitle);
    } else if (platformKey === 'threads') {
      targetUrl = 'https://www.threads.net/intent/post?text=' + encodeURIComponent(shareText + ' ' + shareUrl);
    } else if (platformKey === 'instagram') {
      copyTextFallback(shareText + ' ' + shareUrl);
      showToast('Article link & headline copied for your Instagram Story/Post! Opening Instagram...');
      targetUrl = 'https://www.instagram.com/';
    } else if (platformKey === 'youtube') {
      copyTextFallback(shareText + ' ' + shareUrl);
      showToast('Article link & headline copied for your YouTube Post! Opening YouTube...');
      targetUrl = 'https://www.youtube.com/';
    }

    if (targetUrl) {
      window.open(targetUrl, '_blank', 'noopener,noreferrer');
    }
  };

  window.copyTextToClipboard = function(txt, label) {
    copyTextFallback(txt);
    showToast('Copied ' + (label || 'details') + ' to clipboard!');
  };

  function copyTextFallback(txt) {
    try {
      var ta = document.createElement('textarea');
      ta.value = txt;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    } catch (e) {}
  }

  function renderAuthorChip(user, readTimeStr, dateStr) {
    if (!user) return '';
    var metaLine = escapeHtml(user.bio);
    if (dateStr) metaLine += ' &nbsp;·&nbsp; <strong>' + escapeHtml(dateStr) + '</strong>';
    if (readTimeStr) metaLine += ' &nbsp;|&nbsp; ' + escapeHtml(readTimeStr);
    return '<button type="button" class="author-chip" onclick="openContributorProfile(\'' + user.id + '\')">' +
      '<img src="' + resolvePhoto(user.avatar) + '" alt="' + escapeHtml(user.name) + '" class="author-avatar-lg"/>' +
      '<span class="author-meta-text">' +
        '<span class="author-name-bold">' + escapeHtml(user.name) + '</span>' +
        '<span class="author-bio-regular">' + metaLine + '</span>' +
      '</span>' +
    '</button>';
  }

  function escapeHtml(s) {
    if (s === null || s === undefined) return '';
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // Navigation Handlers & Multi-Page URL Router
  function updateUrlHashQuietly(hashStr) {
    try {
      if (window.history && window.history.replaceState) {
        window.history.replaceState(null, '', hashStr);
      }
    } catch (e) {}
  }

  window.goHome = function(catFilter) {
    currentView = 'home';
    activeCategory = catFilter || 'ALL';
    currentPage = 1;
    searchQuery = '';
    var inp = document.getElementById('liveSearchInput');
    if (inp) inp.value = '';
    updateUrlHashQuietly(activeCategory === 'ALL' ? '#page/1' : ('#category/' + encodeURIComponent(activeCategory) + '/page/1'));
    renderMainView();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  window.filterByCategory = function(catName) {
    currentView = 'home';
    activeCategory = catName;
    currentPage = 1;
    updateUrlHashQuietly('#category/' + encodeURIComponent(catName) + '/page/1');
    renderMainView();
    var el = document.getElementById('journalSectionAnchor');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  window.goToPage = function(pageNum) {
    currentPage = Math.max(1, parseInt(pageNum, 10) || 1);
    updateUrlHashQuietly(activeCategory === 'ALL' ? ('#page/' + currentPage) : ('#category/' + encodeURIComponent(activeCategory) + '/page/' + currentPage));
    renderMainView();
    var el = document.getElementById('journalSectionAnchor');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
    else window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  window.goToProfilePage = function(pageNum) {
    profileCurrentPage = Math.max(1, parseInt(pageNum, 10) || 1);
    updateUrlHashQuietly('#author/' + encodeURIComponent(currentProfileUserId || 'u_weekline_desk') + '/page/' + profileCurrentPage);
    renderMainView();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  window.changeArticlesPerPage = function(val) {
    var num = parseInt(val, 10) || 12;
    if (!state.siteConfig) state.siteConfig = {};
    state.siteConfig.articlesPerPage = num;
    currentPage = 1;
    profileCurrentPage = 1;
    saveStateLocal();
    renderMainView();
  };

  window.toggleSearchBar = function() {
    var sb = document.getElementById('liveSearchBarWrap');
    if (!sb) return;
    var isHidden = sb.style.display === 'none' || !sb.style.display;
    sb.style.display = isHidden ? 'block' : 'none';
    if (isHidden) {
      var inp = document.getElementById('liveSearchInput');
      if (inp) inp.focus();
    }
  };

  window.handleSearchInput = function(val) {
    searchQuery = (val || '').trim().toLowerCase();
    if (currentView !== 'home') currentView = 'home';
    renderMainView();
  };

  window.openArticle = function(artId) {
    if (state && state.articles) {
      for (var i = 0; i < state.articles.length; i++) {
        if (state.articles[i].id === artId) {
          state.articles[i].views = (Number(state.articles[i].views) || 0) + 1;
          break;
        }
      }
      saveStateLocal();
      if (window.location.protocol.indexOf('http') === 0) {
        try {
          var apiUrl = ['api', '.php?action='].join('');
          fetch(apiUrl + 'increment_view', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ articleId: artId })
          }).catch(function() {});
        } catch (e) {}
      }
    }
    currentArticleId = artId;
    currentView = 'article';
    updateUrlHashQuietly('#article/' + encodeURIComponent(artId));
    renderMainView();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  window.openContributorProfile = function(userId) {
    var targetU = getUserById(userId);
    if (targetU && targetU.isHiddenSuper && !isLoggedSuperAdmin()) {
      targetU = getUserById('u_mahadi_contributor') || state.users[2];
    }
    currentProfileUserId = targetU ? targetU.id : 'u_weekline_desk';
    profileCurrentPage = 1;
    currentView = 'profile';
    updateUrlHashQuietly('#author/' + encodeURIComponent(currentProfileUserId) + '/page/1');
    renderMainView();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  window.openAllContributors = function() {
    currentView = 'contributors';
    updateUrlHashQuietly('#contributors');
    renderMainView();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  window.openCmsDashboard = function() {
    currentView = 'cms';
    updateUrlHashQuietly('#cms');
    renderMainView();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // ============================================================================
  // WRITE FOR US MODAL & AUTO-CREATED PENDING CONTRIBUTOR PROFILE
  // ============================================================================
  window.openWriteForUsModal = function() {
    tempWriteAvatarUri = '';
    tempWriteFeaturedUri = '';
    var m = document.getElementById('writeForUsModal');
    if (m) m.classList.add('open');
  };

  window.closeWriteForUsModal = function() {
    var m = document.getElementById('writeForUsModal');
    if (m) m.classList.remove('open');
  };

  window.handleWriteProfilePicUpload = function(inputEl) {
    var statusEl = document.getElementById('writeAvatarStatus');
    if (!inputEl || !inputEl.files || !inputEl.files[0]) return;
    var file = inputEl.files[0];
    var sizeKB = Math.round(file.size / 1024);
    if (file.size > 300 * 1024) {
      inputEl.value = '';
      tempWriteAvatarUri = '';
      if (statusEl) {
        statusEl.style.color = '#c23425';
        statusEl.textContent = 'Error: Profile pic is ' + sizeKB + ' KB. Must be less than 300 KB (any file).';
      }
      showToast('Profile picture exceeds 300 KB limit (' + sizeKB + ' KB).');
      return;
    }
    var reader = new FileReader();
    reader.onload = function(evt) {
      tempWriteAvatarUri = evt.target.result;
      if (statusEl) {
        statusEl.style.color = '#1b6e38';
        statusEl.textContent = 'Verified: ' + file.name + ' (' + sizeKB + ' KB < 300 KB limit)';
      }
      var prev = document.getElementById('writeAvatarPreviewImg');
      if (prev) {
        prev.src = tempWriteAvatarUri;
        prev.style.display = 'inline-block';
      }
    };
    reader.readAsDataURL(file);
  };

  window.handleWriteFeaturedUpload = function(inputEl, targetMode) {
    var isCms = (targetMode === 'cms');
    var statusEl = document.getElementById(isCms ? 'cmsFeaturedStatus' : 'writeFeaturedStatus');
    if (!inputEl || !inputEl.files || !inputEl.files[0]) return;
    var file = inputEl.files[0];
    var sizeKB = Math.round(file.size / 1024);
    var isWebp = (file.type === 'image/webp') || /\.webp$/i.test(file.name);

    if (file.size > 1024 * 1024) {
      inputEl.value = '';
      if (statusEl) {
        statusEl.style.color = '#c23425';
        statusEl.textContent = 'Error: Featured photo is ' + sizeKB + ' KB. Must be less than 1 MB (.webp featured).';
      }
      showToast('Featured photo exceeds 1 MB limit (' + sizeKB + ' KB).');
      return;
    }

    var reader = new FileReader();
    reader.onload = function(evt) {
      if (isWebp) {
        if (isCms) tempCmsFeaturedUri = evt.target.result;
        else tempWriteFeaturedUri = evt.target.result;
        if (statusEl) {
          statusEl.style.color = '#1b6e38';
          statusEl.textContent = 'Verified WebP: ' + file.name + ' (' + sizeKB + ' KB < 1 MB limit)';
        }
      } else {
        var img = new Image();
        img.onload = function() {
          var c = document.createElement('canvas');
          var maxW = 900;
          var scale = img.width > maxW ? (maxW / img.width) : 1;
          c.width = Math.round(img.width * scale);
          c.height = Math.round(img.height * scale);
          var ctx = c.getContext('2d');
          ctx.drawImage(img, 0, 0, c.width, c.height);
          var webpData = c.toDataURL('image/webp', 0.82);
          var convKB = Math.round((webpData.length * 3 / 4) / 1024);
          if (isCms) tempCmsFeaturedUri = webpData;
          else tempWriteFeaturedUri = webpData;
          if (statusEl) {
            statusEl.style.color = '#1b6e38';
            statusEl.textContent = 'Auto-converted to .webp (' + convKB + ' KB < 1 MB limit)';
          }
        };
        img.src = evt.target.result;
      }
    };
    reader.readAsDataURL(file);
  };

  window.submitWriteForUsArticle = function() {
    var name = (document.getElementById('wfuName').value || '').trim();
    var email = (document.getElementById('wfuEmail').value || '').trim();
    var bio = (document.getElementById('wfuBio').value || '').trim();
    var headline = (document.getElementById('wfuHeadline').value || '').trim();
    var subtitle = (document.getElementById('wfuSubtitle').value || '').trim();
    var category = document.getElementById('wfuCategory').value;
    var wfuChecks = document.querySelectorAll('input[name="wfuMultiCat"]:checked');
    var selectedCategories = [category];
    for (var ci = 0; ci < wfuChecks.length; ci++) {
      var cVal = wfuChecks[ci].value;
      if (cVal && selectedCategories.indexOf(cVal) === -1) selectedCategories.push(cVal);
    }
    var bodyRaw = (document.getElementById('wfuBody').value || '').trim();
    var customHtmlEl = document.getElementById('wfuCustomHtml');
    var customHtmlVal = customHtmlEl ? (customHtmlEl.value || '').trim() : '';

    if (!name || !bio || !headline || !bodyRaw) {
      showToast('Please fill in your Contributor Name, Short Biography, Essay Headline, and Body.');
      return;
    }

    var formattedBody = bodyRaw.indexOf('<p') !== -1 ? bodyRaw : ('<p class="lead-para">' + bodyRaw.split(/\n\n+/).join('</p><p>') + '</p>');
    var defaultAvatar = tempWriteAvatarUri || '@photo:weekline_icon';
    var defaultFeatured = tempWriteFeaturedUri || '@photo:p_maritime';

    // Automatically create a Pending Contributor Profile (Waiting for Approval) if not existing
    var existingUser = state.users.find(function(u) {
      return u.name.toLowerCase() === name.toLowerCase() && !u.isHiddenSuper;
    });
    var pendingUserId = '';
    if (existingUser) {
      pendingUserId = existingUser.id;
    } else {
      pendingUserId = 'u_pending_' + Date.now();
      state.users.push({
        id: pendingUserId,
        username: name.toLowerCase().replace(/[^a-z0-9]/g, '_') + '_pending',
        password: '',
        name: name,
        role: 'Public Contributor (Waiting for Approval)',
        accessLevel: 'Temporary Auto-Created Profile (No CMS Login Access)',
        canLogin: false,
        isHiddenSuper: false,
        email: email || 'contributor@csbnewsusallc.news',
        emailVerified: false,
        status: 'pending_approval',
        bio: bio,
        avatar: defaultAvatar
      });
    }

    var newSub = {
      id: 'sub_' + Date.now(),
      contributorUserId: pendingUserId,
      contributorName: name,
      contributorEmail: email || 'contributor@csbnewsusallc.news',
      contributorBio: bio,
      contributorAvatar: defaultAvatar,
      headline: headline,
      subtitle: subtitle || 'A contributor essay submitted for the Sunday edition.',
      category: selectedCategories[0],
      categories: selectedCategories,
      featuredImage: defaultFeatured,
      submittedAt: '2026-10-25 · Waiting for Approval',
      emailedTo: 'editorial@csbnewsusallc.news',
      status: 'pending',
      customHtml: customHtmlVal,
      body: formattedBody
    };

    state.submissions.unshift(newSub);
    saveState();

    if (window.location.protocol.indexOf('http') === 0) {
      try {
        var apiUrl = ['api', '.php?action='].join('');
        fetch(apiUrl + 'send_editorial_mail', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newSub)
        }).catch(function() {});
      } catch (e) {}
    }

    var editorialDest = state.seoConfig.editorialEmail || 'editorial@csbnewsusallc.news';
    closeWriteForUsModal();
    showToast('Essay sent to ' + editorialDest + ' & Pending Contributor Profile created in CMS Dashboard (Waiting for Approval)!');
    renderMainView();
  };

  // ============================================================================
  // SUPPORT US — WORLDWIDE CURRENCY-TO-USD CONVERTER + US BUSINESS CORPORATE CARD,
  // US BANK, BD BANK & INTERNATIONAL WIRE
  // ============================================================================
  window.openSupportModal = function() {
    lastCompletedReceipt = null;
    var m = document.getElementById('supportModal');
    if (m) m.classList.add('open');
    renderSupportModalBody();
  };

  window.closeSupportModal = function() {
    var m = document.getElementById('supportModal');
    if (m) m.classList.remove('open');
  };

  window.selectSupportPaymentCategory = function(catKey) {
    activeSupportCategory = catKey;
    lastCompletedReceipt = null;
    renderSupportModalBody();
  };

  window.handleSupportCurrencyChange = function() {
    var amtEl = document.getElementById('supAmountInput');
    var curEl = document.getElementById('supCurrencySelect');
    if (amtEl) supportInputAmount = Math.max(1, parseFloat(amtEl.value) || 0);
    if (curEl) supportInputCurrency = curEl.value;
    var eqEl = document.getElementById('supUsdEquivalentReadout');
    if (eqEl) {
      eqEl.textContent = '$' + computeUsdEquivalent(supportInputAmount, supportInputCurrency).toFixed(2) + ' USD';
    }
  };

  window.setPresetUsdSupport = function(usdVal) {
    supportInputCurrency = 'USD';
    supportInputAmount = usdVal;
    renderSupportModalBody();
  };

  function computeUsdEquivalent(amount, currency) {
    var rates = (state && state.paymentConfig && state.paymentConfig.exchangeRatesToUSD) ? state.paymentConfig.exchangeRatesToUSD : { USD: 1.0 };
    var rate = rates[currency] || 1.0;
    return amount * rate;
  }

  function renderSupportModalBody() {
    var container = document.getElementById('supportModalDynamicBody');
    if (!container) return;

    var usdEq = computeUsdEquivalent(supportInputAmount, supportInputCurrency);
    var rates = (state && state.paymentConfig && state.paymentConfig.exchangeRatesToUSD) ? state.paymentConfig.exchangeRatesToUSD : { USD: 1.0 };
    var currencyList = [
      { code: 'USD', label: 'USD ($) — United States Dollar' },
      { code: 'BDT', label: 'BDT (৳) — Bangladesh Taka' },
      { code: 'EUR', label: 'EUR (€) — Eurozone Euro' },
      { code: 'GBP', label: 'GBP (£) — British Pound Sterling' },
      { code: 'CAD', label: 'CAD (C$) — Canadian Dollar' },
      { code: 'AUD', label: 'AUD (A$) — Australian Dollar' },
      { code: 'AED', label: 'AED (د.إ) — UAE Dirham' },
      { code: 'SAR', label: 'SAR (﷼) — Saudi Riyal' },
      { code: 'INR', label: 'INR (₹) — Indian Rupee' },
      { code: 'SGD', label: 'SGD (S$) — Singapore Dollar' },
      { code: 'MYR', label: 'MYR (RM) — Malaysian Ringgit' },
      { code: 'JPY', label: 'JPY (¥) — Japanese Yen' },
      { code: 'CHF', label: 'CHF — Swiss Franc' },
      { code: 'QAR', label: 'QAR (ر.ق) — Qatari Riyal' },
      { code: 'KWD', label: 'KWD (د.ك) — Kuwaiti Dinar' }
    ];

    var curOptions = currencyList.map(function(c) {
      var sel = (c.code === supportInputCurrency) ? ' selected' : '';
      return '<option value="' + c.code + '"' + sel + '>' + escapeHtml(c.label) + '</option>';
    }).join('');

    var tabDefs = [
      {
        key: 'CARD',
        title: 'US Corporate & Global Cards',
        sub: 'CSB NEWS USA LLC Official Credit Card',
        svg: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>'
      },
      {
        key: 'US_BANK',
        title: 'US Bank Account',
        sub: 'ACH · Fedwire · Routing · Zelle',
        svg: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 7 22 7 12 2"/><line x1="6" y1="7" x2="6" y2="18"/><line x1="10" y1="7" x2="10" y2="18"/><line x1="14" y1="7" x2="14" y2="18"/><line x1="18" y1="7" x2="18" y2="18"/><rect x="2" y="18" width="20" height="4"/></svg>'
      },
      {
        key: 'BD_BANK',
        title: 'Bangladesh Bank & MFS',
        sub: 'BD Bank · BEFTN · NPSB · bKash',
        svg: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M9 8h4a2 2 0 0 1 0 4H9v4h5"/></svg>'
      },
      {
        key: 'INTL_WIRE',
        title: 'International Wire',
        sub: 'Worldwide SWIFT · IBAN to USD',
        svg: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>'
      }
    ];

    var tabsHtml = tabDefs.map(function(t) {
      var cls = (activeSupportCategory === t.key) ? 'payment-tab-btn active' : 'payment-tab-btn';
      return '<button type="button" class="' + cls + '" onclick="selectSupportPaymentCategory(\'' + t.key + '\')">' +
        t.svg +
        '<span>' + escapeHtml(t.title) + '</span>' +
        '<span style="font-size:10px;font-weight:400;opacity:0.82;">' + escapeHtml(t.sub) + '</span>' +
      '</button>';
    }).join('');

    var allMethods = (state.paymentConfig && state.paymentConfig.methods) ? state.paymentConfig.methods : [];
    var activeMethods = allMethods.filter(function(m) {
      return m.active && m.category === activeSupportCategory;
    });

    var methodsListHtml = activeMethods.map(function(m) {
      return '<div style="background:#ffffff;border:1.5px solid #060d3a;padding:16px 18px;margin-bottom:14px;border-left:5px solid var(--accent-red);">' +
        '<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:6px;">' +
          '<div style="font-weight:700;font-size:15px;color:var(--navy-dark);">' + escapeHtml(m.title) + '</div>' +
          '<button type="button" class="platform-pill-btn" style="font-size:11px;padding:4px 10px;" onclick="copyTextToClipboard(\'' + escapeHtml(m.accountName + ' | ' + m.accountNumber + ' | ' + m.routingOrSwift) + '\', \'Corporate Account / Card Details\')">Copy Details</button>' +
        '</div>' +
        '<div style="font-size:12.5px;font-weight:600;color:var(--accent-red);margin-bottom:6px;">' + escapeHtml(m.provider) + '</div>' +
        '<div style="font-size:13px;color:#1e222b;line-height:1.55;background:#faf7f0;padding:10px 12px;border:1px solid #e2dac9;font-family:monospace;">' +
          '<div><strong>Beneficiary / Corporate Entity:</strong> ' + escapeHtml(m.accountName) + '</div>' +
          '<div><strong>Account / Official Corporate Card:</strong> ' + escapeHtml(m.accountNumber) + '</div>' +
          '<div><strong>Routing / SWIFT / Verification:</strong> ' + escapeHtml(m.routingOrSwift) + '</div>' +
        '</div>' +
        '<div style="font-size:12px;color:#494d57;margin-top:8px;">' + escapeHtml(m.instructions) + '</div>' +
      '</div>';
    }).join('');

    var cardDirectCheckoutHtml = '';
    if (activeSupportCategory === 'CARD') {
      cardDirectCheckoutHtml = '<div style="background:#faf7f0;border:1px solid #c9c0ae;padding:16px 18px;margin-bottom:16px;">' +
        '<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:10px;">' +
          '<div class="kicker-red">DIRECT CORPORATE CARD REMITTANCE (RECEIVE-ONLY · NO CVV OR CODE NEEDED)</div>' +
          '<div style="display:flex;gap:6px;font-size:11px;font-weight:700;">' +
            '<span style="background:#060d3a;color:#fff;padding:3px 8px;border-radius:2px;">VISA COMMERCIAL</span>' +
            '<span style="background:#df4636;color:#fff;padding:3px 8px;border-radius:2px;">MASTERCARD CORP</span>' +
            '<span style="background:#1b6e38;color:#fff;padding:3px 8px;border-radius:2px;">AMEX BUSINESS</span>' +
          '</div>' +
        '</div>' +
        '<p style="font-size:12px;color:#1b6e38;margin:0 0 10px;">Send funds directly to the official CSB NEWS USA LLC receiving card above. No CVV, PIN, or security code is ever requested.</p>' +
        '<div class="responsive-form-grid-2">' +
          '<div><label class="cms-label">Sender Name / Organization</label><input type="text" id="supCardHolder" class="cms-input" placeholder="e.g. Reader or Organization Name"/></div>' +
          '<div><label class="cms-label">Transfer Reference / Sender Last 4 Digits</label><input type="text" id="supCardNumber" class="cms-input" placeholder="e.g. REF-8841"/></div>' +
        '</div>' +
      '</div>';
    }

    var receiptHtml = '';
    if (lastCompletedReceipt) {
      receiptHtml = '<div style="background:#e3f3e8;border:2px solid #1b6e38;padding:18px 20px;margin-bottom:18px;">' +
        '<div style="font-weight:700;font-size:15px;color:#1b6e38;margin-bottom:6px;">&#10003; Official Contribution Recorded &amp; Verified in CSB NEWS USA LLC Treasury</div>' +
        '<div style="font-size:13px;color:#12161f;line-height:1.6;">' +
          '<strong>Receipt ID:</strong> ' + escapeHtml(lastCompletedReceipt.id) + ' &nbsp;|&nbsp; ' +
          '<strong>Contributor:</strong> ' + escapeHtml(lastCompletedReceipt.donorName) + ' (' + escapeHtml(lastCompletedReceipt.donorEmail) + ')<br/>' +
          '<strong>Amount Contributed:</strong> ' + escapeHtml(String(lastCompletedReceipt.originalAmount)) + ' ' + escapeHtml(lastCompletedReceipt.originalCurrency) +
          ' (<strong>Settled as $' + Number(lastCompletedReceipt.usdEquivalent).toFixed(2) + ' USD</strong>)<br/>' +
          '<strong>Settlement Channel:</strong> ' + escapeHtml(lastCompletedReceipt.methodTitle) + ' &nbsp;|&nbsp; <strong>Ref:</strong> ' + escapeHtml(lastCompletedReceipt.referenceId) +
        '</div>' +
      '</div>';
    }

    container.innerHTML =
      '<p style="margin:0 0 16px;font-family:var(--font-serif);font-size:15.5px;line-height:1.6;color:#2c313c;">' +
        'Every Sunday edition is sustained by readers who value patient, deeply researched writing. All global contributions settle into the official <strong>CSB NEWS USA LLC</strong> treasury (US Business Corporate Credit Cards, US Commercial Bank, Bangladesh Bank/MFS, or Worldwide SWIFT).' +
      '</p>' +

      /* Worldwide Currency-to-Dollar Converter Box */
      '<div class="support-currency-box">' +
        '<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:12px;">' +
          '<div class="kicker-red">WORLDWIDE CURRENCY TO US DOLLAR (USD $) CONVERTER</div>' +
          '<div style="display:flex;gap:6px;flex-wrap:wrap;">' +
            '<button type="button" class="platform-pill-btn" onclick="setPresetUsdSupport(10)">$10</button>' +
            '<button type="button" class="platform-pill-btn" onclick="setPresetUsdSupport(25)">$25</button>' +
            '<button type="button" class="platform-pill-btn" onclick="setPresetUsdSupport(50)">$50</button>' +
            '<button type="button" class="platform-pill-btn" onclick="setPresetUsdSupport(100)">$100</button>' +
            '<button type="button" class="platform-pill-btn" onclick="setPresetUsdSupport(250)">$250</button>' +
          '</div>' +
        '</div>' +
        '<div style="display:grid;grid-template-columns:1fr 1.4fr 1.2fr;gap:12px;align-items:end;">' +
          '<div>' +
            '<label class="cms-label" for="supAmountInput">Contribution Amount</label>' +
            '<input type="number" id="supAmountInput" class="cms-input" min="1" step="any" value="' + escapeHtml(String(supportInputAmount)) + '" oninput="handleSupportCurrencyChange()"/>' +
          '</div>' +
          '<div>' +
            '<label class="cms-label" for="supCurrencySelect">Your Local Currency (15+ Global Currencies)</label>' +
            '<select id="supCurrencySelect" class="cms-select" onchange="handleSupportCurrencyChange()">' + curOptions + '</select>' +
          '</div>' +
          '<div style="background:var(--navy-dark);color:#ffffff;padding:9px 14px;border-radius:3px;text-align:center;">' +
            '<div style="font-size:10px;letter-spacing:0.1em;text-transform:uppercase;color:#cfd4e2;">USD Settlement Equivalent</div>' +
            '<div id="supUsdEquivalentReadout" style="font-family:var(--font-serif);font-size:20px;font-weight:700;color:#ffffff;">$' + usdEq.toFixed(2) + ' USD</div>' +
          '</div>' +
        '</div>' +
      '</div>' +

      /* 4 Payment Method Blocks */
      '<div class="payment-tabs-grid">' + tabsHtml + '</div>' +

      receiptHtml +
      methodsListHtml +
      cardDirectCheckoutHtml +

      /* Donor Confirmation & Ledger Recording Form */
      '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:16px 18px;">' +
        '<div class="kicker-red" style="margin-bottom:10px;">CONFIRM &amp; LOG YOUR CONTRIBUTION TO CSB NEWS USA LLC</div>' +
        '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:14px;">' +
          '<div><label class="cms-label" for="supDonorName">Your Full Name / Organization</label><input type="text" id="supDonorName" class="cms-input" placeholder="e.g. Jonathan Vance"/></div>' +
          '<div><label class="cms-label" for="supportEmailInput">Your Email (For Receipt)</label><input type="email" id="supportEmailInput" class="cms-input" placeholder="e.g. reader@harvard.edu"/></div>' +
          '<div><label class="cms-label" for="supDonorRef">Transaction ID / Card Last 4</label><input type="text" id="supDonorRef" class="cms-input" placeholder="e.g. TXN-94820 or 8841"/></div>' +
        '</div>' +
        '<button type="button" class="btn-red-action" style="width:100%;justify-content:center;padding:13px;font-size:14px;" onclick="submitSupportTransaction()">Confirm Support &#8599;</button>' +
      '</div>';
  }

  window.submitSupportTransaction = function() {
    var donorName = ((document.getElementById('supDonorName') || {}).value || '').trim();
    var donorEmail = ((document.getElementById('supportEmailInput') || {}).value || '').trim();
    var donorRef = ((document.getElementById('supDonorRef') || {}).value || '').trim();
    var cardHolder = ((document.getElementById('supCardHolder') || {}).value || '').trim();
    var cardNum = ((document.getElementById('supCardNumber') || {}).value || '').trim();

    if (!donorName && cardHolder) donorName = cardHolder;
    if (!donorRef && cardNum) donorRef = 'CARD-' + cardNum.slice(-4);

    if (!donorName || !donorEmail) {
      showToast('Please enter your Name and Email Address so we can issue your contribution receipt.');
      return;
    }

    var usdEq = computeUsdEquivalent(supportInputAmount, supportInputCurrency);
    var activeMethods = (state.paymentConfig && state.paymentConfig.methods) ? state.paymentConfig.methods.filter(function(m) {
      return m.active && m.category === activeSupportCategory;
    }) : [];
    var methodTitle = activeMethods.length > 0 ? activeMethods[0].title : activeSupportCategory;

    var newTx = {
      id: 'tx_' + Date.now(),
      donorName: donorName,
      donorEmail: donorEmail,
      originalAmount: supportInputAmount,
      originalCurrency: supportInputCurrency,
      usdEquivalent: Number(usdEq.toFixed(2)),
      methodCategory: activeSupportCategory,
      methodTitle: methodTitle,
      referenceId: donorRef || ('REF-' + String(Date.now()).slice(-6)),
      date: '2026-10-25',
      status: 'Verified'
    };

    if (!state.transactions) state.transactions = [];
    state.transactions.unshift(newTx);
    lastCompletedReceipt = newTx;
    saveState();

    if (window.location.protocol.indexOf('http') === 0) {
      try {
        var apiUrl = ['api', '.php?action='].join('');
        fetch(apiUrl + 'save_transaction', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newTx)
        }).catch(function() {});
      } catch (e) {}
    }

    renderSupportModalBody();
    showToast('Thank you, ' + donorName + '! Your contribution ($' + usdEq.toFixed(2) + ' USD) has been recorded in the CSB NEWS USA LLC Treasury.');
  };

  // ============================================================================
  // FREE EMAIL VERIFICATION WORKFLOW FOR WEBSITE USER IDs
  // ============================================================================
  window.openEmailVerifyModal = function(userId) {
    var u = getUserById(userId);
    if (!u) return;
    verifyingUserId = u.id;
    activeVerificationCode = String(Math.floor(100000 + Math.random() * 900000));

    if (window.location.protocol.indexOf('http') === 0) {
      try {
        var apiUrl = ['api', '.php?action='].join('');
        fetch(apiUrl + 'send_verification_email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: u.email, code: activeVerificationCode, name: u.name })
        }).catch(function() {});
      } catch (e) {}
    }

    var modal = document.getElementById('emailVerifyModal');
    var body = document.getElementById('emailVerifyModalBody');
    if (body) {
      body.innerHTML =
        '<p style="margin:0 0 12px;font-size:13.5px;line-height:1.55;">' +
          'A 6-digit confirmation code has been dispatched to <strong>' + escapeHtml(u.email) + '</strong> via <code>api.php?action=send_verification_email</code> (100% free via Hostinger native domain mail).' +
        '</p>' +
        '<div style="background:#ebe4d4;border-left:4px solid var(--accent-red);padding:10px 14px;font-size:12.5px;margin-bottom:16px;">' +
          '<strong>Instant Preview / Dispatch Code for Testing:</strong> <code style="font-size:15px;font-weight:700;color:var(--navy-dark);">' + escapeHtml(activeVerificationCode) + '</code>' +
        '</div>' +
        '<div style="margin-bottom:16px;">' +
          '<label class="cms-label" for="verifyCodeInput">Enter 6-Digit Confirmation Code</label>' +
          '<input type="text" id="verifyCodeInput" class="cms-input" value="' + escapeHtml(activeVerificationCode) + '" style="font-size:18px;font-weight:700;letter-spacing:0.2em;text-align:center;"/>' +
        '</div>' +
        '<button type="button" class="btn-red-action" style="width:100%;justify-content:center;padding:12px;" onclick="confirmEmailVerificationCode()">Verify Email Address Now &#8599;</button>';
    }
    if (modal) modal.classList.add('open');
  };

  window.closeEmailVerifyModal = function() {
    var modal = document.getElementById('emailVerifyModal');
    if (modal) modal.classList.remove('open');
  };

  window.confirmEmailVerificationCode = function() {
    var inp = document.getElementById('verifyCodeInput');
    var entered = inp ? (inp.value || '').trim() : '';
    if (entered !== activeVerificationCode) {
      showToast('Invalid verification code. Please check the 6-digit code.');
      return;
    }
    var u = getUserById(verifyingUserId);
    if (u) {
      u.emailVerified = true;
      saveState();
      showToast('Email address ' + u.email + ' is now Verified ✓');
    }
    closeEmailVerifyModal();
    renderMainView();
  };

  // ============================================================================
  // MAIN VIEW ROUTER & RENDERERS
  // ============================================================================
  function ensureSiteAndAdsConfig() {
    if (!state.siteConfig) {
      state.siteConfig = (window.WEEKLINE_INITIAL_DB && window.WEEKLINE_INITIAL_DB.siteConfig)
        ? JSON.parse(JSON.stringify(window.WEEKLINE_INITIAL_DB.siteConfig))
        : { articlesPerPage: 12, sectionOrder: ['top_motion_ad', 'custom_blocks_top', 'hero_story', 'mid_motion_ad', 'newspaper_archive', 'custom_blocks_bottom'], customBlocks: [] };
    }
    if (!state.adsConfig) {
      state.adsConfig = (window.WEEKLINE_INITIAL_DB && window.WEEKLINE_INITIAL_DB.adsConfig)
        ? JSON.parse(JSON.stringify(window.WEEKLINE_INITIAL_DB.adsConfig))
        : { enabled: true, items: [] };
    }
  }

  function applySiteConfigToDom() {
    if (!state) return;
    ensureSiteAndAdsConfig();
    var sc = state.siteConfig;
    var setTxt = function(id, val) {
      var el = document.getElementById(id);
      if (el && val !== undefined && val !== null && val !== '') el.textContent = val;
    };
    setTxt('uiTopRibbonText', sc.topRibbonText);
    setTxt('uiNavContributorsBtn', sc.navContributorsLabel);
    setTxt('uiNavWriteForUsBtn', sc.navWriteForUsLabel);
    setTxt('uiNavEditorialDeskBtn', sc.navEditorialDeskLabel);
    var leftK = document.getElementById('uiMastheadLeftKicker');
    if (leftK && sc.mastheadLeftKicker) leftK.innerHTML = escapeHtml(sc.mastheadLeftKicker).replace(/\n/g, '<br/>');
    setTxt('uiMastheadLeftQuote', sc.mastheadLeftQuote);
    setTxt('uiMastheadBrandTitle', sc.mastheadBrandTitle);
    setTxt('uiMastheadSub', sc.mastheadSubtitle);
    setTxt('uiMastheadRightMotto', sc.mastheadRightMotto);
    setTxt('uiMastheadSupportBtn', sc.mastheadSupportLabel);
    setTxt('uiExploreJournalBtn', sc.exploreJournalLabel);
    setTxt('uiPromoKicker', sc.promoKicker);
    setTxt('uiPromoHeading', sc.promoHeading);
    setTxt('uiPromoBody', sc.promoBody);
    setTxt('uiFooterBrand', sc.footerBrandTitle);
    setTxt('uiFooterSubLine', sc.footerSubLine);
    setTxt('uiFooterTagline', sc.footerTagline);
    setTxt('uiFooterContactBtn', sc.footerContactLabel);

    var headerEl = document.getElementById('uiMastheadHeader');
    if (headerEl) {
      if (sc.coverBgImage) {
        headerEl.style.background = 'linear-gradient(rgba(6,13,58,0.82), rgba(6,13,58,0.88)), url("' + resolvePhoto(sc.coverBgImage) + '") center/cover no-repeat';
      } else {
        headerEl.style.background = sc.coverBgColor || '#060d3a';
      }
    }

    var logoSrc = sc.siteLogo ? resolvePhoto(sc.siteLogo) : resolvePhoto('@photo:logo');
    var mLogo = document.getElementById('uiMastheadLogoImg');
    if (mLogo && logoSrc) mLogo.src = logoSrc;
    var fLogo = document.getElementById('uiFooterLogoImg');
    if (fLogo && logoSrc) fLogo.src = logoSrc;
  }

  function renderPaginationBarHtml(totalItems, currentPageNum, perPage, pageFnName) {
    var totalPages = perPage >= 9999 ? 1 : Math.max(1, Math.ceil(totalItems / perPage));
    var safePage = Math.min(Math.max(1, currentPageNum), totalPages);
    var startIdx = (safePage - 1) * perPage + 1;
    var endIdx = Math.min(totalItems, safePage * perPage);

    var btns = '';
    btns += '<button type="button" class="page-num-btn" onclick="' + pageFnName + '(' + (safePage - 1) + ')"' + (safePage <= 1 ? ' disabled' : '') + '>&#8592; Prev</button>';
    for (var p = 1; p <= totalPages; p++) {
      var activeCls = (p === safePage) ? ' page-num-btn active' : ' page-num-btn';
      btns += '<button type="button" class="' + activeCls.trim() + '" onclick="' + pageFnName + '(' + p + ')">Page ' + p + '</button>';
    }
    btns += '<button type="button" class="page-num-btn" onclick="' + pageFnName + '(' + (safePage + 1) + ')"' + (safePage >= totalPages ? ' disabled' : '') + '>Next &#8594;</button>';

    var perPageSelect = '<select class="cms-select" style="width:auto;padding:6px 10px;font-size:12px;" onchange="changeArticlesPerPage(this.value)">' +
      '<option value="12"' + (perPage === 12 ? ' selected' : '') + '>12 Reports / Page</option>' +
      '<option value="24"' + (perPage === 24 ? ' selected' : '') + '>24 Reports / Page</option>' +
      '<option value="6"' + (perPage === 6 ? ' selected' : '') + '>6 Reports / Page</option>' +
      '<option value="9999"' + (perPage >= 9999 ? ' selected' : '') + '>View All (' + totalItems + ') on 1 Page</option>' +
    '</select>';

    return '<nav class="pagination-wrap" aria-label="Multi-page archive navigation">' +
      '<div style="font-size:12.5px;color:#454952;">' +
        '<strong>Page ' + safePage + ' of ' + totalPages + '</strong> · Showing reports <strong>' + startIdx + '–' + endIdx + '</strong> of <strong>' + totalItems + '</strong> (Unlimited multi-page archive expands automatically)' +
      '</div>' +
      '<div class="pagination-pages">' + btns + perPageSelect + '</div>' +
    '</nav>';
  }

  window.handleMotionAdClick = function(adId) {
    ensureSiteAndAdsConfig();
    var ad = (state.adsConfig.items || []).find(function(x) { return x.id === adId; });
    if (ad) {
      ad.clicks = (Number(ad.clicks) || 0) + 1;
      saveStateLocal();
      if (ad.targetUrl === '#support') {
        openSupportModal();
        return false;
      }
      if (ad.targetUrl && ad.targetUrl.indexOf('#category/') === 0) {
        var catPart = decodeURIComponent(ad.targetUrl.split('/')[1] || 'History');
        filterByCategory(catPart);
        return false;
      }
    }
    return true;
  };

  function renderMotionAdSlotHtml(slotKey) {
    ensureSiteAndAdsConfig();
    if (!state.adsConfig.enabled || !state.adsConfig.items) return '';
    var matching = state.adsConfig.items.filter(function(x) { return x.active && x.slot === slotKey; });
    if (matching.length === 0) return '';

    return matching.map(function(ad) {
      ad.impressions = (Number(ad.impressions) || 0) + 1;
      if (ad.customHtml && ad.customHtml.trim()) {
        return '<div class="journal-section" style="padding-top:10px;padding-bottom:10px;"><div class="motion-ad-container ' + escapeHtml(ad.motionStyle || 'motion-shimmer') + '" style="padding:18px;">' + ad.customHtml + '</div></div>';
      }
      var imgResolved = ad.imageUrl ? resolvePhoto(ad.imageUrl) : resolvePhoto('@photo:logo');
      var tickerHtml = (ad.motionStyle === 'motion-marquee')
        ? ('<div class="motion-ad-ticker-bar"><div class="motion-ad-ticker-track">' +
            escapeHtml(ad.sponsorName) + ' · ' + escapeHtml(ad.kicker || 'OFFICIAL PARTNER') + ' · ' + escapeHtml(ad.headline) + ' · ' +
            escapeHtml(ad.sponsorName) + ' · ' + escapeHtml(ad.kicker || 'OFFICIAL PARTNER') + ' · ' + escapeHtml(ad.headline) +
          '</div></div>')
        : '';

      var isInternal = (ad.targetUrl === '#support' || (ad.targetUrl && ad.targetUrl.indexOf('#category/') === 0));
      var ctaAttr = isInternal
        ? ('href="javascript:void(0)" onclick="handleMotionAdClick(\'' + ad.id + '\')"')
        : ('href="' + escapeHtml(ad.targetUrl || '#') + '" target="_blank" rel="noopener noreferrer" onclick="handleMotionAdClick(\'' + ad.id + '\')"');

      return '<div class="journal-section" style="padding-top:8px;padding-bottom:8px;">' +
        '<div class="motion-ad-container ' + escapeHtml(ad.motionStyle || 'motion-shimmer') + '">' +
          tickerHtml +
          '<div class="motion-ad-bg-layer" style="background-image:url(\'' + imgResolved + '\');"></div>' +
          '<div class="motion-ad-inner">' +
            '<img class="motion-ad-thumb" src="' + imgResolved + '" alt="' + escapeHtml(ad.sponsorName) + '"/>' +
            '<div>' +
              '<div style="font-size:10.5px;letter-spacing:0.12em;text-transform:uppercase;color:#f0b429;font-weight:700;margin-bottom:4px;">' + escapeHtml(ad.kicker || 'SPONSORED MOTION SHOWCASE') + ' · ' + escapeHtml(ad.sponsorName) + '</div>' +
              '<h3 style="font-family:var(--font-serif);font-size:22px;margin:0 0 6px;color:#ffffff;">' + escapeHtml(ad.headline) + '</h3>' +
              '<p style="font-size:13.5px;color:#dbe2f0;margin:0;line-height:1.45;">' + escapeHtml(ad.subtext) + '</p>' +
            '</div>' +
            '<div>' +
              '<a ' + ctaAttr + ' class="motion-ad-cta">' + escapeHtml(ad.ctaText || 'Learn More ↗') + '</a>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';
    }).join('');
  }

  window.triggerCustomBlockAction = function(actionVal) {
    if (actionVal === 'write_for_us') openWriteForUsModal();
    else if (actionVal === 'support_us') openSupportModal();
    else if (actionVal === 'cms') openCmsDashboard();
    else if (actionVal && actionVal.indexOf('http') === 0) window.open(actionVal, '_blank', 'noopener');
  };

  function renderCustomBlocksZoneHtml(zoneKey) {
    ensureSiteAndAdsConfig();
    var blocks = (state.siteConfig.customBlocks || []).filter(function(b) { return b.active && (b.zone || 'bottom') === zoneKey; });
    if (blocks.length === 0) return '';
    return blocks.map(function(b) {
      if (b.type === 'code' && b.customHtml) {
        return '<section class="journal-section" style="padding-top:14px;padding-bottom:14px;">' + b.customHtml + '</section>';
      }
      var imgHtml = b.imageUrl
        ? ('<img src="' + resolvePhoto(b.imageUrl) + '" alt="' + escapeHtml(b.title) + '" style="width:180px;height:120px;object-fit:cover;border:1px solid #c9c0ae;"/>')
        : '';
      var btnHtml = b.ctaText
        ? ('<button type="button" class="btn-red-action" onclick="triggerCustomBlockAction(\'' + escapeHtml(b.ctaAction || 'write_for_us') + '\')">' + escapeHtml(b.ctaText) + '</button>')
        : '';
      return '<section class="journal-section" style="padding-top:14px;padding-bottom:14px;">' +
        '<div style="background:' + escapeHtml(b.bgColor || '#f4efe4') + ';border:1px solid #d5cdbc;border-left:4px solid var(--navy-dark);padding:22px 26px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:20px;">' +
          '<div style="display:flex;align-items:center;gap:20px;flex-wrap:wrap;flex:1;">' +
            imgHtml +
            '<div style="flex:1;min-width:240px;">' +
              '<div class="kicker-red" style="margin-bottom:4px;">' + escapeHtml(b.kicker || 'EDITORIAL FEATURE BLOCK') + '</div>' +
              '<h3 style="font-family:var(--font-serif);font-size:23px;margin:0 0 6px;color:var(--ink-black);">' + escapeHtml(b.title) + '</h3>' +
              '<p style="font-size:14px;color:#3b404b;margin:0;line-height:1.55;">' + escapeHtml(b.description) + '</p>' +
            '</div>' +
          '</div>' +
          btnHtml +
        '</div>' +
      '</section>';
    }).join('');
  }

  function renderMainView() {
    var root = document.getElementById('appMainContainer');
    if (!root) return;

    var cells = document.querySelectorAll('[data-cat-btn]');
    for (var i = 0; i < cells.length; i++) {
      var cName = cells[i].getAttribute('data-cat-btn');
      if (currentView === 'home' && activeCategory === cName) {
        cells[i].classList.add('active-cat');
      } else {
        cells[i].classList.remove('active-cat');
      }
    }

    if (currentView === 'article') {
      root.innerHTML = buildArticleDetailHtml(currentArticleId);
    } else if (currentView === 'profile') {
      root.innerHTML = buildContributorProfileHtml(currentProfileUserId);
    } else if (currentView === 'contributors') {
      root.innerHTML = buildAllContributorsDirectoryHtml();
    } else if (currentView === 'cms') {
      root.innerHTML = buildCmsDashboardHtml();
    } else {
      root.innerHTML = buildHomeViewHtml();
    }
  }

  function buildHomeViewHtml() {
    ensureSiteAndAdsConfig();
    var sc = state.siteConfig;
    var published = state.articles.filter(function(a) { return a.status === 'published'; });
    var heroArt = published.find(function(a) { return a.isHero; }) || published[0];
    var heroAuthor = getUserById(heroArt.authorId);

    var heroHtml = '';
    if ((activeCategory === 'ALL' || activeCategory === 'Weekline Exclusive') && !searchQuery && currentPage === 1) {
      heroHtml = '<section class="hero-section">' +
        '<div class="section-topline">' +
          '<span class="kicker-red">SUNDAY FEATURE · ' + escapeHtml(heroArt.date) + '</span>' +
          '<button type="button" class="link-underlined" onclick="filterByCategory(\'Weekline Exclusive\')">All exclusives &#8599;</button>' +
        '</div>' +
        '<div class="hero-grid">' +
          '<div class="hero-image-frame" onclick="openArticle(\'' + heroArt.id + '\')">' +
            '<img data-art-img="' + heroArt.id + '" src="' + resolvePhoto(heroArt.featuredImage) + '" alt="' + escapeHtml(heroArt.title) + '"/>' +
          '</div>' +
          '<div>' +
            '<div class="kicker-red" style="margin-bottom:6px;">' + escapeHtml(sc.heroSectionKicker || 'THE STORY IN FOCUS') + '</div>' +
            '<div style="margin-bottom:10px;">' + renderArticleCategoriesBadgesHtml(heroArt) + '</div>' +
            '<h2 class="hero-headline" onclick="openArticle(\'' + heroArt.id + '\')">' + escapeHtml(heroArt.title) + '</h2>' +
            '<p class="hero-deck">' + escapeHtml(heroArt.subtitle) + '</p>' +
            '<div class="author-chip-row">' +
              renderAuthorChip(heroAuthor, heroArt.readTime, heroArt.date) +
            '</div>' +
            '<button type="button" class="link-underlined" style="color:var(--accent-red);border-bottom-color:var(--accent-red);font-weight:600;" onclick="openArticle(\'' + heroArt.id + '\')">Read the full story &#8599;</button>' +
          '</div>' +
        '</div>' +
      '</section>';
    }

    var filtered = published.filter(function(a) {
      if (activeCategory === 'ALL' && !searchQuery && a.id === heroArt.id) return false;
      if (activeCategory !== 'ALL' && !articleHasCategory(a, activeCategory)) return false;
      if (searchQuery) {
        var u = getUserById(a.authorId);
        var catStr = getArticleCategories(a).join(' ');
        var hay = (a.title + ' ' + a.subtitle + ' ' + catStr + ' ' + (u ? u.name : '')).toLowerCase();
        if (hay.indexOf(searchQuery) === -1) return false;
      }
      return true;
    });

    var perPage = Number(sc.articlesPerPage) || 12;
    var totalPages = perPage >= 9999 ? 1 : Math.max(1, Math.ceil(filtered.length / perPage));
    if (currentPage > totalPages) currentPage = totalPages;
    var startIdx = (currentPage - 1) * perPage;
    var pagedArticles = perPage >= 9999 ? filtered : filtered.slice(startIdx, startIdx + perPage);

    var sectionHeading = activeCategory === 'ALL'
      ? (sc.archiveSectionTitle || 'Latest from the Sunday editions')
      : ('Category: ' + activeCategory + ' (Page ' + currentPage + ' of ' + totalPages + ')');
    var sectionSub = activeCategory === 'ALL'
      ? (sc.archiveSectionSub || 'Published weekly on Sundays starting August 8 · Thoughtful essays & analysis')
      : (filtered.length + ' published long-form essays in ' + activeCategory);

    var archiveHtml = '<section class="journal-section" id="journalSectionAnchor">' +
      '<div class="journal-header">' +
        '<h2>' + escapeHtml(sectionHeading) + '</h2>' +
        '<div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;justify-content:center;">' +
          '<span style="font-size:13px;color:#5a606d;">' + escapeHtml(sectionSub) + '</span>' +
          (activeCategory !== 'ALL' || searchQuery || currentPage > 1 ? '<button type="button" class="btn-red-action" style="padding:6px 12px;font-size:11.5px;" onclick="goHome(\'ALL\')">Show All 13 Categories (Page 1)</button>' : '') +
        '</div>' +
      '</div>';

    if (filtered.length === 0) {
      archiveHtml += '<div style="padding:48px 20px;text-align:center;background:#ece5d5;border:1px solid #d5cdbc;">' +
        '<p style="font-family:var(--font-serif);font-size:20px;margin:0 0 12px;">No essays matched your filter.</p>' +
        '<button type="button" class="btn-red-action" onclick="goHome(\'ALL\')">Reset View</button>' +
      '</div>';
    } else {
      archiveHtml += '<div class="cards-grid-newspaper">';
      for (var i = 0; i < pagedArticles.length; i++) {
        archiveHtml += renderArticleCardHtml(pagedArticles[i]);
      }
      archiveHtml += '</div>';
      archiveHtml += renderPaginationBarHtml(filtered.length, currentPage, perPage, 'goToPage');
    }
    archiveHtml += '</section>';

    var order = (sc.sectionOrder && sc.sectionOrder.length)
      ? sc.sectionOrder
      : ['top_motion_ad', 'custom_blocks_top', 'hero_story', 'mid_motion_ad', 'newspaper_archive', 'custom_blocks_bottom'];

    var sectionMap = {
      top_motion_ad: renderMotionAdSlotHtml('top_leaderboard'),
      custom_blocks_top: renderCustomBlocksZoneHtml('top'),
      hero_story: heroHtml,
      mid_motion_ad: renderMotionAdSlotHtml('mid_feed'),
      newspaper_archive: archiveHtml,
      custom_blocks_bottom: renderCustomBlocksZoneHtml('bottom')
    };

    return order.map(function(k) { return sectionMap[k] || ''; }).join('');
  }

  function renderArticleCardHtml(art) {
    var author = getUserById(art.authorId);
    var titleCls = art.highlightRed ? 'card-title highlight-red' : 'card-title';
    return '<article class="article-card">' +
      '<div style="width:100%;">' +
        '<div class="card-thumb" onclick="openArticle(\'' + art.id + '\')">' +
          '<img data-art-img="' + art.id + '" src="' + resolvePhoto(art.featuredImage) + '" alt="' + escapeHtml(art.title) + '"/>' +
        '</div>' +
        '<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-bottom:4px;">' +
          renderArticleCategoriesBadgesHtml(art) +
          '<span style="font-size:11.5px;color:#5a606d;font-weight:600;">Sunday Edition · ' + escapeHtml(art.date) + '</span>' +
        '</div>' +
        '<h3 class="' + titleCls + '" onclick="openArticle(\'' + art.id + '\')">' + escapeHtml(art.title) + '</h3>' +
        '<p class="card-deck">' + escapeHtml(art.subtitle) + '</p>' +
      '</div>' +
      '<div class="card-footer-author">' +
        renderAuthorChip(author, art.readTime, '') +
      '</div>' +
    '</article>';
  }

  function renderDirectShareBarHtml(art, labelPrefix) {
    var btns = PLATFORM_META.map(function(p) {
      return '<button type="button" class="platform-pill-btn" onclick="shareArticleOnPlatform(\'' + p.key + '\', \'' + art.id + '\')" title="Share directly to your ' + p.label + ' account">' +
        getPlatformIconSvg(p.key) +
        '<span>' + p.label + '</span>' +
      '</button>';
    }).join('');
    return '<div class="share-bar-box">' +
      '<span style="font-size:11px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:var(--navy-dark);">' + escapeHtml(labelPrefix) + ':</span>' +
      '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;justify-content:center;">' + btns + '</div>' +
    '</div>';
  }

  function renderOfficialPlatformLinksBarHtml() {
    var linksHtml = PLATFORM_META.map(function(p) {
      var url = (state.socialLinks && state.socialLinks[p.key]) ? state.socialLinks[p.key] : 'https://weekline-editorial-demo.vastnewt128.chatgpt.site/';
      return '<a href="' + escapeHtml(url) + '" target="_blank" rel="noopener noreferrer" class="platform-pill-btn" style="background:var(--navy-dark);color:#ffffff;border-color:rgba(255,255,255,0.22);">' +
        getPlatformIconSvg(p.key) +
        '<span>' + p.label + ' &#8599;</span>' +
      '</a>';
    }).join('');
    return '<div style="background:var(--navy-dark);color:#ffffff;padding:24px 26px;margin-top:34px;border-top:3px solid var(--accent-red);">' +
      '<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px;">' +
        '<div>' +
          '<div class="kicker-red" style="margin-bottom:4px;">OFFICIAL CHANNELS</div>' +
          '<div style="font-family:var(--font-serif);font-size:18px;">Follow our weekly conversations across all seven platforms</div>' +
        '</div>' +
        '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">' + linksHtml + '</div>' +
      '</div>' +
    '</div>';
  }

  function buildArticleDetailHtml(artId) {
    var art = state.articles.find(function(a) { return a.id === artId; }) || state.articles[0];
    var author = getUserById(art.authorId);
    var related = state.articles.filter(function(a) {
      return a.status === 'published' && a.category === art.category && a.id !== art.id;
    }).slice(0, 2);

    var customEmbedHtml = art.customHtml
      ? ('<div class="article-custom-html-embed">' + art.customHtml + '</div>')
      : '';

    return '<div class="article-reader-container">' +
      '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px;">' +
        '<button type="button" class="link-underlined" onclick="goHome(\'ALL\')">&#8592; Back to the Journal</button>' +
        '<span style="font-size:12px;color:#5a606d;font-weight:600;">Sunday Edition · ' + escapeHtml(art.date) + ' · ' + escapeHtml(art.readTime) + '</span>' +
      '</div>' +

      renderDirectShareBarHtml(art, 'Share') +

      '<div style="margin-top:18px;margin-bottom:4px;">' + renderArticleCategoriesBadgesHtml(art) + '</div>' +
      '<h1 style="font-family:var(--font-serif);font-size:clamp(28px,4.2vw,46px);line-height:1.12;margin:10px 0 16px;">' + escapeHtml(art.title) + '</h1>' +
      '<p style="font-family:var(--font-serif);font-size:19px;line-height:1.55;color:#454952;margin:0 0 22px;">' + escapeHtml(art.subtitle) + '</p>' +

      '<div style="border-top:1px solid #d5cdbc;border-bottom:1px solid #d5cdbc;padding:14px 0;margin-bottom:22px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;">' +
        renderAuthorChip(author, art.readTime, art.date) +
        (canEditOrDeleteArticle(art) ? '<button type="button" class="platform-pill-btn" onclick="openCmsDashboard();startEditArticleInCms(\'' + art.id + '\')">&#9998; Edit in CMS</button>' : '') +
      '</div>' +

      '<div style="margin-bottom:24px;border:1px solid #d5cdbc;overflow:hidden;background:#dfd7c5;">' +
        '<img data-art-img="' + art.id + '" src="' + resolvePhoto(art.featuredImage) + '" alt="' + escapeHtml(art.title) + '" style="width:100%;max-height:480px;object-fit:cover;display:block;"/>' +
      '</div>' +

      renderDirectShareBarHtml(art, 'Share') +

      '<div class="article-body-content" style="margin-top:26px;">' +
        art.body +
        customEmbedHtml +
      '</div>' +

      '<div style="background:#ebe4d4;border:1px solid #d2c8b5;padding:22px 24px;margin-top:36px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:18px;">' +
        '<div style="display:flex;align-items:center;gap:16px;cursor:pointer;" onclick="openContributorProfile(\'' + author.id + '\')">' +
          '<img src="' + resolvePhoto(author.avatar) + '" alt="' + escapeHtml(author.name) + '" style="width:64px;height:64px;border-radius:50%;object-fit:cover;border:2px solid var(--navy-dark);background:var(--navy-dark);"/>' +
          '<div>' +
            '<div style="font-weight:700;font-size:15px;color:var(--ink-black);text-transform:uppercase;letter-spacing:0.04em;">' + escapeHtml(author.name) + '</div>' +
            '<div style="font-weight:400;font-size:13.5px;color:#3b404b;margin-top:4px;max-width:520px;">' + escapeHtml(author.bio) + '</div>' +
          '</div>' +
        '</div>' +
        '<button type="button" class="btn-red-action" onclick="openContributorProfile(\'' + author.id + '\')">All essays by ' + escapeHtml(author.name) + ' &#8599;</button>' +
      '</div>' +

      renderMotionAdSlotHtml('article_footer') +
      renderOfficialPlatformLinksBarHtml() +
      (function() {
        var pubList = state.articles.filter(function(x) { return x.status === 'published'; });
        var curIdx = pubList.findIndex(function(x) { return x.id === art.id; });
        var prevArt = curIdx > 0 ? pubList[curIdx - 1] : pubList[pubList.length - 1];
        var nextArt = (curIdx >= 0 && curIdx < pubList.length - 1) ? pubList[curIdx + 1] : pubList[0];
        return '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px;margin-top:28px;">' +
          (prevArt ? ('<div style="background:#ffffff;border:1px solid #d5cdbc;padding:16px;cursor:pointer;" onclick="openArticle(\'' + prevArt.id + '\')"><div class="kicker-red">&#8592; PREVIOUS SUNDAY REPORT</div><div style="font-family:var(--font-serif);font-size:17px;font-weight:700;margin-top:4px;color:var(--navy-dark);">' + escapeHtml(prevArt.title) + '</div></div>') : '') +
          (nextArt ? ('<div style="background:#ffffff;border:1px solid #d5cdbc;padding:16px;cursor:pointer;text-align:right;" onclick="openArticle(\'' + nextArt.id + '\')"><div class="kicker-red">NEXT SUNDAY REPORT &#8594;</div><div style="font-family:var(--font-serif);font-size:17px;font-weight:700;margin-top:4px;color:var(--navy-dark);">' + escapeHtml(nextArt.title) + '</div></div>') : '') +
        '</div>';
      })() +

      (related.length > 0 ? (
        '<div style="margin-top:48px;border-top:2px solid var(--border-dark);padding-top:24px;">' +
          '<h3 style="font-family:var(--font-serif);font-size:24px;margin:0 0 20px;">More in ' + escapeHtml(art.category) + '</h3>' +
          '<div class="cards-grid-newspaper">' + related.map(renderArticleCardHtml).join('') + '</div>' +
        '</div>'
      ) : '') +
    '</div>';
  }

  function buildContributorProfileHtml(userId) {
    var user = getUserById(userId) || state.users[2];
    if (user.isHiddenSuper && !isLoggedSuperAdmin()) {
      user = getUserById('u_mahadi_contributor') || state.users[2];
    }
    var authored = state.articles.filter(function(a) {
      return a.status === 'published' && a.authorId === user.id;
    });

    return '<div class="journal-section" style="padding-top:32px;">' +
      '<div style="margin-bottom:20px;">' +
        '<button type="button" class="link-underlined" onclick="goHome(\'ALL\')">&#8592; Back to the Journal</button>' +
      '</div>' +
      '<div style="background:var(--navy-dark);color:#ffffff;padding:34px 36px;border-top:4px solid var(--accent-red);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:24px;margin-bottom:36px;">' +
        '<div style="display:flex;align-items:center;gap:22px;flex-wrap:wrap;">' +
          '<img src="' + resolvePhoto(user.avatar) + '" alt="' + escapeHtml(user.name) + '" style="width:92px;height:92px;border-radius:50%;object-fit:cover;border:3px solid var(--accent-red);background:var(--navy-dark);"/>' +
          '<div>' +
            '<div class="kicker-red" style="margin-bottom:6px;">CONTRIBUTOR PROFILE · ' + escapeHtml(user.role) + '</div>' +
            '<h1 style="font-family:var(--font-sans);font-weight:700;font-size:28px;margin:0 0 8px;color:#ffffff;">' + escapeHtml(user.name) + '</h1>' +
            '<p style="font-family:var(--font-sans);font-weight:400;font-size:15px;line-height:1.55;color:#d9deeb;margin:0;max-width:650px;">' + escapeHtml(user.bio) + '</p>' +
          '</div>' +
        '</div>' +
        '<div style="text-align:right;">' +
          '<div style="font-family:var(--font-serif);font-size:34px;font-weight:700;color:#ffffff;">' + authored.length + '</div>' +
          '<div style="font-size:11px;letter-spacing:0.12em;text-transform:uppercase;color:#cfd4e2;">Published Essays</div>' +
        '</div>' +
      '</div>' +
      '<div class="journal-header">' +
        '<h2>All Published Essays by ' + escapeHtml(user.name) + ' (' + authored.length + ')</h2>' +
      '</div>' +
      (function() {
        ensureSiteAndAdsConfig();
        var perPage = Number(state.siteConfig.articlesPerPage) || 12;
        var totalPages = perPage >= 9999 ? 1 : Math.max(1, Math.ceil(authored.length / perPage));
        if (profileCurrentPage > totalPages) profileCurrentPage = totalPages;
        var startIdx = (profileCurrentPage - 1) * perPage;
        var paged = perPage >= 9999 ? authored : authored.slice(startIdx, startIdx + perPage);
        return '<div class="cards-grid-newspaper">' + paged.map(renderArticleCardHtml).join('') + '</div>' +
          renderPaginationBarHtml(authored.length, profileCurrentPage, perPage, 'goToProfilePage');
      })() +
    '</div>';
  }

  function buildAllContributorsDirectoryHtml() {
    var pubUsers = getPublicContributorsList();
    var cards = pubUsers.map(function(u) {
      var count = state.articles.filter(function(a) {
        return a.status === 'published' && a.authorId === u.id;
      }).length;
      return '<div style="background:#faf7f0;border:1px solid #d5cdbc;padding:26px;display:flex;flex-direction:column;justify-content:space-between;gap:16px;">' +
        '<div style="display:flex;align-items:center;gap:16px;cursor:pointer;" onclick="openContributorProfile(\'' + u.id + '\')">' +
          '<img src="' + resolvePhoto(u.avatar) + '" alt="' + escapeHtml(u.name) + '" style="width:72px;height:72px;border-radius:50%;object-fit:cover;border:2px solid var(--navy-dark);background:var(--navy-dark);"/>' +
          '<div>' +
            '<div style="font-weight:700;font-size:17px;color:var(--ink-black);">' + escapeHtml(u.name) + '</div>' +
            '<div class="kicker-red" style="font-size:10px;margin:3px 0;">' + escapeHtml(u.role) + '</div>' +
          '</div>' +
        '</div>' +
        '<p style="font-weight:400;font-size:14px;line-height:1.55;color:#454952;margin:0;">' + escapeHtml(u.bio) + '</p>' +
        '<div style="border-top:1px solid #e2dac9;padding-top:12px;display:flex;align-items:center;justify-content:space-between;">' +
          '<span style="font-size:12.5px;font-weight:600;color:var(--navy-dark);">' + count + ' Published Essays across 13 Beats</span>' +
          '<button type="button" class="link-underlined" onclick="openContributorProfile(\'' + u.id + '\')">View essays &#8599;</button>' +
        '</div>' +
      '</div>';
    }).join('');

    return '<div class="journal-section" style="padding-top:32px;">' +
      '<div class="journal-header">' +
        '<h2>Our Writers &amp; Contributors</h2>' +
        '<button type="button" class="write-for-us-highlight" onclick="openWriteForUsModal()">&#9998; Write for Us &#8599;</button>' +
      '</div>' +
      '<div class="cards-grid-newspaper">' + cards + '</div>' +
    '</div>';
  }

  // ============================================================================
  // WORDPRESS / ELEMENTOR-STYLE CMS CONTROL PANEL (WITH HIDDEN SUPER ADMIN,
  // CHAIRMAN TREASURY, US CORPORATE CREDIT CARDS, EMAIL VERIFICATION & CUSTOM HTML)
  // ============================================================================
  window.fillCmsCredentials = function(uname, pass) {
    var uEl = document.getElementById('cmsLoginUsername');
    var pEl = document.getElementById('cmsLoginPassword');
    if (uEl) uEl.value = uname;
    if (pEl) pEl.value = pass;
  };

  window.handleCmsLogin = function() {
    var uVal = (document.getElementById('cmsLoginUsername').value || '').trim();
    var pVal = (document.getElementById('cmsLoginPassword').value || '').trim();
    var found = null;
    var normU = uVal.toLowerCase().replace(/\s+/g, '');
    for (var i = 0; i < state.users.length; i++) {
      var u = state.users[i];
      var candU = (u.username || '').toLowerCase().replace(/\s+/g, '');
      var candName = (u.name || '').toLowerCase().replace(/\s+/g, '');
      if ((candU === normU || candName === normU) && u.password === pVal) {
        found = u;
        break;
      }
    }
    if (!found) {
      showToast('Invalid username or password. Please verify your CMS credentials.');
      return;
    }
    if (!found.canLogin || found.status === 'pending_approval') {
      showToast('This Contributor profile is for public byline attribution only (no CMS login access).');
      return;
    }
    currentUser = found;
    activeCmsTab = 'overview';
    showToast('Signed in to CMS Control Panel as ' + found.name + ' (' + found.role + ').');
    renderMainView();
  };

  window.handleCmsLogout = function() {
    currentUser = null;
    editingArticleId = null;
    editingSubmissionId = null;
    showToast('Signed out of CMS Control Panel.');
    renderMainView();
  };

  window.switchCmsTab = function(tabName) {
    activeCmsTab = tabName;
    if (tabName !== 'editor') editingArticleId = null;
    renderMainView();
  };

  window.insertElementorWidget = function(widgetType) {
    var area = document.getElementById('cmsEditorBody');
    if (!area) return;
    var snippet = '';
    if (widgetType === 'lead') {
      snippet = '<p class="lead-para">Enter your opening lead paragraph here with classic drop-cap styling.</p>\n';
    } else if (widgetType === 'quote') {
      snippet = '<blockquote>"Insert an incisive reflection or pull-quote from your essay here."</blockquote>\n';
    } else if (widgetType === 'h3') {
      snippet = '<h3>Section Subheading Title</h3>\n<p>Continue your analytical narrative under this subheading.</p>\n';
    } else if (widgetType === 'callout') {
      snippet = '<div style="background:#ebe4d4;border-left:4px solid #060d3a;padding:16px 20px;margin:20px 0;"><strong>Historical &amp; Policy Context:</strong> Summarize essential archival or economic background here.</div>\n';
    } else if (widgetType === 'divider') {
      snippet = '<hr style="border:none;border-top:2px double #181c26;margin:28px 0;"/>\n';
    }
    area.value = (area.value || '') + '\n' + snippet;
    showToast('Inserted Elementor block: ' + widgetType.toUpperCase());
  };

  window.startEditArticleInCms = function(artId) {
    var art = state.articles.find(function(a) { return a.id === artId; });
    if (!art || !canEditOrDeleteArticle(art)) {
      showToast('You only have permission to edit your own articles or pending contributor submissions.');
      return;
    }
    editingArticleId = artId;
    tempCmsFeaturedUri = '';
    activeCmsTab = 'editor';
    renderMainView();
  };

  window.onCmsMultiCatChange = function() {
    var primaryEl = document.getElementById('cmsArtCategory');
    var primaryCat = primaryEl ? primaryEl.value : 'Weekline Exclusive';
    var checks = document.querySelectorAll('input[name="cmsArtMultiCat"]:checked');
    var chosen = [primaryCat];
    for (var i = 0; i < checks.length; i++) {
      var v = checks[i].value;
      if (v && chosen.indexOf(v) === -1) chosen.push(v);
    }
    var prevBox = document.getElementById('cmsMultiCatLivePreview');
    if (prevBox) {
      prevBox.innerHTML = chosen.map(function(c) {
        return '<span class="cat-badge-bold" style="cursor:default;"><strong>' + escapeHtml(c) + '</strong></span>';
      }).join(' ');
    }
  };

  window.addNewCustomCategoryInCms = function() {
    var inp = document.getElementById('cmsNewCustomCategoryInput');
    var newCat = inp ? (inp.value || '').trim() : '';
    if (!newCat) {
      showToast('Enter a category name to add.');
      return;
    }
    if (state.categories.indexOf(newCat) === -1) {
      state.categories.push(newCat);
      saveState();
      syncCategoryNavBarDom();
      showToast('Added new category "' + newCat + '" to website & CMS!');
      renderMainView();
    } else {
      showToast('Category "' + newCat + '" already exists.');
    }
  };

  window.toggleQuickMultiCatEditor = function(artId) {
    editingMultiCatArtId = (editingMultiCatArtId === artId) ? null : artId;
    renderMainView();
  };

  window.saveQuickMultiCatForArticle = function(artId) {
    var art = state.articles.find(function(a) { return a.id === artId; });
    if (!art || !canEditOrDeleteArticle(art)) return;
    var checks = document.querySelectorAll('input[name="quickCat_' + artId + '"]:checked');
    var selected = [];
    for (var i = 0; i < checks.length; i++) {
      selected.push(checks[i].value);
    }
    if (selected.length === 0) {
      showToast('Please select at least 1 category for the article.');
      return;
    }
    art.categories = selected;
    art.category = selected[0];
    editingMultiCatArtId = null;
    saveState();
    showToast('Updated bold categories for "' + art.title.slice(0, 32) + '..." (' + selected.join(' · ') + ')!');
    renderMainView();
  };

  window.saveOrPublishCmsArticle = function() {
    var title = (document.getElementById('cmsArtTitle').value || '').trim();
    var subtitle = (document.getElementById('cmsArtSubtitle').value || '').trim();
    var primaryCategory = document.getElementById('cmsArtCategory').value || 'Weekline Exclusive';
    var multiChecks = document.querySelectorAll('input[name="cmsArtMultiCat"]:checked');
    var selectedCategories = [primaryCategory];
    for (var cIdx = 0; cIdx < multiChecks.length; cIdx++) {
      var cVal = multiChecks[cIdx].value;
      if (cVal && selectedCategories.indexOf(cVal) === -1) {
        selectedCategories.push(cVal);
      }
    }
    var category = selectedCategories[0];
    var authorId = document.getElementById('cmsArtAuthorId').value;
    var pubDate = document.getElementById('cmsArtDate').value || '2026-10-25';
    var readTime = (document.getElementById('cmsArtReadTime').value || '6 min read').trim();
    var status = document.getElementById('cmsArtStatus').value;
    var isHero = document.getElementById('cmsArtIsHero').checked;
    var seoTitle = (document.getElementById('cmsArtSeoTitle').value || '').trim();
    var seoDesc = (document.getElementById('cmsArtSeoDesc').value || '').trim();
    var seoKw = (document.getElementById('cmsArtSeoKeywords').value || '').trim();
    var bodyVal = (document.getElementById('cmsEditorBody').value || '').trim();
    var customHtmlEl = document.getElementById('cmsArtCustomHtml');
    var customHtmlVal = customHtmlEl ? (customHtmlEl.value || '').trim() : '';

    if (!title || !bodyVal) {
      showToast('Headline and essay body are required to publish.');
      return;
    }

    if (isHero && canManageEditorial()) {
      for (var i = 0; i < state.articles.length; i++) {
        state.articles[i].isHero = false;
      }
    }

    var formattedBody = bodyVal.indexOf('<p') !== -1 ? bodyVal : ('<p class="lead-para">' + bodyVal.split(/\n\n+/).join('</p><p>') + '</p>');

    if (editingArticleId) {
      var existing = state.articles.find(function(a) { return a.id === editingArticleId; });
      if (existing && canEditOrDeleteArticle(existing)) {
        existing.title = title;
        existing.subtitle = subtitle;
        existing.category = category;
        existing.categories = selectedCategories;
        if (isLoggedSuperAdmin() || canManageEditorial()) existing.authorId = authorId;
        existing.date = pubDate;
        existing.readTime = readTime;
        existing.status = status;
        existing.isHero = isHero;
        existing.seoTitle = seoTitle || (title + ' | ' + selectedCategories.join(' · '));
        existing.seoDescription = seoDesc || subtitle;
        existing.seoKeywords = seoKw || selectedCategories.join(', ').toLowerCase();
        existing.customHtml = customHtmlVal;
        existing.body = formattedBody;
        if (tempCmsFeaturedUri) existing.featuredImage = tempCmsFeaturedUri;
      }
      showToast('Updated article "' + title + '" with categories: ' + selectedCategories.join(' · ') + '!');
    } else {
      var newArt = {
        id: 'art_cms_' + Date.now(),
        title: title,
        subtitle: subtitle || 'Published in the Sunday edition.',
        category: category,
        categories: selectedCategories,
        authorId: authorId,
        date: pubDate,
        readTime: readTime,
        isHero: isHero,
        views: 0,
        isOriginalCard: false,
        highlightRed: false,
        featuredImage: tempCmsFeaturedUri || '@photo:p_maritime',
        seoTitle: seoTitle || (title + ' | ' + selectedCategories.join(' · ')),
        seoDescription: seoDesc || subtitle,
        seoKeywords: seoKw || selectedCategories.join(', ').toLowerCase(),
        status: status,
        customHtml: customHtmlVal,
        body: formattedBody
      };
      state.articles.unshift(newArt);
      showToast('Published new essay "' + title + '" under ' + selectedCategories.join(' · ') + '!');
    }

    editingArticleId = null;
    tempCmsFeaturedUri = '';
    saveState();
    activeCmsTab = 'articles';
    renderMainView();
  };

  window.quickReassignArticleAuthor = function(artId, newAuthorId) {
    if (!isLoggedSuperAdmin()) {
      showToast('Only the Master Super Admin can reassign article User IDs across all accounts.');
      return;
    }
    var art = state.articles.find(function(a) { return a.id === artId; });
    var u = getUserById(newAuthorId);
    if (art && u) {
      art.authorId = newAuthorId;
      saveState();
      showToast('Assigned "' + art.title.slice(0, 32) + '..." to ' + u.name + '!');
      renderMainView();
    }
  };

  window.quickChangeArticleDate = function(artId, newDate) {
    var art = state.articles.find(function(a) { return a.id === artId; });
    if (!art || !canEditOrDeleteArticle(art)) return;
    if (newDate) {
      art.date = newDate;
      saveState();
      showToast('Updated publication date for "' + art.title.slice(0, 32) + '..." to ' + newDate + '!');
      renderMainView();
    }
  };

  window.deleteArticleInCms = function(artId) {
    var art = state.articles.find(function(a) { return a.id === artId; });
    if (!art || !canEditOrDeleteArticle(art)) {
      showToast('You do not have permission to delete this article.');
      return;
    }
    state.articles = state.articles.filter(function(a) { return a.id !== artId; });
    saveState();
    showToast('Article deleted.');
    renderMainView();
  };

  // Pending Submissions & Temporary Contributor Profile Approval / Editing / Deletion
  window.startEditSubmissionInCms = function(subId) {
    editingSubmissionId = (editingSubmissionId === subId) ? null : subId;
    renderMainView();
  };

  window.saveEditedSubmissionInCms = function(subId) {
    var sub = state.submissions.find(function(s) { return s.id === subId; });
    if (!sub) return;
    var nameEl = document.getElementById('editSubName_' + subId);
    var bioEl = document.getElementById('editSubBio_' + subId);
    var headEl = document.getElementById('editSubHead_' + subId);
    var catEl = document.getElementById('editSubCat_' + subId);
    var bodyEl = document.getElementById('editSubBody_' + subId);

    if (nameEl) sub.contributorName = nameEl.value.trim();
    if (bioEl) sub.contributorBio = bioEl.value.trim();
    if (headEl) sub.headline = headEl.value.trim();
    if (catEl) sub.category = catEl.value;
    if (bodyEl) sub.body = bodyEl.value.trim();

    if (sub.contributorUserId) {
      var u = getUserById(sub.contributorUserId);
      if (u) {
        u.name = sub.contributorName;
        u.bio = sub.contributorBio;
      }
    }
    editingSubmissionId = null;
    saveState();
    showToast('Updated pending contributor profile & essay submission!');
    renderMainView();
  };

  window.deleteSubmissionInCms = function(subId) {
    var sub = state.submissions.find(function(s) { return s.id === subId; });
    if (sub && sub.contributorUserId) {
      var u = getUserById(sub.contributorUserId);
      if (u && u.status === 'pending_approval') {
        state.users = state.users.filter(function(usr) { return usr.id !== u.id; });
      }
    }
    state.submissions = state.submissions.filter(function(s) { return s.id !== subId; });
    saveState();
    showToast('Deleted submission and temporary contributor profile.');
    renderMainView();
  };

  window.approveSubmissionInCms = function(subId) {
    var sub = state.submissions.find(function(s) { return s.id === subId; });
    if (!sub) return;

    var contribUser = sub.contributorUserId ? getUserById(sub.contributorUserId) : null;
    if (!contribUser) {
      contribUser = state.users.find(function(u) {
        return u.name.toLowerCase() === sub.contributorName.toLowerCase() && !u.isHiddenSuper;
      });
    }
    if (!contribUser) {
      contribUser = {
        id: 'u_contrib_' + Date.now(),
        username: sub.contributorName.toLowerCase().replace(/[^a-z0-9]/g, '_') + '_public',
        password: '',
        name: sub.contributorName,
        role: 'Public Contributor',
        accessLevel: 'Public Profile & Byline Only (Zero CMS Login Access)',
        canLogin: false,
        isHiddenSuper: false,
        email: sub.contributorEmail,
        emailVerified: true,
        status: 'active',
        bio: sub.contributorBio,
        avatar: sub.contributorAvatar || '@photo:weekline_icon'
      };
      state.users.push(contribUser);
    } else {
      contribUser.status = 'active';
      contribUser.role = 'Public Contributor';
      contribUser.name = sub.contributorName;
      contribUser.bio = sub.contributorBio;
    }

    var subCats = (Array.isArray(sub.categories) && sub.categories.length) ? sub.categories : [sub.category || 'Analysis'];
    var newArt = {
      id: 'art_sub_' + Date.now(),
      title: sub.headline,
      subtitle: sub.subtitle,
      category: subCats[0],
      categories: subCats,
      authorId: contribUser.id,
      date: '2026-10-25',
      readTime: '6 min read',
      isHero: false,
      isOriginalCard: false,
      highlightRed: false,
      featuredImage: sub.featuredImage,
      seoTitle: sub.headline + ' | ' + sub.category,
      seoDescription: sub.subtitle,
      seoKeywords: sub.category.toLowerCase() + ', ' + sub.contributorName,
      status: 'published',
      customHtml: sub.customHtml || '',
      body: sub.body
    };

    state.articles.unshift(newArt);
    sub.status = 'approved';
    saveState();
    showToast('Approved & published under ' + contribUser.name + ' (Public Contributor profile activated)!');
    renderMainView();
  };

  window.approvePendingUserProfileDirectly = function(uid) {
    var u = getUserById(uid);
    if (!u) return;
    u.status = 'active';
    if (u.role.indexOf('Waiting') !== -1) u.role = 'Public Contributor';
    saveState();
    showToast('Approved contributor profile for ' + u.name + '!');
    renderMainView();
  };

  window.deleteUserProfileInCms = function(uid) {
    var u = getUserById(uid);
    if (!u || u.isHiddenSuper || u.id === 'u_weekline_desk') {
      showToast('Core system desk accounts cannot be deleted.');
      return;
    }
    state.users = state.users.filter(function(item) { return item.id !== uid; });
    saveState();
    showToast('Removed user profile: ' + u.name);
    renderMainView();
  };

  // Treasury Management (Super Admin & Chairman ID)
  window.addPaymentMethodInCms = function() {
    if (!isLoggedChairmanOrSuper()) {
      showToast('Only the Master Super Admin or Chairman ID can modify Treasury Cards & Bank Accounts.');
      return;
    }
    var cat = document.getElementById('newPmCategory').value;
    var title = (document.getElementById('newPmTitle').value || '').trim();
    var provider = (document.getElementById('newPmProvider').value || '').trim();
    var accName = (document.getElementById('newPmAccName').value || 'CSB NEWS USA LLC').trim();
    var accNum = (document.getElementById('newPmAccNum').value || '').trim();
    var routing = (document.getElementById('newPmRouting').value || '').trim();
    var instr = (document.getElementById('newPmInstructions').value || '').trim();

    if (!title || !provider || !accNum) {
      showToast('Please enter Card/Bank Title, Issuing Bank/Network, and Account/Corporate Card Number.');
      return;
    }

    state.paymentConfig.methods.unshift({
      id: 'pm_' + Date.now(),
      category: cat,
      title: title,
      provider: provider,
      accountName: accName,
      accountNumber: accNum,
      routingOrSwift: routing || 'Verified Official CSB NEWS USA LLC Account',
      instructions: instr || 'Official receiving account for CSB NEWS USA LLC.',
      active: true
    });
    saveState();
    showToast('Added new ' + cat + ' receiving channel (' + title + ') to Support Us!');
    renderMainView();
  };

  window.togglePaymentMethodActive = function(pmId) {
    if (!isLoggedSuperAdmin()) {
      showToast('Only the Master Super Admin ID can pause or remove cards and bank accounts.');
      return;
    }
    var m = state.paymentConfig.methods.find(function(x) { return x.id === pmId; });
    if (m) {
      m.active = !m.active;
      saveState();
      showToast('Updated status for ' + m.title);
      renderMainView();
    }
  };

  window.deletePaymentMethodInCms = function(pmId) {
    if (!isLoggedSuperAdmin()) {
      showToast('Only the Master Super Admin ID can remove cards and bank accounts.');
      return;
    }
    state.paymentConfig.methods = state.paymentConfig.methods.filter(function(x) { return x.id !== pmId; });
    saveState();
    showToast('Removed payment channel from Treasury.');
    renderMainView();
  };

  window.handleNewUserAvatarUpload = function(inputEl, mode) {
    if (!inputEl || !inputEl.files || !inputEl.files[0]) return;
    var file = inputEl.files[0];
    var sizeKB = Math.round(file.size / 1024);
    if (file.size > 300 * 1024) {
      inputEl.value = '';
      showToast('Profile picture is ' + sizeKB + ' KB. Must be less than 300 KB (any file).');
      return;
    }
    var reader = new FileReader();
    reader.onload = function(evt) {
      if (mode === 'profile') tempProfileAvatarUri = evt.target.result;
      else tempNewUserAvatarUri = evt.target.result;
      showToast('Verified profile photo (' + sizeKB + ' KB < 300 KB limit).');
    };
    reader.readAsDataURL(file);
  };

  window.createNewCmsUser = function() {
    var name = (document.getElementById('newUserName').value || '').trim();
    var uname = (document.getElementById('newUserUsername').value || '').trim();
    var pass = (document.getElementById('newUserPassword').value || '').trim();
    var role = document.getElementById('newUserRole').value;
    var email = (document.getElementById('newUserEmail').value || '').trim();
    var bio = (document.getElementById('newUserBio').value || '').trim();

    if (!name || !uname || !bio) {
      showToast('Please enter Full Name, Username, and Short Biography.');
      return;
    }

    var isPublicOnly = (role === 'Public Contributor (No Login)');
    var newU = {
      id: 'u_custom_' + Date.now(),
      username: uname,
      password: isPublicOnly ? '' : (pass || 'WeeklineUser@2026'),
      name: name,
      role: role,
      accessLevel: isPublicOnly ? 'Public Byline Only (No CMS Login)' : 'Partial Access (' + role + ')',
      canLogin: !isPublicOnly,
      isHiddenSuper: false,
      email: email || (uname.toLowerCase() + '@csbnewsusallc.news'),
      emailVerified: false,
      status: 'active',
      bio: bio,
      avatar: tempNewUserAvatarUri || '@photo:weekline_icon'
    };

    state.users.push(newU);
    tempNewUserAvatarUri = '';
    saveState();
    showToast('Created new ' + role + ' ID: ' + uname + '! Click "Verify Email" to send confirmation code.');
    renderMainView();
  };

  window.saveMyProfileAndPassword = function() {
    if (!currentUser) return;
    var newName = (document.getElementById('myProfName').value || '').trim();
    var unameEl = document.getElementById('myProfUsername');
    var newUname = unameEl ? (unameEl.value || '').trim() : '';
    var newEmail = (document.getElementById('myProfEmail').value || '').trim();
    var newBio = (document.getElementById('myProfBio').value || '').trim();
    var newPass = (document.getElementById('myProfNewPass').value || '').trim();

    if (newName) currentUser.name = newName;
    if (newUname && !currentUser.isHiddenSuper) currentUser.username = newUname;
    if (newEmail && newEmail !== currentUser.email) {
      currentUser.email = newEmail;
      currentUser.emailVerified = false;
    }
    if (newBio) currentUser.bio = newBio;
    if (tempProfileAvatarUri) {
      currentUser.avatar = tempProfileAvatarUri;
      tempProfileAvatarUri = '';
    }
    if (newPass) {
      currentUser.password = newPass;
    }
    saveState();
    showToast('Profile details' + (newPass ? ' and new password' : '') + ' saved!');
    renderMainView();
  };

  window.saveGlobalSeoAndSocial = function() {
    state.seoConfig.siteTitle = (document.getElementById('seoSiteTitle').value || '').trim();
    state.seoConfig.metaDescription = (document.getElementById('seoMetaDesc').value || '').trim();
    state.seoConfig.metaKeywords = (document.getElementById('seoMetaKeywords').value || '').trim();
    state.seoConfig.canonicalUrl = (document.getElementById('seoCanonicalUrl').value || '').trim();
    state.seoConfig.editorialEmail = (document.getElementById('seoEditorialEmail').value || 'editorial@csbnewsusallc.news').trim();

    PLATFORM_META.forEach(function(p) {
      var el = document.getElementById('socialLink_' + p.key);
      if (el) state.socialLinks[p.key] = el.value.trim();
    });

    document.title = state.seoConfig.siteTitle;
    saveState();
    renderFooterSocialButtons();
    showToast('Global SEO & all 7 official Social Platform Links saved!');
  };

  // ============================================================================
  // SITE CUSTOMIZER, MOTTO/TEXT/COVER/DP EDITOR, DRAG-AND-DROP BLOCK BUILDER,
  // MOTION ADS STUDIO & ONE-CLICK EXCELLENT SEO OPTIMIZER
  // ============================================================================
  window.saveSiteTextAndMottoConfig = function() {
    if (!isLoggedSuperAdmin()) {
      showToast('Only the Master Super Admin ID can edit global website motto, labels, and design.');
      return;
    }
    ensureSiteAndAdsConfig();
    var sc = state.siteConfig;
    var valOf = function(id, fallback) {
      var el = document.getElementById(id);
      return el ? (el.value || '').trim() : fallback;
    };
    sc.topRibbonText = valOf('custTopRibbon', sc.topRibbonText);
    sc.mastheadLeftKicker = valOf('custLeftKicker', sc.mastheadLeftKicker);
    sc.mastheadLeftQuote = valOf('custLeftQuote', sc.mastheadLeftQuote);
    sc.mastheadBrandTitle = valOf('custBrandTitle', sc.mastheadBrandTitle);
    sc.mastheadSubtitle = valOf('custBrandSub', sc.mastheadSubtitle);
    sc.mastheadRightMotto = valOf('custRightMotto', sc.mastheadRightMotto);
    sc.mastheadSupportLabel = valOf('custSupportLabel', sc.mastheadSupportLabel);
    sc.navWriteForUsLabel = valOf('custWriteLabel', sc.navWriteForUsLabel);
    sc.navContributorsLabel = valOf('custContribLabel', sc.navContributorsLabel);
    sc.navEditorialDeskLabel = valOf('custDeskLabel', sc.navEditorialDeskLabel);
    sc.exploreJournalLabel = valOf('custExploreLabel', sc.exploreJournalLabel);
    sc.heroSectionKicker = valOf('custHeroKicker', sc.heroSectionKicker);
    sc.archiveSectionTitle = valOf('custArchiveTitle', sc.archiveSectionTitle);
    sc.archiveSectionSub = valOf('custArchiveSub', sc.archiveSectionSub);
    sc.promoKicker = valOf('custPromoKicker', sc.promoKicker);
    sc.promoHeading = valOf('custPromoHeading', sc.promoHeading);
    sc.promoBody = valOf('custPromoBody', sc.promoBody);
    sc.footerTagline = valOf('custFooterTagline', sc.footerTagline);
    sc.footerContactLabel = valOf('custFooterContact', sc.footerContactLabel);
    sc.coverBgColor = valOf('custCoverColor', sc.coverBgColor || '#060d3a');
    var perP = parseInt(valOf('custPerPage', '12'), 10);
    if (perP > 0) sc.articlesPerPage = perP;

    applySiteConfigToDom();
    saveState();
    showToast('Saved all website motto, text labels, cover color & multi-page settings live!');
    renderMainView();
  };

  window.handleCoverOrLogoUpload = function(inputEl, targetMode) {
    if (!isLoggedSuperAdmin() || !inputEl || !inputEl.files || !inputEl.files[0]) return;
    ensureSiteAndAdsConfig();
    var file = inputEl.files[0];
    var reader = new FileReader();
    reader.onload = function(evt) {
      var img = new Image();
      img.onload = function() {
        var c = document.createElement('canvas');
        var maxW = targetMode === 'cover' ? 1200 : 256;
        var scale = img.width > maxW ? (maxW / img.width) : 1;
        c.width = Math.round(img.width * scale);
        c.height = Math.round(img.height * scale);
        var ctx = c.getContext('2d');
        ctx.drawImage(img, 0, 0, c.width, c.height);
        var webpOut = c.toDataURL('image/webp', 0.85);
        if (targetMode === 'cover') {
          state.siteConfig.coverBgImage = webpOut;
          showToast('Updated Masthead Cover Background Photo!');
        } else if (targetMode === 'logo') {
          state.siteConfig.siteLogo = webpOut;
          state.siteConfig.siteFavicon = webpOut;
          showToast('Updated Website Logo & Google Search Favicon Icon!');
        } else if (targetMode === 'deskdp') {
          state.siteConfig.defaultDeskDp = webpOut;
          var deskU = getUserById('u_weekline_desk');
          if (deskU) deskU.avatar = webpOut;
          showToast('Updated Default Editorial Desk DP Icon!');
        }
        applySiteConfigToDom();
        saveState();
        renderMainView();
      };
      img.src = evt.target.result;
    };
    reader.readAsDataURL(file);
  };

  window.resetCoverToDefaultNavy = function() {
    if (!isLoggedSuperAdmin()) return;
    ensureSiteAndAdsConfig();
    state.siteConfig.coverBgImage = '';
    state.siteConfig.coverBgColor = '#060d3a';
    applySiteConfigToDom();
    saveState();
    showToast('Reset Masthead Cover to Classic Editorial Navy (#060d3a).');
    renderMainView();
  };

  window.moveHomepageSectionOrder = function(index, dir) {
    if (!isLoggedSuperAdmin()) return;
    ensureSiteAndAdsConfig();
    var arr = state.siteConfig.sectionOrder;
    var target = index + dir;
    if (target < 0 || target >= arr.length) return;
    var tmp = arr[index];
    arr[index] = arr[target];
    arr[target] = tmp;
    saveState();
    showToast('Updated Homepage section order!');
    renderMainView();
  };

  window.onSectionDragStart = function(idx) {
    draggedSectionIndex = idx;
  };
  window.onSectionDragOver = function(evt) {
    if (evt && evt.preventDefault) evt.preventDefault();
  };
  window.onSectionDrop = function(targetIdx) {
    if (!isLoggedSuperAdmin() || draggedSectionIndex === null || draggedSectionIndex === targetIdx) return;
    ensureSiteAndAdsConfig();
    var arr = state.siteConfig.sectionOrder;
    var moved = arr.splice(draggedSectionIndex, 1)[0];
    arr.splice(targetIdx, 0, moved);
    draggedSectionIndex = null;
    saveState();
    showToast('Reordered Homepage sections via drag-and-drop!');
    renderMainView();
  };

  window.handleCustomBlockImgUpload = function(inputEl) {
    if (!inputEl || !inputEl.files || !inputEl.files[0]) return;
    var file = inputEl.files[0];
    var reader = new FileReader();
    reader.onload = function(evt) {
      var img = new Image();
      img.onload = function() {
        var c = document.createElement('canvas');
        var scale = img.width > 800 ? (800 / img.width) : 1;
        c.width = Math.round(img.width * scale);
        c.height = Math.round(img.height * scale);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        tempCustomBlockImgUri = c.toDataURL('image/webp', 0.84);
        showToast('Uploaded custom block visual (.webp ready).');
      };
      img.src = evt.target.result;
    };
    reader.readAsDataURL(file);
  };

  window.addNewCustomPageBlock = function() {
    if (!isLoggedSuperAdmin()) return;
    ensureSiteAndAdsConfig();
    var bType = document.getElementById('newBlkType').value;
    var bZone = document.getElementById('newBlkZone').value;
    var kicker = (document.getElementById('newBlkKicker').value || 'EDITORIAL FEATURE BLOCK').trim();
    var title = (document.getElementById('newBlkTitle').value || '').trim();
    var desc = (document.getElementById('newBlkDesc').value || '').trim();
    var ctaText = (document.getElementById('newBlkCtaText').value || '').trim();
    var ctaAct = (document.getElementById('newBlkCtaAction').value || 'write_for_us').trim();
    var bgCol = (document.getElementById('newBlkBgColor').value || '#f4efe4').trim();
    var codeHtml = (document.getElementById('newBlkCodeHtml').value || '').trim();

    if (bType === 'code' && !codeHtml) {
      showToast('Please paste custom HTML/CSS/JS code for the code block.');
      return;
    }
    if (bType === 'visual' && !title) {
      showToast('Please enter a headline for the visual block.');
      return;
    }

    state.siteConfig.customBlocks.push({
      id: 'blk_' + Date.now(),
      zone: bZone,
      type: bType,
      kicker: kicker,
      title: title || 'Custom Code Block',
      description: desc,
      imageUrl: tempCustomBlockImgUri || '',
      ctaText: ctaText,
      ctaAction: ctaAct,
      customHtml: codeHtml,
      bgColor: bgCol,
      active: true
    });
    tempCustomBlockImgUri = '';
    saveState();
    showToast('Added new custom page block to website (' + bZone.toUpperCase() + ' zone)!');
    renderMainView();
  };

  window.toggleCustomPageBlock = function(blkId) {
    if (!isLoggedSuperAdmin()) return;
    ensureSiteAndAdsConfig();
    var b = state.siteConfig.customBlocks.find(function(x) { return x.id === blkId; });
    if (b) {
      b.active = !b.active;
      saveState();
      renderMainView();
    }
  };

  window.deleteCustomPageBlock = function(blkId) {
    if (!isLoggedSuperAdmin()) return;
    ensureSiteAndAdsConfig();
    state.siteConfig.customBlocks = state.siteConfig.customBlocks.filter(function(x) { return x.id !== blkId; });
    saveState();
    showToast('Removed custom block.');
    renderMainView();
  };

  window.moveCustomPageBlock = function(idx, dir) {
    if (!isLoggedSuperAdmin()) return;
    ensureSiteAndAdsConfig();
    var arr = state.siteConfig.customBlocks;
    var target = idx + dir;
    if (target < 0 || target >= arr.length) return;
    var tmp = arr[idx];
    arr[idx] = arr[target];
    arr[target] = tmp;
    saveState();
    renderMainView();
  };

  // Motion Ads Studio Handlers
  window.toggleGlobalAdsEnabled = function() {
    if (!isLoggedChairmanOrSuper()) return;
    ensureSiteAndAdsConfig();
    state.adsConfig.enabled = !state.adsConfig.enabled;
    saveState();
    showToast('Motion Advertisements are now ' + (state.adsConfig.enabled ? 'ENABLED' : 'PAUSED') + ' site-wide.');
    renderMainView();
  };

  window.handleMotionAdImgUpload = function(inputEl) {
    if (!inputEl || !inputEl.files || !inputEl.files[0]) return;
    var file = inputEl.files[0];
    var reader = new FileReader();
    reader.onload = function(evt) {
      var img = new Image();
      img.onload = function() {
        var c = document.createElement('canvas');
        var scale = img.width > 800 ? (800 / img.width) : 1;
        c.width = Math.round(img.width * scale);
        c.height = Math.round(img.height * scale);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        tempMotionAdImgUri = c.toDataURL('image/webp', 0.84);
        showToast('Uploaded Motion Ad visual (.webp ready).');
      };
      img.src = evt.target.result;
    };
    reader.readAsDataURL(file);
  };

  window.addNewMotionAdvertisement = function() {
    if (!isLoggedChairmanOrSuper()) return;
    ensureSiteAndAdsConfig();
    var slot = document.getElementById('newAdSlot').value;
    var motionStyle = document.getElementById('newAdMotionStyle').value;
    var sponsor = (document.getElementById('newAdSponsor').value || 'OFFICIAL PARTNER').trim();
    var kicker = (document.getElementById('newAdKicker').value || 'SPONSORED MOTION SPOTLIGHT').trim();
    var headline = (document.getElementById('newAdHeadline').value || '').trim();
    var subtext = (document.getElementById('newAdSubtext').value || '').trim();
    var ctaText = (document.getElementById('newAdCtaText').value || 'Explore Offer ↗').trim();
    var targetUrl = (document.getElementById('newAdTargetUrl').value || '#').trim();
    var customHtml = (document.getElementById('newAdCustomHtml').value || '').trim();

    if (!headline && !customHtml) {
      showToast('Please enter an Ad Headline or paste Custom Ad HTML.');
      return;
    }

    state.adsConfig.items.unshift({
      id: 'ad_' + Date.now(),
      slot: slot,
      sponsorName: sponsor,
      kicker: kicker,
      headline: headline || 'Custom Sponsor Unit',
      subtext: subtext,
      ctaText: ctaText,
      targetUrl: targetUrl,
      imageUrl: tempMotionAdImgUri || '@artwebp:art_bus_1:bus_1:0:0',
      motionStyle: motionStyle,
      customHtml: customHtml,
      active: true,
      impressions: 1,
      clicks: 0
    });
    tempMotionAdImgUri = '';
    saveState();
    showToast('Published new animated Motion Advertisement (' + sponsor + ')!');
    renderMainView();
  };

  window.toggleMotionAdItem = function(adId) {
    if (!isLoggedChairmanOrSuper()) return;
    ensureSiteAndAdsConfig();
    var ad = state.adsConfig.items.find(function(x) { return x.id === adId; });
    if (ad) {
      ad.active = !ad.active;
      saveState();
      renderMainView();
    }
  };

  window.deleteMotionAdItem = function(adId) {
    if (!isLoggedChairmanOrSuper()) return;
    ensureSiteAndAdsConfig();
    state.adsConfig.items = state.adsConfig.items.filter(function(x) { return x.id !== adId; });
    saveState();
    showToast('Removed advertisement from website.');
    renderMainView();
  };

  // One-Click Excellent SEO Optimizer & Basic SEO Wizard (Master Admin & Chairman)
  window.runOneClickAutoSeoOptimization = function() {
    if (!isLoggedChairmanOrSuper()) return;
    var count = 0;
    state.articles.forEach(function(a) {
      a.seoTitle = a.title + ' | ' + a.category + ' | WEEKLINE · CSB NEWS USA LLC';
      a.seoDescription = (a.subtitle && a.subtitle.length > 30)
        ? a.subtitle
        : (a.title + ' — In-depth Sunday analytical report in ' + a.category + ' published by WEEKLINE | CSB NEWS USA LLC.');
      a.seoKeywords = a.category.toLowerCase() + ', WEEKLINE, CSB NEWS USA LLC, Sunday analytical edition, ' + a.title.split(' ').slice(0, 5).join(', ');
      count++;
    });
    state.seoConfig.siteTitle = 'WEEKLINE | CSB NEWS USA LLC';
    if (!state.seoConfig.metaDescription) {
      state.seoConfig.metaDescription = 'WEEKLINE is an international weekly publication by CSB NEWS USA LLC featuring in-depth analysis, geopolitics, war & conflicts, history, literature, culture, business, and global essays published every Sunday.';
    }
    document.title = state.seoConfig.siteTitle;
    saveState();
    showToast('1-Click SEO Excellence Boost Complete! Optimized all ' + count + ' essays, Google Search JSON-LD Schema & OpenGraph tags (100/100 SEO Score).');
    renderMainView();
  };

  window.runBasicSeoQuickWizard = function() {
    if (!isLoggedChairmanOrSuper()) return;
    var focusEl = document.getElementById('basicSeoFocusInput');
    var focusPhrase = focusEl ? (focusEl.value || '').trim() : '';
    if (!focusPhrase) {
      showToast('Enter a focus topic or keywords in the Quick-Wizard box first.');
      return;
    }
    state.seoConfig.metaKeywords = 'WEEKLINE, CSB NEWS USA LLC, ' + focusPhrase + ', geopolitics, war and conflicts, analysis, history, literature, business, Sunday review';
    state.seoConfig.metaDescription = 'WEEKLINE | CSB NEWS USA LLC — International weekly publication featuring ' + focusPhrase + ', geopolitics, war & conflicts, history, literature, and analytical essays published every Sunday.';
    saveState();
    showToast('Applied Basic SEO Quick-Wizard for "' + focusPhrase + '" across global meta tags!');
    renderMainView();
  };

  window.downloadLiveSitemapXml = function() {
    var base = (state.seoConfig.canonicalUrl || 'https://yourdomain.com/').replace(/\/+$/, '');
    var xml = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
    xml += '  <url><loc>' + escapeHtml(base) + '/</loc><changefreq>weekly</changefreq><priority>1.0</priority></url>\n';
    state.categories.forEach(function(c) {
      xml += '  <url><loc>' + escapeHtml(base) + '/#category/' + encodeURIComponent(c) + '/page/1</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>\n';
    });
    state.articles.forEach(function(a) {
      xml += '  <url><loc>' + escapeHtml(base) + '/#article/' + encodeURIComponent(a.id) + '</loc><lastmod>' + escapeHtml(a.date) + '</lastmod><changefreq>monthly</changefreq><priority>0.9</priority></url>\n';
    });
    xml += '</urlset>';
    var blob = new Blob([xml], { type: 'application/xml' });
    var aEl = document.createElement('a');
    aEl.href = URL.createObjectURL(blob);
    aEl.download = 'sitemap.xml';
    document.body.appendChild(aEl);
    aEl.click();
    document.body.removeChild(aEl);
    showToast('Downloaded fresh sitemap.xml with all ' + state.articles.length + ' reports & ' + state.categories.length + ' categories!');
  };

  // ============================================================================
  // FULL WEBSITE BACKUP, RESTORE & PYTHON 3 CMS ENGINE HANDLERS
  // ============================================================================
  window.downloadFullCmsBackupJson = function() {
    var ts = new Date().toISOString().slice(0, 10);
    var jsonStr = JSON.stringify(state, null, 2);
    var blob = new Blob([jsonStr], { type: 'application/json' });
    var aEl = document.createElement('a');
    aEl.href = URL.createObjectURL(blob);
    aEl.download = 'weekline-full-backup-' + ts + '.json';
    document.body.appendChild(aEl);
    aEl.click();
    document.body.removeChild(aEl);
    showToast('Downloaded full website & CMS database backup (weekline-full-backup-' + ts + '.json)!');
  };

  window.restoreCmsFromUploadedBackup = function(inputEl) {
    if (!inputEl || !inputEl.files || !inputEl.files[0]) return;
    var file = inputEl.files[0];
    var reader = new FileReader();
    reader.onload = function(evt) {
      try {
        var parsed = JSON.parse(evt.target.result);
        if (parsed && Array.isArray(parsed.articles) && Array.isArray(parsed.users)) {
          state = parsed;
          normalizeStateArticlesCategories();
          saveState();
          applySiteConfigToDom();
          syncCategoryNavBarDom();
          showToast('Successfully restored full website database (' + state.articles.length + ' essays & ' + state.users.length + ' user profiles) from backup!');
          renderMainView();
        } else {
          showToast('Invalid backup file format: missing articles or users array.');
        }
      } catch (err) {
        showToast('Error reading backup JSON file.');
      }
    };
    reader.readAsText(file);
  };

  window.triggerServerSnapshotBackup = function() {
    var nowStr = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    var snapName = 'weekline_backup_' + nowStr + '_cms.json';
    serverBackupsList.unshift({
      filename: snapName,
      sizeKB: Math.round(JSON.stringify(state).length / 1024 * 10) / 10,
      modifiedAt: new Date().toUTCString()
    });
    saveState();
    callBackendApi('create_backup', 'POST', {}, function(resp) {
      if (resp && Array.isArray(resp.backups)) {
        serverBackupsList = resp.backups;
        renderMainView();
      }
    });
    showToast('Created new server backup snapshot (' + snapName + ') in Hostinger backups/ folder!');
    renderMainView();
  };

  window.restoreFromServerSnapshot = function(fname) {
    callBackendApi('restore_backup', 'POST', { filename: fname }, function(resp) {
      if (resp && resp.ok && resp.state) {
        state = resp.state;
        normalizeStateArticlesCategories();
        saveStateLocal();
        applySiteConfigToDom();
        syncCategoryNavBarDom();
        showToast('Restored live website from server snapshot: ' + fname);
        renderMainView();
      }
    });
    showToast('Verified server snapshot "' + fname + '" — state synchronized!');
  };

  function buildCmsDashboardHtml() {
    if (!currentUser) {
      // Note: Super Admin credentials are NOT pre-filled or displayed on the public login screen!
      return '<div class="journal-section" style="padding-top:36px;max-width:760px;">' +
        '<div style="background:var(--navy-dark);color:#ffffff;padding:36px;border-top:4px solid var(--accent-red);box-shadow:0 20px 50px rgba(0,0,0,0.2);">' +
          '<div style="display:flex;align-items:center;gap:16px;margin-bottom:20px;">' +
            '<img src="' + resolvePhoto('@photo:weekline_icon') + '" alt="WEEKLINE" style="width:60px;height:60px;border-radius:50%;border:2px solid var(--accent-red);"/>' +
            '<div>' +
              '<div class="kicker-red">CSB NEWS USA LLC · HOSTINGER-READY CMS CONTROL PANEL</div>' +
              '<h2 style="font-family:var(--font-serif);font-size:28px;margin:4px 0 0;">Editorial &amp; Treasury Dashboard Login</h2>' +
            '</div>' +
          '</div>' +
          '<div style="display:grid;gap:16px;margin-bottom:22px;">' +
            '<div>' +
              '<label class="cms-label" style="color:#e45745;" for="cmsLoginUsername">Username</label>' +
              '<input type="text" id="cmsLoginUsername" class="cms-input" placeholder="Enter your CMS Username..." value=""/>' +
            '</div>' +
            '<div>' +
              '<label class="cms-label" style="color:#e45745;" for="cmsLoginPassword">Password</label>' +
              '<input type="password" id="cmsLoginPassword" class="cms-input" placeholder="Enter your CMS Password..." value=""/>' +
            '</div>' +
            '<button type="button" class="btn-red-action" style="justify-content:center;padding:13px;font-size:14px;" onclick="handleCmsLogin()">Sign In to CMS Control Panel &#8599;</button>' +
          '</div>' +
          '<div style="border-top:1px solid rgba(255,255,255,0.18);padding-top:18px;">' +
            '<div style="font-size:11px;text-transform:uppercase;letter-spacing:0.1em;color:#cfd4e2;margin-bottom:10px;">Standard Desk, Chairman &amp; Contributor Quick-Fill (Master Super Admin is Hidden &amp; Private):</div>' +
            '<div style="display:flex;flex-wrap:wrap;gap:10px;">' +
              '<button type="button" class="platform-pill-btn" onclick="fillCmsCredentials(\'WEEKLINE_DESK\', \'WeeklineDesk@CSB2026#Editorial\')">1. WEEKLINE DESK (50 Essays · All 13 Beats)</button>' +
              '<button type="button" class="platform-pill-btn" onclick="fillCmsCredentials(\'MahadiAlMoktadir\', \'MahadiContributor@2026#\')">2. Mahadi Al Moktadir (Contributor · 13 Essays)</button>' +
              '<button type="button" class="platform-pill-btn" onclick="fillCmsCredentials(\'Editor1\', \'Editor1@Weekline2026#\')">3. Editor 1 (Editor1)</button>' +
              '<button type="button" class="platform-pill-btn" onclick="fillCmsCredentials(\'Editor2\', \'Editor2@Weekline2026#\')">4. Editor 2 (Editor2)</button>' +
              '<button type="button" class="platform-pill-btn" onclick="fillCmsCredentials(\'ChairmanCSBNewsUSA\', \'Chairman@CSBNewsUSA2026#\')">5. Chairman ID (Treasury &amp; US Corporate Cards)</button>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';
    }

    var isSuper = isLoggedSuperAdmin();
    var isAdminView = canViewArticleAnalytics();
    var isChairmanOrSuper = isLoggedChairmanOrSuper();
    var isEditorial = canManageEditorial();
    var isContribOnly = (currentUser.role === 'Contributor');
    var pendingCount = state.submissions.filter(function(s) { return s.status === 'pending'; }).length;
    var visibleUsers = getVisibleUsersForCurrentContext();

    var navTabs = [
      { id: 'overview', label: 'Dashboard Overview' },
      { id: 'editor', label: editingArticleId ? 'Edit Essay (Elementor Studio)' : '+ Upload / Publish Essay' },
      { id: 'articles', label: 'Manage Essays (' + state.articles.length + ')' },
      { id: 'submissions', label: 'Write for Us & Pending Profiles (' + pendingCount + ')' }
    ];
    if (isSuper) {
      navTabs.push({ id: 'customizer', label: '🎨 Site Customizer & Drag-Drop Builder' });
    }
    if (isChairmanOrSuper) {
      ensureSiteAndAdsConfig();
      navTabs.push({ id: 'ads', label: '✨ Motion Ads & Sponsors (' + (state.adsConfig.items || []).length + ')' });
      navTabs.push({ id: 'treasury', label: '💳 Cards, Banks & Incoming Funds (' + state.paymentConfig.methods.length + ')' });
      navTabs.push({ id: 'seo', label: '🚀 Excellent SEO & Auto-SEO Studio' });
      navTabs.push({ id: 'backup', label: '🐍 Python CMS & Full Backup' });
    }
    if (isEditorial) {
      navTabs.push({ id: 'users', label: 'User IDs & Email Verification (' + visibleUsers.length + ')' });
    }
    navTabs.push({ id: 'profile', label: 'My Profile & Password' });

    var tabButtons = navTabs.map(function(t) {
      var activeStyle = activeCmsTab === t.id
        ? 'background:var(--accent-red);color:#ffffff;border-color:var(--accent-red);'
        : 'background:#ffffff;color:var(--ink-black);';
      return '<button type="button" class="platform-pill-btn" style="' + activeStyle + 'padding:9px 14px;" onclick="switchCmsTab(\'' + t.id + '\')">' + escapeHtml(t.label) + '</button>';
    }).join('');

    var bodyContent = '';

    if (activeCmsTab === 'overview') {
      var totalSiteViews = state.articles.reduce(function(acc, a) { return acc + (Number(a.views) || 0); }, 0);
      var avgSiteViews = state.articles.length ? Math.round(totalSiteViews / state.articles.length) : 0;
      var catRows = state.categories.map(function(c) {
        var deskInCat = state.articles.filter(function(a) { return articleHasCategory(a, c) && a.authorId === 'u_weekline_desk'; }).length;
        var mahadiInCat = state.articles.filter(function(a) { return articleHasCategory(a, c) && a.authorId === 'u_mahadi_contributor'; }).length;
        var totalInCat = state.articles.filter(function(a) { return articleHasCategory(a, c); }).length;
        var viewsInCat = state.articles.filter(function(a) { return articleHasCategory(a, c); }).reduce(function(s, a) { return s + (Number(a.views) || 0); }, 0);
        var safeJsC = String(c).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
        return '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:12px 14px;display:flex;align-items:center;justify-content:space-between;">' +
          '<div>' +
            '<div style="font-weight:700;font-size:13.5px;">' + escapeHtml(c) + '</div>' +
            '<div style="font-size:11.5px;color:#5a606d;">Desk: ' + deskInCat + ' · Mahadi Al Moktadir: ' + mahadiInCat + (isAdminView ? (' · <strong style="color:#0b2e6b;">&#128065; ' + viewsInCat.toLocaleString() + ' views</strong>') : '') + '</div>' +
          '</div>' +
          '<button type="button" class="platform-pill-btn" onclick="filterByCategory(\'' + safeJsC + '\')">' + totalInCat + ' Essays &#8599;</button>' +
        '</div>';
      }).join('');

      var adminViewsCard = isAdminView
        ? ('<div style="background:#0b2e6b;color:#ffffff;padding:20px;border-top:3px solid #f0b429;">' +
            '<div style="font-size:11px;text-transform:uppercase;letter-spacing:0.1em;color:#dbe7ff;">Live Article Views (Admin ID Only)</div>' +
            '<div style="font-family:var(--font-serif);font-size:32px;font-weight:700;margin:6px 0;">&#128065; ' + totalSiteViews.toLocaleString() + '</div>' +
            '<div style="font-size:12px;color:#f0b429;">Avg ' + avgSiteViews.toLocaleString() + ' views/essay · Hidden from Editors &amp; Public</div>' +
          '</div>')
        : '';

      bodyContent = '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px;margin-bottom:28px;">' +
        '<div style="background:var(--navy-dark);color:#ffffff;padding:20px;border-top:3px solid var(--accent-red);">' +
          '<div style="font-size:11px;text-transform:uppercase;letter-spacing:0.1em;color:#cfd4e2;">Published Long-Form Essays</div>' +
          '<div style="font-family:var(--font-serif);font-size:36px;font-weight:700;margin:6px 0;">' + state.articles.length + '</div>' +
          '<div style="font-size:12px;color:#e45745;">50 WEEKLINE DESK · 13 Mahadi Al Moktadir</div>' +
        '</div>' +
        adminViewsCard +
        '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:20px;">' +
          '<div style="font-size:11px;text-transform:uppercase;letter-spacing:0.1em;color:#5a606d;">Sunday Publication Schedule</div>' +
          '<div style="font-family:var(--font-serif);font-size:22px;font-weight:700;margin:10px 0 6px;color:var(--ink-black);">Aug 8 + Every Sunday</div>' +
          '<div style="font-size:12px;color:#1b6e38;">627–900 words per essay across 13 beats</div>' +
        '</div>' +
        '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:20px;">' +
          '<div style="font-size:11px;text-transform:uppercase;letter-spacing:0.1em;color:#5a606d;">CSB NEWS USA LLC Treasury</div>' +
          '<div style="font-family:var(--font-serif);font-size:22px;font-weight:700;margin:10px 0 6px;color:#1b6e38;">' + state.paymentConfig.methods.length + ' Active Channels</div>' +
          '<div style="font-size:12px;color:#5a606d;">Official US Corporate Cards, US/BD Banks &amp; SWIFT</div>' +
        '</div>' +
      '</div>' +
      '<h3 style="font-family:var(--font-serif);font-size:22px;margin:0 0 14px;">13-Category Coverage Matrix (Education Top-Middle · Unified History, Religion &amp; Culture · Multi-Category Enabled)</h3>' +
      '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px;">' + catRows + '</div>';
    } else if (activeCmsTab === 'editor') {
      var editArt = editingArticleId ? state.articles.find(function(a) { return a.id === editingArticleId; }) : null;
      var selAuthorId = editArt ? editArt.authorId : currentUser.id;
      var authorOpts = visibleUsers.map(function(u) {
        var sel = (u.id === selAuthorId) ? ' selected' : '';
        return '<option value="' + u.id + '"' + sel + '>' + escapeHtml(u.name) + ' (' + escapeHtml(u.role) + ')</option>';
      }).join('');
      var catOpts = state.categories.map(function(c) {
        var sel = (editArt && editArt.category === c) ? ' selected' : '';
        return '<option value="' + escapeHtml(c) + '"' + sel + '>' + escapeHtml(c) + '</option>';
      }).join('');

      bodyContent = '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:24px;">' +
        '<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:20px;border-bottom:1px solid #e2dac9;padding-bottom:14px;">' +
          '<div>' +
            '<div class="kicker-red">WORDPRESS / ELEMENTOR VISUAL ARTICLE STUDIO</div>' +
            '<h3 style="font-family:var(--font-serif);font-size:24px;margin:4px 0 0;">' + (editArt ? 'Editing: ' + escapeHtml(editArt.title) : 'Upload & Publish New Sunday Essay') + '</h3>' +
          '</div>' +
          '<button type="button" class="btn-red-action" onclick="saveOrPublishCmsArticle()">' + (isContribOnly ? 'Publish Contributor Essay &#8599;' : (editArt ? 'Update Essay &#8599;' : 'Publish Essay Now &#8599;')) + '</button>' +
        '</div>' +
        '<div style="display:grid;grid-template-columns:2fr 1fr;gap:24px;">' +
          '<div style="display:flex;flex-direction:column;gap:16px;">' +
            '<div>' +
              '<label class="cms-label">Essay Headline</label>' +
              '<input type="text" id="cmsArtTitle" class="cms-input" placeholder="Enter headline..." value="' + escapeHtml(editArt ? editArt.title : '') + '"/>' +
            '</div>' +
            '<div>' +
              '<label class="cms-label">Subheadline / Analytical Deck</label>' +
              '<input type="text" id="cmsArtSubtitle" class="cms-input" placeholder="Enter analytical deck..." value="' + escapeHtml(editArt ? editArt.subtitle : '') + '"/>' +
            '</div>' +
            '<div>' +
              '<label class="cms-label">Elementor Block Insertion Toolbar</label>' +
              '<div style="display:flex;flex-wrap:wrap;gap:8px;background:#ece5d5;padding:10px;border:1px solid #d5cdbc;">' +
                '<button type="button" class="platform-pill-btn" onclick="insertElementorWidget(\'lead\')">+ Drop-Cap Lead</button>' +
                '<button type="button" class="platform-pill-btn" onclick="insertElementorWidget(\'quote\')">+ Pull-Quote</button>' +
                '<button type="button" class="platform-pill-btn" onclick="insertElementorWidget(\'h3\')">+ Subheading (H3)</button>' +
                '<button type="button" class="platform-pill-btn" onclick="insertElementorWidget(\'callout\')">+ Callout Box</button>' +
                '<button type="button" class="platform-pill-btn" onclick="insertElementorWidget(\'divider\')">+ Divider</button>' +
              '</div>' +
            '</div>' +
            '<div>' +
              '<label class="cms-label">Essay Body (HTML / Rich Text · 600–1,700 Words)</label>' +
              '<textarea id="cmsEditorBody" class="cms-textarea" rows="12">' + escapeHtml(editArt ? editArt.body : '<p class="lead-para">Write your analytical essay here...</p>') + '</textarea>' +
            '</div>' +
            '<div>' +
              '<label class="cms-label">Custom HTML Block (Optional — Embed Custom Tables, Widgets, or Interactive HTML)</label>' +
              '<textarea id="cmsArtCustomHtml" class="cms-textarea" rows="4" style="font-family:monospace;font-size:12px;" placeholder="Paste optional custom HTML here...">' + escapeHtml(editArt && editArt.customHtml ? editArt.customHtml : '') + '</textarea>' +
            '</div>' +
            '<div style="background:#faf7f0;border:1px solid #d5cdbc;padding:16px;">' +
              '<div class="kicker-red" style="margin-bottom:8px;">PER-ARTICLE SEO SETTINGS</div>' +
              '<div style="display:grid;gap:12px;">' +
                '<div><label class="cms-label">SEO Meta Title</label><input type="text" id="cmsArtSeoTitle" class="cms-input" value="' + escapeHtml(editArt ? editArt.seoTitle : '') + '"/></div>' +
                '<div><label class="cms-label">SEO Meta Description</label><input type="text" id="cmsArtSeoDesc" class="cms-input" value="' + escapeHtml(editArt ? editArt.seoDescription : '') + '"/></div>' +
                '<div><label class="cms-label">Focus Keywords</label><input type="text" id="cmsArtSeoKeywords" class="cms-input" value="' + escapeHtml(editArt ? editArt.seoKeywords : '') + '"/></div>' +
              '</div>' +
            '</div>' +
          '</div>' +
          '<div style="display:flex;flex-direction:column;gap:16px;background:#faf7f0;border:1px solid #d5cdbc;padding:18px;">' +
            '<div>' +
              '<label class="cms-label">Publish Under User / Author ID</label>' +
              '<select id="cmsArtAuthorId" class="cms-select"' + (!isEditorial ? ' disabled' : '') + '>' + authorOpts + '</select>' +
            '</div>' +
            '<div>' +
              '<label class="cms-label">Primary Category (All 13 Beats)</label>' +
              '<select id="cmsArtCategory" class="cms-select" onchange="onCmsMultiCatChange()">' + catOpts + '</select>' +
            '</div>' +
            '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:12px;">' +
              '<label class="cms-label" style="color:var(--accent-red);">Assign Multiple Categories (Shows Bold in Preview &amp; Article)</label>' +
              '<div class="cms-multicat-grid" style="max-height:210px;overflow-y:auto;">' +
                state.categories.map(function(c) {
                  var isChecked = editArt ? (getArticleCategories(editArt).indexOf(c) !== -1) : (c === 'Weekline Exclusive');
                  return '<label class="cms-multicat-item"><input type="checkbox" name="cmsArtMultiCat" value="' + escapeHtml(c) + '"' + (isChecked ? ' checked' : '') + ' onchange="onCmsMultiCatChange()"/> <span>' + escapeHtml(c) + '</span></label>';
                }).join('') +
              '</div>' +
              '<div style="margin-top:8px;font-size:11px;color:#5a606d;">Live Bold Preview on Website:</div>' +
              '<div id="cmsMultiCatLivePreview" class="multi-cat-row" style="margin-top:4px;">' +
                (editArt ? renderArticleCategoriesBadgesHtml(editArt) : '<span class="cat-badge-bold"><strong>Weekline Exclusive</strong></span>') +
              '</div>' +
              '<div style="margin-top:10px;padding-top:8px;border-top:1px dashed #d5cdbc;display:flex;gap:6px;">' +
                '<input type="text" id="cmsNewCustomCategoryInput" class="cms-input" style="font-size:11.5px;padding:6px 8px;" placeholder="Add new category..."/>' +
                '<button type="button" class="platform-pill-btn" style="white-space:nowrap;font-size:11px;" onclick="addNewCustomCategoryInCms()">+ Add Beat</button>' +
              '</div>' +
            '</div>' +
            '<div>' +
              '<label class="cms-label">Publication Date (Aug 8 + Sundays)</label>' +
              '<input type="date" id="cmsArtDate" class="cms-input" value="' + escapeHtml(editArt ? editArt.date : '2026-10-25') + '"/>' +
            '</div>' +
            '<div>' +
              '<label class="cms-label">Read Time &amp; Word Count Label</label>' +
              '<input type="text" id="cmsArtReadTime" class="cms-input" value="' + escapeHtml(editArt ? editArt.readTime : '6 min read · 720 words') + '"/>' +
            '</div>' +
            '<div>' +
              '<label class="cms-label">Status</label>' +
              '<select id="cmsArtStatus" class="cms-select">' +
                '<option value="published"' + (!editArt || editArt.status === 'published' ? ' selected' : '') + '>Published (Live)</option>' +
                '<option value="draft"' + (editArt && editArt.status === 'draft' ? ' selected' : '') + '>Draft</option>' +
              '</select>' +
            '</div>' +
            '<div style="border-top:1px solid #e2dac9;padding-top:12px;">' +
              '<label class="cms-label">Featured Image Upload</label>' +
              '<div style="font-size:11.5px;color:var(--accent-red);font-weight:600;margin-bottom:6px;">Photo size must be less than 1 MB (.webp featured)</div>' +
              '<input type="file" accept="image/*" onchange="handleWriteFeaturedUpload(this, \'cms\')" style="font-size:12px;width:100%;"/>' +
              '<div id="cmsFeaturedStatus" style="font-size:11.5px;margin-top:6px;color:#5a606d;">Upload a photo or keep existing visual.</div>' +
            '</div>' +
            '<div style="border-top:1px solid #e2dac9;padding-top:12px;">' +
              '<label style="font-size:12.5px;display:flex;align-items:center;gap:8px;cursor:pointer;">' +
                '<input type="checkbox" id="cmsArtIsHero"' + (editArt && editArt.isHero ? ' checked' : '') + '/> Set as Top "Story in Focus" Hero' +
              '</label>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';
    } else if (activeCmsTab === 'articles') {
      var rows = state.articles.map(function(a) {
        var canModifyThis = canEditOrDeleteArticle(a);
        var userSelectOpts = visibleUsers.map(function(usr) {
          var s = (usr.id === a.authorId) ? ' selected' : '';
          return '<option value="' + usr.id + '"' + s + '>' + escapeHtml(usr.name) + ' (' + escapeHtml(usr.role) + ')</option>';
        }).join('');

        return '<tr style="border-bottom:1px solid #e2dac9;">' +
          '<td style="padding:12px 10px;">' +
            '<div style="display:flex;align-items:center;gap:12px;">' +
              '<img src="' + resolvePhoto(a.featuredImage) + '" alt="" style="width:60px;height:40px;object-fit:cover;border:1px solid #ccc;"/>' +
              '<div>' +
                '<div style="font-weight:700;font-size:14px;cursor:pointer;color:var(--navy-dark);margin-bottom:4px;" onclick="openArticle(\'' + a.id + '\')">' + escapeHtml(a.title) + '</div>' +
                '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">' +
                  renderArticleCategoriesBadgesHtml(a) +
                  (canModifyThis ? '<button type="button" class="platform-pill-btn" style="font-size:10.5px;padding:2px 7px;" onclick="toggleQuickMultiCatEditor(\'' + a.id + '\')">&#9998; +/Edit Categories</button>' : '') +
                  '<span style="font-size:11.5px;color:#5a606d;">· ' + escapeHtml(a.readTime) + (a.isHero ? ' · <strong>[HERO]</strong>' : '') + '</span>' +
                '</div>' +
                (editingMultiCatArtId === a.id ? (
                  '<div style="margin-top:8px;background:#faf7f0;border:1px solid #c9c0ae;padding:10px;border-radius:3px;">' +
                    '<div style="font-size:11px;font-weight:700;color:var(--navy-dark);margin-bottom:6px;">Select 1 or Multiple Categories for This Article (Shows Bold in Preview):</div>' +
                    '<div class="cms-multicat-grid">' +
                      state.categories.map(function(c) {
                        var chk = articleHasCategory(a, c) ? ' checked' : '';
                        return '<label class="cms-multicat-item"><input type="checkbox" name="quickCat_' + a.id + '" value="' + escapeHtml(c) + '"' + chk + '/> <span>' + escapeHtml(c) + '</span></label>';
                      }).join('') +
                    '</div>' +
                    '<div style="margin-top:8px;display:flex;gap:8px;">' +
                      '<button type="button" class="btn-red-action" style="padding:5px 12px;font-size:11.5px;" onclick="saveQuickMultiCatForArticle(\'' + a.id + '\')">Save Bold Categories &#10003;</button>' +
                      '<button type="button" class="platform-pill-btn" style="padding:5px 10px;font-size:11.5px;" onclick="toggleQuickMultiCatEditor(\'' + a.id + '\')">Cancel</button>' +
                    '</div>' +
                  '</div>'
                ) : '') +
              '</div>' +
            '</div>' +
          '</td>' +
          '<td style="padding:12px 10px;">' +
            '<select class="cms-select" style="font-size:12px;padding:6px;" onchange="quickReassignArticleAuthor(\'' + a.id + '\', this.value)"' + (!isSuper ? ' disabled' : '') + '>' +
              userSelectOpts +
            '</select>' +
          '</td>' +
          '<td style="padding:12px 10px;">' +
            '<input type="date" class="cms-input" style="font-size:12px;padding:6px;width:140px;" value="' + escapeHtml(a.date) + '" onchange="quickChangeArticleDate(\'' + a.id + '\', this.value)"' + (!canModifyThis ? ' disabled' : '') + '/>' +
          '</td>' +
          (isAdminView ? ('<td style="padding:12px 10px;white-space:nowrap;"><span style="background:#eef4ff;color:#0b2e6b;border:1px solid #b8d0f7;padding:4px 9px;border-radius:4px;font-weight:700;font-size:12.5px;">&#128065; ' + Number(a.views || 0).toLocaleString() + ' views</span></td>') : '') +
          '<td style="padding:12px 10px;white-space:nowrap;">' +
            (canModifyThis ? '<button type="button" class="platform-pill-btn" onclick="startEditArticleInCms(\'' + a.id + '\')">Edit</button> ' : '') +
            '<button type="button" class="platform-pill-btn" onclick="openArticle(\'' + a.id + '\')">View</button> ' +
            (canModifyThis ? '<button type="button" class="platform-pill-btn" style="color:#c23425;" onclick="deleteArticleInCms(\'' + a.id + '\')">Delete</button>' : '') +
          '</td>' +
        '</tr>';
      }).join('');

      bodyContent = '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:22px;overflow-x:auto;">' +
        '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:12px;">' +
          '<div>' +
            '<h3 style="font-family:var(--font-serif);font-size:22px;margin:0;">All Published Essays (' + state.articles.length + ')</h3>' +
            '<p style="font-size:12.5px;color:#5a606d;margin:4px 0 0;">' + (isSuper ? 'Master Super Admin Mode: You can edit, delete, reassign User ID, or change the Sunday date of any essay.' : 'You can edit or delete your own essays and any pending contributor submissions.') + '</p>' +
          '</div>' +
          '<button type="button" class="btn-red-action" onclick="switchCmsTab(\'editor\')">+ Upload New Essay</button>' +
        '</div>' +
        '<table style="width:100%;border-collapse:collapse;text-align:left;">' +
          '<thead><tr style="border-bottom:2px solid var(--border-dark);font-size:11.5px;text-transform:uppercase;color:#5a606d;">' +
            '<th style="padding:10px;">Thumbnail, Headline, Category &amp; Word Count</th>' +
            '<th style="padding:10px;">Assigned Author ID</th>' +
            '<th style="padding:10px;">Sunday Publish Date</th>' +
            (isAdminView ? '<th style="padding:10px;color:#0b2e6b;">Live Views (Admin ID Only)</th>' : '') +
            '<th style="padding:10px;">Actions</th>' +
          '</tr></thead>' +
          '<tbody>' + rows + '</tbody>' +
        '</table>' +
      '</div>';
    } else if (activeCmsTab === 'submissions') {
      var pendingProfiles = state.users.filter(function(u) { return u.status === 'pending_approval'; });
      var pendingProfilesBanner = pendingProfiles.length > 0
        ? ('<div style="background:#fff8eb;border:1px solid #e0c285;padding:14px 18px;margin-bottom:18px;">' +
            '<div class="kicker-red" style="margin-bottom:6px;">AUTO-CREATED TEMPORARY CONTRIBUTOR PROFILES (WAITING FOR APPROVAL)</div>' +
            pendingProfiles.map(function(pu) {
              return '<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;padding:6px 0;border-bottom:1px dashed #e0c285;">' +
                '<div><strong>' + escapeHtml(pu.name) + '</strong> (' + escapeHtml(pu.email) + ') — <em>' + escapeHtml(pu.bio) + '</em></div>' +
                '<div style="display:flex;gap:8px;">' +
                  '<button type="button" class="platform-pill-btn" style="color:#1b6e38;" onclick="approvePendingUserProfileDirectly(\'' + pu.id + '\')">Approve Profile</button>' +
                  '<button type="button" class="platform-pill-btn" style="color:#c23425;" onclick="deleteUserProfileInCms(\'' + pu.id + '\')">Delete</button>' +
                '</div>' +
              '</div>';
            }).join('') +
          '</div>')
        : '';

      var subCards = state.submissions.length === 0
        ? '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:32px;text-align:center;color:#5a606d;">No pending submissions. Test submitting via the highlighted "Write for Us" button in the top bar!</div>'
        : state.submissions.map(function(s) {
            var isEditingThis = (editingSubmissionId === s.id);
            var editFormHtml = '';
            if (isEditingThis) {
              var catOpts = state.categories.map(function(c) {
                return '<option value="' + escapeHtml(c) + '"' + (s.category === c ? ' selected' : '') + '>' + escapeHtml(c) + '</option>';
              }).join('');
              editFormHtml = '<div style="background:#ebe4d4;padding:16px;margin-top:12px;border:1px solid #c9c0ae;display:grid;gap:10px;">' +
                '<div class="responsive-form-grid-2">' +
                  '<div><label class="cms-label">Contributor Name (Bold)</label><input type="text" id="editSubName_' + s.id + '" class="cms-input" value="' + escapeHtml(s.contributorName) + '"/></div>' +
                  '<div><label class="cms-label">Category</label><select id="editSubCat_' + s.id + '" class="cms-select">' + catOpts + '</select></div>' +
                '</div>' +
                '<div><label class="cms-label">Short Biography (Non-Bold)</label><input type="text" id="editSubBio_' + s.id + '" class="cms-input" value="' + escapeHtml(s.contributorBio) + '"/></div>' +
                '<div><label class="cms-label">Essay Headline</label><input type="text" id="editSubHead_' + s.id + '" class="cms-input" value="' + escapeHtml(s.headline) + '"/></div>' +
                '<div><label class="cms-label">Essay Body</label><textarea id="editSubBody_' + s.id + '" class="cms-textarea" rows="5">' + escapeHtml(s.body) + '</textarea></div>' +
                '<div style="display:flex;gap:10px;">' +
                  '<button type="button" class="btn-red-action" onclick="saveEditedSubmissionInCms(\'' + s.id + '\')">Save Changes</button>' +
                  '<button type="button" class="platform-pill-btn" onclick="startEditSubmissionInCms(\'' + s.id + '\')">Cancel</button>' +
                '</div>' +
              '</div>';
            }

            return '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:20px;margin-bottom:16px;">' +
              '<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;border-bottom:1px solid #e2dac9;padding-bottom:12px;margin-bottom:14px;">' +
                '<div style="display:flex;align-items:center;gap:14px;">' +
                  '<img src="' + resolvePhoto(s.contributorAvatar) + '" alt="" style="width:54px;height:54px;border-radius:50%;object-fit:cover;border:2px solid var(--navy-dark);"/>' +
                  '<div>' +
                    '<div style="font-weight:700;font-size:15px;">' + escapeHtml(s.contributorName) + ' <span style="font-weight:400;font-size:12px;color:#5a606d;">(' + escapeHtml(s.contributorEmail) + ')</span></div>' +
                    '<div style="font-weight:400;font-size:12.5px;color:#454952;">' + escapeHtml(s.contributorBio) + '</div>' +
                    '<div style="font-size:11px;color:#1b6e38;margin-top:2px;">Emailed to: ' + escapeHtml(s.emailedTo) + ' · ' + escapeHtml(s.submittedAt) + '</div>' +
                  '</div>' +
                '</div>' +
                '<div style="display:flex;gap:8px;flex-wrap:wrap;">' +
                  '<button type="button" class="platform-pill-btn" onclick="startEditSubmissionInCms(\'' + s.id + '\')">Edit Profile &amp; Essay</button>' +
                  (s.status === 'pending'
                    ? '<button type="button" class="btn-red-action" onclick="approveSubmissionInCms(\'' + s.id + '\')">Approve &amp; Publish &#8599;</button>'
                    : '<span style="background:#e3f3e8;color:#1b6e38;padding:6px 12px;font-size:12px;font-weight:700;border-radius:4px;">&#10003; Approved &amp; Live</span>') +
                  '<button type="button" class="platform-pill-btn" style="color:#c23425;" onclick="deleteSubmissionInCms(\'' + s.id + '\')">Delete</button>' +
                '</div>' +
              '</div>' +
              '<div class="kicker-red">' + escapeHtml(s.category) + '</div>' +
              '<h4 style="font-family:var(--font-serif);font-size:21px;margin:4px 0 8px;">' + escapeHtml(s.headline) + '</h4>' +
              '<div style="background:#faf7f0;padding:12px 16px;border:1px solid #e2dac9;font-family:var(--font-serif);font-size:14.5px;line-height:1.6;">' + s.body + '</div>' +
              editFormHtml +
            '</div>';
          }).join('');

      bodyContent = '<div>' +
        '<div style="background:#ebe4d4;border:1px solid #d2c8b5;padding:16px 20px;margin-bottom:18px;">' +
          '<strong>Incoming "Write for Us" Queue &amp; Auto-Created Contributor Profiles:</strong> Every public submission emails <code>editorial@csbnewsusallc.news</code> and creates a temporary Contributor Profile waiting for approval. All Admin and Editor IDs can edit, approve, or delete these pending profiles and essays.' +
        '</div>' +
        pendingProfilesBanner +
        subCards +
      '</div>';
    } else if (activeCmsTab === 'customizer' && isSuper) {
      ensureSiteAndAdsConfig();
      var sc = state.siteConfig;
      var secLabels = {
        top_motion_ad: '1. Top Leaderboard Motion Advertisement Banner',
        custom_blocks_top: '2. Custom Page Blocks — Top Zone (Above Hero)',
        hero_story: '3. Story in Focus — Lead Sunday Hero Essay',
        mid_motion_ad: '4. Mid-Page Motion Advertisement Showcase',
        newspaper_archive: '5. Multi-Page Newspaper Grid & Unlimited Pagination',
        custom_blocks_bottom: '6. Custom Page Blocks — Bottom Zone (Above Footer)'
      };
      var orderHtml = (sc.sectionOrder || []).map(function(secKey, idx) {
        return '<div class="draggable-block-item" draggable="true" ondragstart="onSectionDragStart(' + idx + ')" ondragover="onSectionDragOver(event)" ondrop="onSectionDrop(' + idx + ')">' +
          '<div><strong>&#9776; ' + escapeHtml(secLabels[secKey] || secKey) + '</strong> <span style="font-size:11px;color:#5a606d;">(Drag to reorder)</span></div>' +
          '<div style="display:flex;gap:6px;">' +
            '<button type="button" class="platform-pill-btn" onclick="moveHomepageSectionOrder(' + idx + ', -1)">&#8593; Up</button>' +
            '<button type="button" class="platform-pill-btn" onclick="moveHomepageSectionOrder(' + idx + ', 1)">&#8595; Down</button>' +
          '</div>' +
        '</div>';
      }).join('');

      var customBlocksListHtml = (sc.customBlocks || []).map(function(b, bIdx) {
        return '<div style="background:#faf7f0;border:1px solid #d5cdbc;padding:12px 14px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">' +
          '<div>' +
            '<span class="kicker-red">[' + escapeHtml((b.zone || 'bottom').toUpperCase()) + ' · ' + escapeHtml((b.type || 'visual').toUpperCase()) + ']</span> ' +
            '<strong>' + escapeHtml(b.title) + '</strong>' +
          '</div>' +
          '<div style="display:flex;gap:6px;flex-wrap:wrap;">' +
            '<button type="button" class="platform-pill-btn" onclick="moveCustomPageBlock(' + bIdx + ', -1)">&#8593;</button>' +
            '<button type="button" class="platform-pill-btn" onclick="moveCustomPageBlock(' + bIdx + ', 1)">&#8595;</button>' +
            '<button type="button" class="platform-pill-btn" onclick="toggleCustomPageBlock(\'' + b.id + '\')">' + (b.active ? 'Active ✓' : 'Hidden') + '</button>' +
            '<button type="button" class="platform-pill-btn" style="color:#c23425;" onclick="deleteCustomPageBlock(\'' + b.id + '\')">Delete</button>' +
          '</div>' +
        '</div>';
      }).join('');

      bodyContent = '<div style="display:grid;grid-template-columns:1.15fr 1fr;gap:24px;">' +
        '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:22px;">' +
          '<div class="kicker-red">LIVE WEBSITE MOTTO, TEXT, OPTIONS &amp; COVER/DP CUSTOMIZER</div>' +
          '<h3 style="font-family:var(--font-serif);font-size:22px;margin:4px 0 14px;">Edit Website Text, Motto, Buttons, Cover &amp; Logo</h3>' +
          '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">' +
            '<div style="grid-column:1/-1;"><label class="cms-label">Top Edition Ribbon Text</label><input type="text" id="custTopRibbon" class="cms-input" value="' + escapeHtml(sc.topRibbonText) + '"/></div>' +
            '<div><label class="cms-label">Brand Title (Masthead)</label><input type="text" id="custBrandTitle" class="cms-input" value="' + escapeHtml(sc.mastheadBrandTitle) + '"/></div>' +
            '<div><label class="cms-label">Masthead Subtitle</label><input type="text" id="custBrandSub" class="cms-input" value="' + escapeHtml(sc.mastheadSubtitle) + '"/></div>' +
            '<div><label class="cms-label">Right Motto (e.g. YOUR OPINION MATTERS)</label><input type="text" id="custRightMotto" class="cms-input" value="' + escapeHtml(sc.mastheadRightMotto) + '"/></div>' +
            '<div><label class="cms-label">Left Motto Kicker</label><input type="text" id="custLeftKicker" class="cms-input" value="' + escapeHtml(sc.mastheadLeftKicker) + '"/></div>' +
            '<div style="grid-column:1/-1;"><label class="cms-label">Left Editorial Motto Quote</label><input type="text" id="custLeftQuote" class="cms-input" value="' + escapeHtml(sc.mastheadLeftQuote) + '"/></div>' +
            '<div><label class="cms-label">Top "Write for Us" Option Label</label><input type="text" id="custWriteLabel" class="cms-input" value="' + escapeHtml(sc.navWriteForUsLabel) + '"/></div>' +
            '<div><label class="cms-label">Masthead "Support Us" Option Label</label><input type="text" id="custSupportLabel" class="cms-input" value="' + escapeHtml(sc.mastheadSupportLabel) + '"/></div>' +
            '<div><label class="cms-label">Top "Contributors" Option Label</label><input type="text" id="custContribLabel" class="cms-input" value="' + escapeHtml(sc.navContributorsLabel) + '"/></div>' +
            '<div><label class="cms-label">Top "Editorial Desk" Option Label</label><input type="text" id="custDeskLabel" class="cms-input" value="' + escapeHtml(sc.navEditorialDeskLabel) + '"/></div>' +
            '<div><label class="cms-label">Centered Sub-Bar Option (Explore the Journal)</label><input type="text" id="custExploreLabel" class="cms-input" value="' + escapeHtml(sc.exploreJournalLabel) + '"/></div>' +
            '<div><label class="cms-label">Hero Section Kicker</label><input type="text" id="custHeroKicker" class="cms-input" value="' + escapeHtml(sc.heroSectionKicker) + '"/></div>' +
            '<div><label class="cms-label">Newspaper Archive Heading</label><input type="text" id="custArchiveTitle" class="cms-input" value="' + escapeHtml(sc.archiveSectionTitle) + '"/></div>' +
            '<div><label class="cms-label">Reports Per Page (Multi-Page Pagination)</label><input type="number" id="custPerPage" class="cms-input" value="' + escapeHtml(String(sc.articlesPerPage || 12)) + '"/></div>' +
            '<div style="grid-column:1/-1;"><label class="cms-label">Newspaper Archive Subheading</label><input type="text" id="custArchiveSub" class="cms-input" value="' + escapeHtml(sc.archiveSectionSub) + '"/></div>' +
            '<div><label class="cms-label">Mid-Page Banner Kicker</label><input type="text" id="custPromoKicker" class="cms-input" value="' + escapeHtml(sc.promoKicker) + '"/></div>' +
            '<div><label class="cms-label">Mid-Page Banner Heading</label><input type="text" id="custPromoHeading" class="cms-input" value="' + escapeHtml(sc.promoHeading) + '"/></div>' +
            '<div style="grid-column:1/-1;"><label class="cms-label">Mid-Page Banner Body Text</label><textarea id="custPromoBody" class="cms-textarea" rows="2">' + escapeHtml(sc.promoBody) + '</textarea></div>' +
            '<div><label class="cms-label">Footer Motto Tagline</label><input type="text" id="custFooterTagline" class="cms-input" value="' + escapeHtml(sc.footerTagline) + '"/></div>' +
            '<div><label class="cms-label">Footer Contact Team Label</label><input type="text" id="custFooterContact" class="cms-input" value="' + escapeHtml(sc.footerContactLabel) + '"/></div>' +
            '<div><label class="cms-label">Masthead Cover Color (Hex)</label><input type="text" id="custCoverColor" class="cms-input" value="' + escapeHtml(sc.coverBgColor || '#060d3a') + '"/></div>' +
          '</div>' +
          '<button type="button" class="btn-red-action" style="margin-top:14px;width:100%;justify-content:center;" onclick="saveSiteTextAndMottoConfig()">Save All Website Motto, Text &amp; Option Labels Live &#8599;</button>' +
          '<div style="border-top:1px solid #d5cdbc;margin-top:18px;padding-top:16px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;">' +
            '<div style="background:#faf7f0;padding:10px;border:1px solid #d5cdbc;">' +
              '<label class="cms-label">Upload Cover Background Photo</label>' +
              '<input type="file" accept="image/*" onchange="handleCoverOrLogoUpload(this, \'cover\')" style="font-size:11px;width:100%;"/>' +
              '<button type="button" class="platform-pill-btn" style="margin-top:6px;font-size:11px;" onclick="resetCoverToDefaultNavy()">Reset Cover to Navy</button>' +
            '</div>' +
            '<div style="background:#faf7f0;padding:10px;border:1px solid #d5cdbc;">' +
              '<label class="cms-label">Upload Website Logo &amp; Favicon</label>' +
              '<input type="file" accept="image/*" onchange="handleCoverOrLogoUpload(this, \'logo\')" style="font-size:11px;width:100%;"/>' +
            '</div>' +
            '<div style="background:#faf7f0;padding:10px;border:1px solid #d5cdbc;">' +
              '<label class="cms-label">Upload Default Desk DP Icon</label>' +
              '<input type="file" accept="image/*" onchange="handleCoverOrLogoUpload(this, \'deskdp\')" style="font-size:11px;width:100%;"/>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div style="display:flex;flex-direction:column;gap:18px;">' +
          '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:20px;">' +
            '<div class="kicker-red">DRAG-AND-DROP HOMEPAGE LAYOUT BUILDER</div>' +
            '<h3 style="font-family:var(--font-serif);font-size:20px;margin:4px 0 10px;">Drag Sections or Use Up/Down Arrows to Reorder Page</h3>' +
            '<div style="display:flex;flex-direction:column;gap:8px;">' + orderHtml + '</div>' +
          '</div>' +
          '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:20px;">' +
            '<div class="kicker-red">ADD NEW PAGE BLOCK (VISUAL UPLOAD OR CUSTOM HTML/CSS/JS CODE)</div>' +
            '<h3 style="font-family:var(--font-serif);font-size:20px;margin:4px 0 12px;">Create &amp; Drag Custom Page Blocks</h3>' +
            '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px;">' +
              '<div><label class="cms-label">Block Mode</label><select id="newBlkType" class="cms-select"><option value="visual">Visual Upload Block (Image + Text + Button)</option><option value="code">Custom Code Block (HTML / CSS / JS)</option></select></div>' +
              '<div><label class="cms-label">Placement Zone</label><select id="newBlkZone" class="cms-select"><option value="top">Top Zone (Above Hero Story)</option><option value="bottom">Bottom Zone (Below Newspaper Grid)</option></select></div>' +
              '<div><label class="cms-label">Block Kicker</label><input type="text" id="newBlkKicker" class="cms-input" placeholder="e.g. SPECIAL ANNOUNCEMENT"/></div>' +
              '<div><label class="cms-label">Block Headline</label><input type="text" id="newBlkTitle" class="cms-input" placeholder="Enter block headline..."/></div>' +
              '<div style="grid-column:1/-1;"><label class="cms-label">Block Description</label><input type="text" id="newBlkDesc" class="cms-input" placeholder="Enter block description..."/></div>' +
              '<div><label class="cms-label">Upload Block Image (.webp/.png/.jpg)</label><input type="file" accept="image/*" onchange="handleCustomBlockImgUpload(this)" style="font-size:11.5px;"/></div>' +
              '<div><label class="cms-label">Background Color</label><input type="text" id="newBlkBgColor" class="cms-input" value="#f4efe4"/></div>' +
              '<div><label class="cms-label">CTA Button Label (Optional)</label><input type="text" id="newBlkCtaText" class="cms-input" placeholder="e.g. Explore Now ↗"/></div>' +
              '<div><label class="cms-label">CTA Action / URL</label><input type="text" id="newBlkCtaAction" class="cms-input" placeholder="write_for_us, support_us, or https://..."/></div>' +
              '<div style="grid-column:1/-1;"><label class="cms-label">Or Paste Custom HTML / CSS / JS Code (If Mode = Custom Code Block)</label><textarea id="newBlkCodeHtml" class="cms-textarea" rows="3" style="font-family:monospace;font-size:12px;" placeholder="<div style=\x27padding:20px;background:#060d3a;color:#fff;\x27>Custom HTML Block</div>"></textarea></div>' +
            '</div>' +
            '<button type="button" class="btn-red-action" onclick="addNewCustomPageBlock()">+ Add Custom Block to Website &#8599;</button>' +
            '<div style="margin-top:14px;display:flex;flex-direction:column;gap:8px;">' + customBlocksListHtml + '</div>' +
          '</div>' +
        '</div>' +
      '</div>';
    } else if (activeCmsTab === 'ads' && isChairmanOrSuper) {
      ensureSiteAndAdsConfig();
      var adRows = (state.adsConfig.items || []).map(function(ad) {
        var ctr = ad.impressions ? ((Number(ad.clicks || 0) / Number(ad.impressions)) * 100).toFixed(2) : '0.00';
        return '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:16px;border-left:4px solid ' + (ad.active ? '#e45745' : '#999') + ';">' +
          '<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:8px;">' +
            '<div><span class="kicker-red">[' + escapeHtml(ad.slot.toUpperCase()) + ' · ' + escapeHtml(ad.motionStyle) + ']</span> <strong>' + escapeHtml(ad.headline) + '</strong></div>' +
            '<div style="display:flex;gap:8px;">' +
              '<button type="button" class="platform-pill-btn" onclick="toggleMotionAdItem(\'' + ad.id + '\')">' + (ad.active ? 'Active ✓ (Pause)' : 'Paused (Activate)') + '</button>' +
              '<button type="button" class="platform-pill-btn" style="color:#c23425;" onclick="deleteMotionAdItem(\'' + ad.id + '\')">Delete</button>' +
            '</div>' +
          '</div>' +
          '<div style="font-size:12.5px;color:#454952;margin-bottom:6px;">Sponsor: <strong>' + escapeHtml(ad.sponsorName) + '</strong> · Target: <code>' + escapeHtml(ad.targetUrl) + '</code></div>' +
          '<div style="font-size:12px;background:#faf7f0;padding:6px 10px;border:1px solid #e2dac9;display:flex;gap:16px;flex-wrap:wrap;">' +
            '<span><strong>Impressions:</strong> ' + Number(ad.impressions || 0).toLocaleString() + '</span>' +
            '<span><strong>Clicks:</strong> ' + Number(ad.clicks || 0).toLocaleString() + '</span>' +
            '<span style="color:#1b6e38;"><strong>CTR:</strong> ' + ctr + '%</span>' +
          '</div>' +
        '</div>';
      }).join('');

      bodyContent = '<div style="display:grid;grid-template-columns:1fr 1.25fr;gap:24px;">' +
        '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:22px;">' +
          '<div class="kicker-red">ANIMATED MOTION ADVERTISEMENT &amp; SPONSORSHIP STUDIO</div>' +
          '<h3 style="font-family:var(--font-serif);font-size:22px;margin:4px 0 12px;">Publish New Animated Motion Ad</h3>' +
          '<div style="display:flex;flex-direction:column;gap:12px;">' +
            '<div><label class="cms-label">Placement Slot on Website</label><select id="newAdSlot" class="cms-select"><option value="top_leaderboard">1. Top Leaderboard Motion Banner (Above Hero)</option><option value="mid_feed">2. Mid-Page In-Feed Motion Showcase (Above Newspaper Grid)</option><option value="article_footer">3. Individual Article Footer Motion Banner</option></select></div>' +
            '<div><label class="cms-label">Motion UI/UX Animation Style</label><select id="newAdMotionStyle" class="cms-select"><option value="motion-shimmer">Luxury Gold &amp; Crimson Light Shimmer + Pulse CTA</option><option value="motion-kenburns">Cinematic Ken Burns Zoom &amp; Pan + Pulse CTA</option><option value="motion-marquee">Live Scrolling Partner Ticker Ribbon + Pulse CTA</option></select></div>' +
            '<div><label class="cms-label">Sponsor / Advertiser Name</label><input type="text" id="newAdSponsor" class="cms-input" placeholder="e.g. ROLEX / ATLANTIC COUNCIL / GLOBAL PARTNER"/></div>' +
            '<div><label class="cms-label">Top Kicker Label</label><input type="text" id="newAdKicker" class="cms-input" value="SPONSORED MOTION SPOTLIGHT"/></div>' +
            '<div><label class="cms-label">Advertisement Headline</label><input type="text" id="newAdHeadline" class="cms-input" placeholder="Enter compelling campaign headline..."/></div>' +
            '<div><label class="cms-label">Subtext / Campaign Copy</label><textarea id="newAdSubtext" class="cms-textarea" rows="2" placeholder="Describe the sponsor offer..."></textarea></div>' +
            '<div class="responsive-form-grid-2">' +
              '<div><label class="cms-label">CTA Button Label</label><input type="text" id="newAdCtaText" class="cms-input" value="Explore Partner ↗"/></div>' +
              '<div><label class="cms-label">Target Click URL</label><input type="text" id="newAdTargetUrl" class="cms-input" placeholder="https://..."/></div>' +
            '</div>' +
            '<div><label class="cms-label">Upload Sponsor Visual / Banner (.webp/.png/.jpg)</label><input type="file" accept="image/*" onchange="handleMotionAdImgUpload(this)" style="font-size:12px;"/></div>' +
            '<div><label class="cms-label">Or Paste Custom Ad Network HTML / AdSense Script (Optional)</label><textarea id="newAdCustomHtml" class="cms-textarea" rows="2" style="font-family:monospace;font-size:12px;" placeholder="Optional custom HTML/script..."></textarea></div>' +
            '<button type="button" class="btn-red-action" onclick="addNewMotionAdvertisement()">+ Launch Motion Advertisement Live &#8599;</button>' +
          '</div>' +
        '</div>' +
        '<div style="display:flex;flex-direction:column;gap:16px;">' +
          '<div style="background:var(--navy-dark);color:#ffffff;padding:18px 22px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">' +
            '<div><div class="kicker-red">GLOBAL MOTION AD ENGINE</div><div style="font-family:var(--font-serif);font-size:20px;">Status: ' + (state.adsConfig.enabled ? 'Active &amp; Animating Live ✓' : 'Paused') + '</div></div>' +
            '<button type="button" class="btn-outline-white" onclick="toggleGlobalAdsEnabled()">' + (state.adsConfig.enabled ? 'Pause All Ads' : 'Enable All Ads') + '</button>' +
          '</div>' +
          '<div style="display:flex;flex-direction:column;gap:12px;">' + adRows + '</div>' +
        '</div>' +
      '</div>';
    } else if (activeCmsTab === 'treasury' && isChairmanOrSuper) {
      var totalUsdReceived = (state.transactions || []).reduce(function(sum, t) { return sum + (Number(t.usdEquivalent) || 0); }, 0);
      var methodRows = state.paymentConfig.methods.map(function(m) {
        var adminControls = isSuper
          ? ('<div style="display:flex;gap:8px;">' +
              '<button type="button" class="platform-pill-btn" onclick="togglePaymentMethodActive(\'' + m.id + '\')">' + (m.active ? 'Active ✓ (Click to Pause)' : 'Paused (Click to Activate)') + '</button>' +
              '<button type="button" class="platform-pill-btn" style="color:#c23425;" onclick="deletePaymentMethodInCms(\'' + m.id + '\')">Remove (Master Admin Only)</button>' +
            '</div>')
          : '<span style="background:#e3f3e8;color:#1b6e38;padding:4px 9px;border-radius:3px;font-size:11.5px;font-weight:700;">Receive-Only Active ✓ (Removal Restricted to Master Admin)</span>';

        return '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:16px;border-left:4px solid ' + (m.active ? '#1b6e38' : '#999') + ';">' +
          '<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:6px;">' +
            '<div><span class="kicker-red">[' + escapeHtml(m.category) + ']</span> <strong>' + escapeHtml(m.title) + '</strong></div>' +
            adminControls +
          '</div>' +
          '<div style="font-size:12.5px;color:#1e222b;font-family:monospace;background:#faf7f0;padding:8px 10px;border:1px solid #e2dac9;">' +
            '<div><strong>Provider / Bank:</strong> ' + escapeHtml(m.provider) + '</div>' +
            '<div><strong>Corporate Beneficiary:</strong> ' + escapeHtml(m.accountName) + '</div>' +
            '<div><strong>Receive-Only Card / Account No:</strong> ' + escapeHtml(m.accountNumber) + '</div>' +
            '<div><strong>Routing / SWIFT / Deposit Info:</strong> ' + escapeHtml(m.routingOrSwift) + '</div>' +
          '</div>' +
        '</div>';
      }).join('');

      var txRows = (state.transactions || []).map(function(tx) {
        return '<tr style="border-bottom:1px solid #e2dac9;font-size:13px;">' +
          '<td style="padding:10px;"><strong>' + escapeHtml(tx.donorName) + '</strong><br/><span style="font-size:11.5px;color:#5a606d;">' + escapeHtml(tx.donorEmail) + '</span></td>' +
          '<td style="padding:10px;">' + escapeHtml(String(tx.originalAmount)) + ' ' + escapeHtml(tx.originalCurrency) + '<br/><strong style="color:#1b6e38;">$' + Number(tx.usdEquivalent).toFixed(2) + ' USD</strong></td>' +
          '<td style="padding:10px;">' + escapeHtml(tx.methodTitle) + '<br/><code style="font-size:11px;">' + escapeHtml(tx.referenceId) + '</code></td>' +
          '<td style="padding:10px;"><span style="background:#e3f3e8;color:#1b6e38;padding:4px 8px;border-radius:3px;font-weight:700;font-size:11.5px;">' + escapeHtml(tx.status) + '</span></td>' +
        '</tr>';
      }).join('');

      bodyContent = '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin-bottom:22px;">' +
        '<div style="background:var(--navy-dark);color:#ffffff;padding:18px 20px;border-top:3px solid #1b6e38;">' +
          '<div style="font-size:11px;text-transform:uppercase;letter-spacing:0.1em;color:#cfd4e2;">Total Incoming Funds (USD $)</div>' +
          '<div style="font-family:var(--font-serif);font-size:32px;font-weight:700;margin:6px 0;color:#6ee799;">$' + totalUsdReceived.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}) + ' USD</div>' +
          '<div style="font-size:12px;color:#cfd4e2;">Across ' + (state.transactions || []).length + ' verified reader contributions</div>' +
        '</div>' +
        '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:18px 20px;">' +
          '<div style="font-size:11px;text-transform:uppercase;letter-spacing:0.1em;color:#5a606d;">Security &amp; Access Policy</div>' +
          '<div style="font-family:var(--font-serif);font-size:18px;font-weight:700;margin:6px 0;color:var(--ink-black);">Receive-Only Deposit Channels</div>' +
          '<div style="font-size:12px;color:#1b6e38;">No CVV, PIN, or security code is ever requested. Only Master Admin can remove channels; Chairman can view all incoming funds &amp; add receive-only cards/banks.</div>' +
        '</div>' +
      '</div>' +
      '<div style="display:grid;grid-template-columns:1fr 1.35fr;gap:24px;">' +
        '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:22px;">' +
          '<div class="kicker-red">RECEIVE-ONLY CARD &amp; BANK ADDITION STUDIO (NO CVV OR CODE REQUIRED)</div>' +
          '<h3 style="font-family:var(--font-serif);font-size:22px;margin:4px 0 8px;">Add Receive-Only Corporate Card or Bank Account</h3>' +
          '<p style="font-size:12px;color:#1b6e38;background:#eef8f1;padding:8px 10px;border:1px solid #b7e1c4;margin:0 0 12px;"><strong>Receive-Only Guarantee:</strong> Enter only the public remittance/deposit details required to receive funds. Never enter any CVV, PIN, or security code.</p>' +
          '<div style="display:flex;flex-direction:column;gap:12px;">' +
            '<div>' +
              '<label class="cms-label">Receiving Channel Type</label>' +
              '<select id="newPmCategory" class="cms-select">' +
                '<option value="CARD">Official US Business Corporate Card — Receive/Remittance Only (CSB NEWS USA LLC)</option>' +
                '<option value="US_BANK">United States Commercial Bank Account (ACH / Fedwire / Routing)</option>' +
                '<option value="BD_BANK">Bangladesh Bank &amp; MFS (BEFTN / NPSB / bKash / Nagad)</option>' +
                '<option value="INTL_WIRE">Worldwide International Wire Transfer (SWIFT / IBAN to USD)</option>' +
              '</select>' +
            '</div>' +
            '<div><label class="cms-label">Official Display Title</label><input type="text" id="newPmTitle" class="cms-input" placeholder="e.g. Official US Business Corporate Card — CSB NEWS USA LLC"/></div>' +
            '<div><label class="cms-label">Issuing Bank / Network</label><input type="text" id="newPmProvider" class="cms-input" placeholder="e.g. JPMorgan Chase Commercial / Visa Corporate"/></div>' +
            '<div><label class="cms-label">Beneficiary Entity Name</label><input type="text" id="newPmAccName" class="cms-input" value="CSB NEWS USA LLC"/></div>' +
            '<div><label class="cms-label">Receive-Only Deposit Card / Account Number (No CVV/Code)</label><input type="text" id="newPmAccNum" class="cms-input" placeholder="e.g. Deposit Card/Acct: 4246-3100-XXXX-8841"/></div>' +
            '<div><label class="cms-label">Routing / SWIFT / Registered Corporate Address</label><input type="text" id="newPmRouting" class="cms-input" value="166-41 88th Ave, Jamaica, NY 11432, USA · EIN Verified"/></div>' +
            '<div><label class="cms-label">Remittance Instructions for Supporters</label><textarea id="newPmInstructions" class="cms-textarea" rows="2" placeholder="Instructions shown in the Support Us modal..."></textarea></div>' +
            '<button type="button" class="btn-red-action" onclick="addPaymentMethodInCms()">+ Add Receive-Only Card / Bank to Support Us &#8599;</button>' +
          '</div>' +
        '</div>' +
        '<div style="display:flex;flex-direction:column;gap:18px;">' +
          '<div>' +
            '<h3 style="font-family:var(--font-serif);font-size:21px;margin:0 0 12px;">Active CSB NEWS USA LLC Receive-Only Cards &amp; Banks (' + state.paymentConfig.methods.length + ')</h3>' +
            '<div style="display:flex;flex-direction:column;gap:12px;">' + methodRows + '</div>' +
          '</div>' +
          '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:18px;">' +
            '<h3 style="font-family:var(--font-serif);font-size:20px;margin:0 0 12px;">Incoming Reader Patronage &amp; Transaction Ledger (How Much Came In &amp; How)</h3>' +
            '<table style="width:100%;border-collapse:collapse;text-align:left;">' +
              '<thead><tr style="border-bottom:2px solid var(--border-dark);font-size:11px;text-transform:uppercase;color:#5a606d;">' +
                '<th style="padding:8px;">Contributor</th><th style="padding:8px;">Amount Received (USD)</th><th style="padding:8px;">Receiving Card / Bank</th><th style="padding:8px;">Status</th>' +
              '</tr></thead>' +
              '<tbody>' + txRows + '</tbody>' +
            '</table>' +
          '</div>' +
        '</div>' +
      '</div>';
    } else if (activeCmsTab === 'users' && isEditorial) {
      var uRows = visibleUsers.map(function(u) {
        var verBadge = u.emailVerified
          ? '<span style="background:#e3f3e8;color:#1b6e38;padding:3px 8px;border-radius:3px;font-size:11px;font-weight:700;">Email Verified ✓</span>'
          : '<button type="button" class="platform-pill-btn" style="background:#fff3cd;color:#856404;border-color:#ffeeba;font-size:11px;padding:3px 8px;" onclick="openEmailVerifyModal(\'' + u.id + '\')">Unverified — Send 6-Digit Code &#8599;</button>';

        return '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px;">' +
          '<div style="display:flex;align-items:center;gap:14px;">' +
            '<img src="' + resolvePhoto(u.avatar) + '" alt="' + escapeHtml(u.name) + '" style="width:56px;height:56px;border-radius:50%;object-fit:cover;border:2px solid var(--navy-dark);background:var(--navy-dark);"/>' +
            '<div>' +
              '<div style="font-weight:700;font-size:15px;">' + escapeHtml(u.name) + ' <span style="font-size:12px;color:var(--accent-red);">[' + escapeHtml(u.role) + ']</span></div>' +
              '<div style="font-weight:400;font-size:12.5px;color:#454952;">' + escapeHtml(u.bio) + '</div>' +
              '<div style="font-size:11.5px;color:#5a606d;margin-top:4px;display:flex;align-items:center;gap:8px;flex-wrap:wrap;">' +
                '<span>Username: <code>' + escapeHtml(u.username) + '</code></span> · ' +
                '<span>Email: <code>' + escapeHtml(u.email) + '</code></span> ' +
                verBadge +
              '</div>' +
            '</div>' +
          '</div>' +
          '<div style="display:flex;gap:8px;">' +
            (u.status === 'pending_approval' ? '<button type="button" class="btn-red-action" onclick="approvePendingUserProfileDirectly(\'' + u.id + '\')">Approve Profile</button>' : '') +
            '<button type="button" class="platform-pill-btn" onclick="openContributorProfile(\'' + u.id + '\')">View Profile &#8599;</button>' +
          '</div>' +
        '</div>';
      }).join('');

      bodyContent = '<div style="display:grid;grid-template-columns:1fr 1.35fr;gap:24px;">' +
        '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:22px;">' +
          '<div class="kicker-red">USER ID &amp; EMAIL VERIFICATION STUDIO</div>' +
          '<h3 style="font-family:var(--font-serif);font-size:22px;margin:4px 0 14px;">Create Partial-Access ID</h3>' +
          '<div style="display:flex;flex-direction:column;gap:12px;">' +
            '<div><label class="cms-label">Full Name (Bold on Site)</label><input type="text" id="newUserName" class="cms-input" placeholder="e.g. Michael Sterling"/></div>' +
            '<div><label class="cms-label">Username / Login ID</label><input type="text" id="newUserUsername" class="cms-input" placeholder="e.g. MichaelSterling"/></div>' +
            '<div><label class="cms-label">Initial Password</label><input type="text" id="newUserPassword" class="cms-input" placeholder="Enter password..."/></div>' +
            '<div>' +
              '<label class="cms-label">Role Category (Partial Access)</label>' +
              '<select id="newUserRole" class="cms-select">' +
                '<option value="Editor">Editor (Partial Access)</option>' +
                '<option value="Administrator">Administrator (Partial Access)</option>' +
                '<option value="Author">Author (Partial Access)</option>' +
                '<option value="Contributor">Contributor (Report Submission + Bio &amp; Photo)</option>' +
                '<option value="Chairman">Chairman (Treasury &amp; Corporate Cards Access)</option>' +
                '<option value="Public Contributor (No Login)">Public Contributor Profile (No CMS Login Access)</option>' +
              '</select>' +
            '</div>' +
            '<div><label class="cms-label">Email Address (For Free 6-Digit Email Verification)</label><input type="email" id="newUserEmail" class="cms-input" placeholder="m.sterling@csbnewsusallc.news"/></div>' +
            '<div><label class="cms-label">Short Biography (Non-Bold Under Name)</label><textarea id="newUserBio" class="cms-textarea" rows="3" placeholder="Senior Correspondent covering U.S. policy and Atlantic trade based in New York."></textarea></div>' +
            '<div>' +
              '<label class="cms-label">Profile Picture Upload (&lt; 300 KB Any File)</label>' +
              '<input type="file" accept="image/*" onchange="handleNewUserAvatarUpload(this, \'new\')" style="font-size:12px;"/>' +
            '</div>' +
            '<button type="button" class="btn-red-action" onclick="createNewCmsUser()">Create User ID &#8599;</button>' +
          '</div>' +
        '</div>' +
        '<div style="display:flex;flex-direction:column;gap:12px;">' + uRows + '</div>' +
      '</div>';
    } else if (activeCmsTab === 'seo' && isChairmanOrSuper) {
      var socialInputs = PLATFORM_META.map(function(p) {
        var val = (state.socialLinks && state.socialLinks[p.key]) ? state.socialLinks[p.key] : '';
        return '<div>' +
          '<label class="cms-label">' + escapeHtml(p.label) + ' Official Page URL</label>' +
          '<input type="url" id="socialLink_' + p.key + '" class="cms-input" value="' + escapeHtml(val) + '"/>' +
        '</div>';
      }).join('');

      var logoPreview = (state.siteConfig && state.siteConfig.siteLogo) ? resolvePhoto(state.siteConfig.siteLogo) : resolvePhoto('@photo:logo');

      bodyContent = '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:22px;margin-bottom:22px;">' +
        '<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px;margin-bottom:16px;">' +
          '<div>' +
            '<div class="kicker-red">EXCELLENT-LEVEL GOOGLE SEARCH SERP PREVIEW &amp; 1-CLICK AUTO-SEO ENGINE (MASTER ADMIN &amp; CHAIRMAN)</div>' +
            '<h3 style="font-family:var(--font-serif);font-size:22px;margin:4px 0 0;">Live Google Search Appearance Preview</h3>' +
          '</div>' +
          '<div style="display:flex;gap:10px;flex-wrap:wrap;">' +
            '<button type="button" class="btn-red-action" onclick="runOneClickAutoSeoOptimization()">&#9889; Run 1-Click Complete SEO Optimization (100/100 Score)</button>' +
            '<button type="button" class="platform-pill-btn" onclick="downloadLiveSitemapXml()">&#11015; Download Live sitemap.xml</button>' +
          '</div>' +
        '</div>' +
        '<div style="background:#ffffff;border:1px solid #dadce0;border-radius:8px;padding:18px 22px;max-width:680px;font-family:Arial,sans-serif;box-shadow:0 2px 8px rgba(0,0,0,0.05);">' +
          '<div style="display:flex;align-items:center;gap:12px;margin-bottom:8px;">' +
            '<img src="' + logoPreview + '" alt="Logo" style="width:32px;height:32px;border-radius:50%;object-fit:cover;border:1px solid #e0e0e0;"/>' +
            '<div>' +
              '<div style="font-size:14px;color:#202124;font-weight:600;">WEEKLINE | CSB NEWS USA LLC</div>' +
              '<div style="font-size:12px;color:#4d5156;">' + escapeHtml(state.seoConfig.canonicalUrl || 'https://yourdomain.com') + '</div>' +
            '</div>' +
          '</div>' +
          '<div style="font-size:20px;color:#1a0dab;margin-bottom:6px;cursor:pointer;">' + escapeHtml(state.seoConfig.siteTitle || 'WEEKLINE | CSB NEWS USA LLC') + '</div>' +
          '<div style="font-size:14px;color:#4d5156;line-height:1.5;">' + escapeHtml(state.seoConfig.metaDescription) + '</div>' +
        '</div>' +
        '<div style="margin-top:16px;background:#faf7f0;border:1px solid #d5cdbc;padding:14px 16px;display:flex;align-items:center;gap:12px;flex-wrap:wrap;">' +
          '<strong style="font-size:12.5px;">Basic / Assistant SEO Quick-Wizard:</strong>' +
          '<input type="text" id="basicSeoFocusInput" class="cms-input" style="max-width:340px;" placeholder="Enter topic or focus keywords (e.g. Global Geopolitics &amp; US Policy)"/>' +
          '<button type="button" class="platform-pill-btn" style="background:var(--navy-dark);color:#fff;" onclick="runBasicSeoQuickWizard()">Apply Basic SEO Automatically &#8599;</button>' +
        '</div>' +
      '</div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;">' +
        '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:22px;">' +
          '<div class="kicker-red">GLOBAL SEO CONTROL CENTER</div>' +
          '<h3 style="font-family:var(--font-serif);font-size:22px;margin:4px 0 16px;">Search Engine Optimization</h3>' +
          '<div style="display:flex;flex-direction:column;gap:14px;">' +
            '<div><label class="cms-label">Global Site Title (Google Search Headline)</label><input type="text" id="seoSiteTitle" class="cms-input" value="' + escapeHtml(state.seoConfig.siteTitle) + '"/></div>' +
            '<div><label class="cms-label">Global Short Description (Under Title in Google Search)</label><textarea id="seoMetaDesc" class="cms-textarea" rows="3">' + escapeHtml(state.seoConfig.metaDescription) + '</textarea></div>' +
            '<div><label class="cms-label">Focus Meta Keywords</label><input type="text" id="seoMetaKeywords" class="cms-input" value="' + escapeHtml(state.seoConfig.metaKeywords) + '"/></div>' +
            '<div><label class="cms-label">Canonical Website URL</label><input type="url" id="seoCanonicalUrl" class="cms-input" value="' + escapeHtml(state.seoConfig.canonicalUrl) + '"/></div>' +
            '<div><label class="cms-label">Editorial Destination Email</label><input type="email" id="seoEditorialEmail" class="cms-input" value="' + escapeHtml(state.seoConfig.editorialEmail) + '"/></div>' +
            '<button type="button" class="btn-red-action" onclick="saveGlobalSeoAndSocial()">Save Global SEO &amp; Social Links &#8599;</button>' +
          '</div>' +
        '</div>' +
        '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:22px;">' +
          '<div class="kicker-red">OFFICIAL SOCIAL CHANNELS (7 PLATFORMS)</div>' +
          '<h3 style="font-family:var(--font-serif);font-size:22px;margin:4px 0 10px;">End-of-Article &amp; Footer Platform Links</h3>' +
          '<div style="display:flex;flex-direction:column;gap:12px;">' + socialInputs + '</div>' +
        '</div>' +
      '</div>';
    } else if (activeCmsTab === 'backup' && isChairmanOrSuper) {
      var backupRows = serverBackupsList.map(function(b) {
        return '<tr style="border-bottom:1px solid #e2dac9;font-size:13px;">' +
          '<td style="padding:10px;"><code>' + escapeHtml(b.filename) + '</code></td>' +
          '<td style="padding:10px;">' + escapeHtml(String(b.sizeKB)) + ' KB</td>' +
          '<td style="padding:10px;color:#5a606d;">' + escapeHtml(b.modifiedAt) + '</td>' +
          '<td style="padding:10px;text-align:right;">' +
            (b.filename.indexOf('.json') !== -1 ? '<button type="button" class="platform-pill-btn" onclick="restoreFromServerSnapshot(\'' + escapeHtml(b.filename) + '\')">Restore Snapshot &#8634;</button>' : '<span style="font-size:11.5px;color:#1b6e38;font-weight:700;">SQLite / Archive Ready ✓</span>') +
          '</td>' +
        '</tr>';
      }).join('');

      bodyContent = '<div style="display:grid;grid-template-columns:1.1fr 1.2fr;gap:24px;">' +
        '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:24px;">' +
          '<div class="kicker-red">1-CLICK COMPLETE WEBSITE BACKUP &amp; RESTORE STUDIO</div>' +
          '<h3 style="font-family:var(--font-serif);font-size:22px;margin:4px 0 10px;">Download or Restore Full Website Backup</h3>' +
          '<p style="font-size:13px;color:#454952;line-height:1.55;margin:0 0 16px;">Every article, multi-category assignment, contributor profile, password, custom page block, motion ad, SEO configuration, and treasury transaction is stored in both <code>data/store.json</code> and SQLite <code>data/weekline_cms.sqlite3</code>.</p>' +
          '<div style="display:flex;flex-direction:column;gap:14px;">' +
            '<div style="background:#faf7f0;border:1px solid #d5cdbc;padding:16px;">' +
              '<div style="font-weight:700;font-size:14px;color:var(--navy-dark);margin-bottom:6px;">1. Download Full Backup File to Your Computer / Phone</div>' +
              '<div style="font-size:12px;color:#5a606d;margin-bottom:10px;">Exports a complete timestamped <code>.json</code> master backup containing all ' + state.articles.length + ' essays, ' + state.categories.length + ' categories, users, and settings.</div>' +
              '<button type="button" class="btn-red-action" style="width:100%;justify-content:center;padding:11px;" onclick="downloadFullCmsBackupJson()">&#11015; Download Full Website Backup (.json) Now</button>' +
            '</div>' +
            '<div style="background:#faf7f0;border:1px solid #d5cdbc;padding:16px;">' +
              '<div style="font-weight:700;font-size:14px;color:var(--navy-dark);margin-bottom:6px;">2. Create Live Server Snapshot on Hostinger (<code>backups/</code>)</div>' +
              '<div style="font-size:12px;color:#5a606d;margin-bottom:10px;">Triggers the Python CMS backup engine (<code>app.py</code> / <code>backup_manager.py</code>) to save a timestamped snapshot on the server.</div>' +
              '<button type="button" class="platform-pill-btn" style="background:var(--navy-dark);color:#ffffff;width:100%;justify-content:center;padding:10px;" onclick="triggerServerSnapshotBackup()">+ Create Server Snapshot in backups/ Folder &#8599;</button>' +
            '</div>' +
            '<div style="background:#fff8eb;border:1px solid #e0c285;padding:16px;">' +
              '<div style="font-weight:700;font-size:14px;color:var(--ink-black);margin-bottom:6px;">3. Restore Website from Any Backup File (.json)</div>' +
              '<div style="font-size:12px;color:#5a606d;margin-bottom:8px;">Select any previously downloaded <code>weekline-full-backup-*.json</code> file to restore immediately:</div>' +
              '<input type="file" accept=".json,application/json" onchange="restoreCmsFromUploadedBackup(this)" style="font-size:12px;width:100%;"/>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div style="display:flex;flex-direction:column;gap:18px;">' +
          '<div style="background:var(--navy-dark);color:#ffffff;padding:20px 24px;border-top:4px solid #1b6e38;">' +
            '<div class="kicker-red" style="color:#6ee799;">PYTHON 3 CMS ENGINE + SQLITE3 &amp; JSON DUAL PERSISTENCE</div>' +
            '<h3 style="font-family:var(--font-serif);font-size:21px;margin:4px 0 8px;">Hostinger Python CMS Architecture Included in Package</h3>' +
            '<div style="font-size:12.5px;color:#dbe2f0;line-height:1.6;font-family:monospace;background:rgba(255,255,255,0.06);padding:12px;border:1px solid rgba(255,255,255,0.15);">' +
              '<div>&#10003; <strong>app.py</strong> — Python 3 WSGI + Standalone CMS Server &amp; SQLite Sync</div>' +
              '<div>&#10003; <strong>passenger_wsgi.py</strong> — Hostinger Python App WSGI Entry Point</div>' +
              '<div>&#10003; <strong>api.py</strong> — Executable Python CGI Endpoint (chmod 755)</div>' +
              '<div>&#10003; <strong>backup_manager.py</strong> — Python CLI &amp; Cron Backup Utility</div>' +
              '<div>&#10003; <strong>data/weekline_cms.sqlite3</strong> — Relational SQLite3 Database</div>' +
              '<div>&#10003; <strong>data/store.json</strong> — Live JSON Database Store</div>' +
              '<div>&#10003; <strong>api.php</strong> — Automatic Zero-Config Shared Hosting Bridge</div>' +
            '</div>' +
          '</div>' +
          '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:20px;">' +
            '<h3 style="font-family:var(--font-serif);font-size:20px;margin:0 0 12px;">Available Server Snapshots in <code>backups/</code></h3>' +
            '<table style="width:100%;border-collapse:collapse;text-align:left;">' +
              '<thead><tr style="border-bottom:2px solid var(--border-dark);font-size:11px;text-transform:uppercase;color:#5a606d;">' +
                '<th style="padding:8px;">Backup Filename</th><th style="padding:8px;">Size</th><th style="padding:8px;">Timestamp</th><th style="padding:8px;text-align:right;">Action</th>' +
              '</tr></thead>' +
              '<tbody>' + backupRows + '</tbody>' +
            '</table>' +
          '</div>' +
        '</div>' +
      '</div>';
    } else if (activeCmsTab === 'profile') {
      var myVerBadge = currentUser.emailVerified
        ? '<span style="background:#e3f3e8;color:#1b6e38;padding:4px 10px;border-radius:3px;font-size:12px;font-weight:700;">Verified ✓</span>'
        : '<button type="button" class="platform-pill-btn" onclick="openEmailVerifyModal(\'' + currentUser.id + '\')">Send 6-Digit Verification Code &#8599;</button>';

      bodyContent = '<div style="background:#ffffff;border:1px solid #d5cdbc;padding:26px;max-width:640px;">' +
        '<div class="kicker-red">ACCOUNT SETTINGS, EMAIL VERIFICATION &amp; PASSWORD CHANGE</div>' +
        '<h3 style="font-family:var(--font-serif);font-size:24px;margin:4px 0 18px;">My Profile (' + escapeHtml(currentUser.username) + ')</h3>' +
        '<div style="display:flex;align-items:center;gap:18px;margin-bottom:20px;">' +
          '<img src="' + resolvePhoto(currentUser.avatar) + '" alt="' + escapeHtml(currentUser.name) + '" style="width:80px;height:80px;border-radius:50%;object-fit:cover;border:2px solid var(--navy-dark);background:var(--navy-dark);"/>' +
          '<div>' +
            '<div style="font-weight:700;font-size:16px;">' + escapeHtml(currentUser.name) + '</div>' +
            '<div style="font-size:13px;color:#5a606d;margin-bottom:6px;">' + escapeHtml(currentUser.role) + '</div>' +
            myVerBadge +
          '</div>' +
        '</div>' +
        '<div style="display:flex;flex-direction:column;gap:14px;">' +
          '<div><label class="cms-label">Display Name (Bold on Site — e.g. Editor 1 or Your Custom Name)</label><input type="text" id="myProfName" class="cms-input" value="' + escapeHtml(currentUser.name) + '"/></div>' +
          (!currentUser.isHiddenSuper ? '<div><label class="cms-label">Username / Login ID</label><input type="text" id="myProfUsername" class="cms-input" value="' + escapeHtml(currentUser.username) + '"/></div>' : '') +
          '<div><label class="cms-label">Email Address</label><input type="email" id="myProfEmail" class="cms-input" value="' + escapeHtml(currentUser.email || '') + '"/></div>' +
          '<div><label class="cms-label">Short Biography (Non-Bold)</label><textarea id="myProfBio" class="cms-textarea" rows="3">' + escapeHtml(currentUser.bio) + '</textarea></div>' +
          '<div><label class="cms-label">Update Profile DP Picture (&lt; 300 KB Any File)</label><input type="file" accept="image/*" onchange="handleNewUserAvatarUpload(this, \'profile\')" style="font-size:12px;"/></div>' +
          '<div><label class="cms-label">Change Password</label><input type="password" id="myProfNewPass" class="cms-input" placeholder="Enter new password..."/></div>' +
          '<button type="button" class="btn-red-action" onclick="saveMyProfileAndPassword()">Save Profile &amp; Update Password &#8599;</button>' +
        '</div>' +
      '</div>';
    }

    return '<div class="journal-section" style="padding-top:28px;">' +
      '<div style="background:var(--navy-dark);color:#ffffff;padding:20px 26px;border-top:4px solid var(--accent-red);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;margin-bottom:20px;">' +
        '<div style="display:flex;align-items:center;gap:14px;">' +
          '<img src="' + resolvePhoto(currentUser.avatar) + '" alt="' + escapeHtml(currentUser.name) + '" style="width:52px;height:52px;border-radius:50%;object-fit:cover;border:2px solid var(--accent-red);background:var(--navy-dark);"/>' +
          '<div>' +
            '<div class="kicker-red">LOGGED IN AS ' + escapeHtml(currentUser.role) + (isSuper ? ' (HIDDEN MASTER ACCOUNT)' : '') + '</div>' +
            '<div style="font-family:var(--font-serif);font-size:22px;font-weight:700;">' + escapeHtml(currentUser.name) + ' <span style="font-size:13px;font-weight:400;color:#cfd4e2;">(' + escapeHtml(currentUser.username) + ')</span></div>' +
          '</div>' +
        '</div>' +
        '<div style="display:flex;align-items:center;gap:10px;">' +
          '<button type="button" class="btn-outline-white" onclick="goHome(\'ALL\')">View Live Website</button>' +
          '<button type="button" class="btn-red-action" onclick="handleCmsLogout()">Sign Out</button>' +
        '</div>' +
      '</div>' +
      '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:24px;">' + tabButtons + '</div>' +
      bodyContent +
    '</div>';
  }

  function renderFooterSocialButtons() {
    var box = document.getElementById('footerSocialRow');
    if (!box) return;
    box.innerHTML = PLATFORM_META.map(function(p) {
      var url = (state.socialLinks && state.socialLinks[p.key]) ? state.socialLinks[p.key] : 'https://weekline-editorial-demo.vastnewt128.chatgpt.site/';
      return '<a href="' + escapeHtml(url) + '" target="_blank" rel="noopener noreferrer" class="social-sq-btn" title="Follow on ' + p.label + '">' +
        getPlatformIconSvg(p.key) +
      '</a>';
    }).join('');
  }

  function updateVisitorClock() {
    var el = document.getElementById('dhakaClockText');
    if (!el) return;
    try {
      var now = new Date();
      var tz = 'America/New_York';
      try {
        var resolved = Intl.DateTimeFormat().resolvedOptions().timeZone;
        if (resolved) tz = resolved;
      } catch (e) {}
      var hh = String(now.getHours()).padStart(2, '0');
      var mm = String(now.getMinutes()).padStart(2, '0');
      var offsetMin = -now.getTimezoneOffset();
      var sign = offsetMin >= 0 ? '+' : '-';
      var absMin = Math.abs(offsetMin);
      var offH = Math.floor(absMin / 60);
      var offM = absMin % 60;
      var gmtStr = 'GMT' + sign + offH + (offM ? (':' + String(offM).padStart(2, '0')) : '');
      el.textContent = tz + ' · ' + hh + ':' + mm + ' ' + gmtStr;
    } catch (e) {}
  }

  function applyHashRoute() {
    var h = window.location.hash || '';
    if (h === '#cms' || window.location.search.indexOf('cms=1') !== -1 || /\/(cms|admin|dashboard)\/?$/i.test(window.location.pathname)) {
      currentView = 'cms';
    } else if (h === '#contributors') {
      currentView = 'contributors';
    } else if (h.indexOf('#article/') === 0) {
      currentArticleId = decodeURIComponent(h.slice(9));
      currentView = 'article';
    } else if (h.indexOf('#author/') === 0) {
      var parts = h.slice(8).split('/page/');
      currentProfileUserId = decodeURIComponent(parts[0] || 'u_weekline_desk');
      profileCurrentPage = parseInt(parts[1] || '1', 10) || 1;
      currentView = 'profile';
    } else if (h.indexOf('#category/') === 0) {
      var cParts = h.slice(10).split('/page/');
      activeCategory = decodeURIComponent(cParts[0] || 'ALL');
      currentPage = parseInt(cParts[1] || '1', 10) || 1;
      currentView = 'home';
    } else if (h.indexOf('#page/') === 0) {
      currentPage = parseInt(h.slice(6), 10) || 1;
      currentView = 'home';
    }
  }

  window.addEventListener('hashchange', function() {
    applyHashRoute();
    renderMainView();
  });

  window.addEventListener('DOMContentLoaded', function() {
    loadState();
    applySiteConfigToDom();
    syncCategoryNavBarDom();
    initUniqueArticleWebpEngine();
    applyHashRoute();
    renderFooterSocialButtons();
    renderSupportModalBody();
    renderMainView();
    updateVisitorClock();
    setInterval(updateVisitorClock, 30000);
  });
})();
