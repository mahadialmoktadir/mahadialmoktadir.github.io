#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse
import datetime
import json
import os
import zipfile
from app import (
    BASE_DIR,
    BACKUPS_DIR,
    DATA_DIR,
    UPLOADS_DIR,
    create_snapshot_backup,
    list_available_backups,
    load_store,
    save_store,
    sync_to_sqlite,
)


def create_full_archive_zip():
    os.makedirs(BACKUPS_DIR, exist_ok=True)
    ts = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d")
    zip_name = f"weekline_full_backup_{ts}.zip"
    zip_path = os.path.join(BACKUPS_DIR, zip_name)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for folder in (DATA_DIR, UPLOADS_DIR):
            if os.path.isdir(folder):
                for root, _, files in os.walk(folder):
                    for fn in files:
                        full_p = os.path.join(root, fn)
                        rel_p = os.path.relpath(full_p, BASE_DIR)
                        zf.write(full_p, rel_p)
    return zip_name


def main():
    parser = argparse.ArgumentParser(description="WEEKLINE Python CMS Backup & Restore Utility")
    parser.add_argument("--create", action="store_true", help="Create a timestamped JSON + SQLite + ZIP backup")
    parser.add_argument("--list", action="store_true", help="List all available backups in backups/")
    parser.add_argument("--restore", type=str, help="Restore database from a backup JSON file in backups/")
    args = parser.parse_args()

    if args.create:
        data = load_store()
        if data:
            sync_to_sqlite(data)
        snap = create_snapshot_backup("cli")
        zname = create_full_archive_zip()
        print(f"Created snapshot: {snap} and archive: {zname}")
    elif args.restore:
        target = os.path.join(BACKUPS_DIR, os.path.basename(args.restore))
        if os.path.exists(target):
            with open(target, "r", encoding="utf-8") as f:
                data = json.load(f)
            save_store(data, create_rolling_backup=False)
            print(f"Successfully restored store.json and SQLite database from {args.restore}")
        else:
            print(f"Backup file not found: {target}")
    else:
        for b in list_available_backups():
            print(f"{b['filename']:45s} | {b['sizeKB']:8.1f} KB | {b['modifiedAt']}")


if __name__ == "__main__":
    main()
