<?php
/**
 * WEEKLINE Editorial & CMS Universal Backend Bridge (Hostinger Python 3 + PHP 8.x Auto-Fallback)
 * Works seamlessly alongside `app.py`, `passenger_wsgi.py`, and `api.py`.
 * Supports multi-category articles, live view counting (increment_view), automated & 1-click backups
 * in `backups/`, WebP uploads, and editorial email dispatch to editorial@csbnewsusallc.news.
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$dataDir = __DIR__ . '/data';
$dataFile = $dataDir . '/store.json';
$uploadsDir = __DIR__ . '/uploads';
$backupsDir = __DIR__ . '/backups';

foreach ([$dataDir, $uploadsDir, $backupsDir] as $dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
}

$action = isset($_GET['action']) ? $_GET['action'] : 'ping';

function listServerBackups($backupsDir) {
    $items = [];
    if (is_dir($backupsDir)) {
        $files = scandir($backupsDir, SCANDIR_SORT_DESCENDING);
        foreach ($files as $fn) {
            if (preg_match('/\.(json|sqlite3|zip)$/i', $fn)) {
                $p = $backupsDir . '/' . $fn;
                $items[] = [
                    'filename' => $fn,
                    'sizeKB' => round(filesize($p) / 1024, 1),
                    'modifiedAt' => gmdate('Y-m-d H:i:s \U\T\C', filemtime($p))
                ];
            }
        }
    }
    return $items;
}

if ($action === 'ping') {
    echo json_encode([
        'ok' => true,
        'engine' => 'python3+php_bridge',
        'server' => 'Hostinger Python 3 & PHP Universal CMS Ready'
    ]);
    exit;
}

if ($action === 'load') {
    if (file_exists($dataFile)) {
        echo file_get_contents($dataFile);
    } else {
        echo json_encode(['ok' => false, 'error' => 'store.json not found']);
    }
    exit;
}

if ($action === 'save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw, true);
    if ($decoded && isset($decoded['articles']) && isset($decoded['users'])) {
        foreach ($decoded['articles'] as &$art) {
            if (empty($art['categories']) || !is_array($art['categories'])) {
                $art['categories'] = [isset($art['category']) ? $art['category'] : 'Weekline Exclusive'];
            }
            $art['category'] = $art['categories'][0];
        }
        unset($art);
        $encoded = json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        file_put_contents($dataFile, $encoded);
        @file_put_contents($backupsDir . '/auto_backup_latest.json', $encoded);
        echo json_encode(['ok' => true, 'savedAt' => gmdate('c')]);
    } else {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Invalid payload']);
    }
    exit;
}

if ($action === 'increment_view' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $payload = json_decode($raw, true);
    $artId = isset($payload['articleId']) ? $payload['articleId'] : '';
    if ($artId && file_exists($dataFile)) {
        $db = json_decode(file_get_contents($dataFile), true);
        if ($db && isset($db['articles'])) {
            $newViews = 0;
            foreach ($db['articles'] as &$a) {
                if (isset($a['id']) && $a['id'] === $artId) {
                    $a['views'] = (isset($a['views']) ? (int)$a['views'] : 0) + 1;
                    $newViews = $a['views'];
                    break;
                }
            }
            unset($a);
            file_put_contents($dataFile, json_encode($db, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
            echo json_encode(['ok' => true, 'articleId' => $artId, 'views' => $newViews]);
            exit;
        }
    }
    echo json_encode(['ok' => false]);
    exit;
}

if ($action === 'create_backup') {
    if (file_exists($dataFile)) {
        $fname = 'weekline_backup_' . gmdate('Ymd_His') . '_cms.json';
        @copy($dataFile, $backupsDir . '/' . $fname);
        echo json_encode([
            'ok' => true,
            'createdBackup' => $fname,
            'backups' => listServerBackups($backupsDir)
        ]);
        exit;
    }
    echo json_encode(['ok' => false, 'error' => 'store.json not found']);
    exit;
}

if ($action === 'list_backups') {
    echo json_encode([
        'ok' => true,
        'backups' => listServerBackups($backupsDir)
    ]);
    exit;
}

if ($action === 'restore_backup' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $req = json_decode($raw, true);
    $fname = isset($req['filename']) ? basename($req['filename']) : '';
    $fpath = $backupsDir . '/' . $fname;
    if ($fname && file_exists($fpath) && preg_match('/\.json$/i', $fname)) {
        $restored = json_decode(file_get_contents($fpath), true);
        if ($restored && isset($restored['articles']) && isset($restored['users'])) {
            file_put_contents($dataFile, json_encode($restored, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
            echo json_encode(['ok' => true, 'restoredFrom' => $fname, 'state' => $restored]);
            exit;
        }
    }
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Backup file not found or invalid']);
    exit;
}

if ($action === 'upload' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $payload = json_decode($raw, true);
    if (!$payload || empty($payload['dataUri'])) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Missing image dataUri']);
        exit;
    }
    $type = isset($payload['uploadType']) ? $payload['uploadType'] : 'featured';
    $dataUri = $payload['dataUri'];
    if (preg_match('/^data:image\/(\w+);base64,/', $dataUri, $matches)) {
        $ext = strtolower($matches[1]);
        if ($ext === 'jpeg') $ext = 'jpg';
        $base64Data = substr($dataUri, strpos($dataUri, ',') + 1);
        $binary = base64_decode($base64Data);
        $maxBytes = ($type === 'avatar') ? (300 * 1024) : (1024 * 1024);
        if (strlen($binary) > $maxBytes) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => 'File exceeds maximum allowed size']);
            exit;
        }
        $filename = $type . '_' . time() . '_' . substr(md5(uniqid()), 0, 6) . '.' . $ext;
        $targetPath = $uploadsDir . '/' . $filename;
        if (file_put_contents($targetPath, $binary) !== false) {
            echo json_encode(['ok' => true, 'url' => 'uploads/' . $filename]);
            exit;
        }
    }
    echo json_encode(['ok' => true, 'url' => $dataUri]);
    exit;
}

if ($action === 'send_editorial_mail' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $sub = json_decode($raw, true);
    if ($sub) {
        $to = !empty($sub['emailedTo']) ? $sub['emailedTo'] : 'editorial@csbnewsusallc.news';
        $cats = !empty($sub['categories']) && is_array($sub['categories']) ? implode(', ', $sub['categories']) : ($sub['category'] ?? 'Analysis');
        $subject = '[WEEKLINE Write for Us] ' . ($sub['headline'] ?? 'New Submission') . ' — by ' . ($sub['contributorName'] ?? 'Contributor');
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
        $headers .= "From: WEEKLINE Editorial Desk <editorial@csbnewsusallc.news>\r\n";
        if (!empty($sub['contributorEmail'])) {
            $headers .= "Reply-To: " . $sub['contributorEmail'] . "\r\n";
        }
        $htmlMsg = "<h2>New WEEKLINE Contributor Submission (Waiting for Approval)</h2>"
            . "<p><strong>Contributor Name (Bold):</strong> " . htmlspecialchars($sub['contributorName'] ?? '') . "</p>"
            . "<p><strong>Short Biography (Non-Bold):</strong> " . htmlspecialchars($sub['contributorBio'] ?? '') . "</p>"
            . "<p><strong>Email:</strong> " . htmlspecialchars($sub['contributorEmail'] ?? '') . "</p>"
            . "<p><strong>Categories (Bold):</strong> <strong>" . htmlspecialchars($cats) . "</strong></p>"
            . "<p><strong>Headline:</strong> " . htmlspecialchars($sub['headline'] ?? '') . "</p>"
            . "<p><strong>Subtitle:</strong> " . htmlspecialchars($sub['subtitle'] ?? '') . "</p><hr/>"
            . ($sub['body'] ?? '');
        $sent = @mail($to, $subject, $htmlMsg, $headers);
        echo json_encode(['ok' => true, 'mailDispatched' => (bool)$sent, 'to' => $to]);
        exit;
    }
    echo json_encode(['ok' => false]);
    exit;
}

if ($action === 'send_verification_email' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $req = json_decode($raw, true);
    if ($req && !empty($req['email']) && !empty($req['code'])) {
        $to = $req['email'];
        $code = $req['code'];
        $name = $req['name'] ?? 'WEEKLINE User';
        $subject = 'Your WEEKLINE Account Verification Code: ' . $code;
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
        $headers .= "From: WEEKLINE Security <editorial@csbnewsusallc.news>\r\n";
        $htmlMsg = "<div style='font-family:Georgia,serif;max-width:520px;padding:24px;border:1px solid #d4cbb8;background:#faf7f0;'>"
            . "<h2 style='color:#060d3a;margin:0 0 12px;'>WEEKLINE — Email Verification</h2>"
            . "<p>Hello <strong>" . htmlspecialchars($name) . "</strong>,</p>"
            . "<p>Use the 6-digit confirmation code below to verify your email address on the WEEKLINE Editorial CMS:</p>"
            . "<div style='background:#060d3a;color:#ffffff;font-size:28px;font-weight:700;letter-spacing:0.25em;padding:14px 20px;text-align:center;margin:18px 0;'>"
            . htmlspecialchars($code)
            . "</div>"
            . "<p style='font-size:12px;color:#5a606d;'>A weekly publication by CSB NEWS USA LLC · 166-41 88th Ave, Jamaica, NY 11432</p>"
            . "</div>";
        $sent = @mail($to, $subject, $htmlMsg, $headers);
        echo json_encode(['ok' => true, 'mailDispatched' => (bool)$sent, 'to' => $to]);
        exit;
    }
    echo json_encode(['ok' => false, 'error' => 'Missing email or code']);
    exit;
}

if ($action === 'save_transaction' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $tx = json_decode($raw, true);
    if ($tx && file_exists($dataFile)) {
        $db = json_decode(file_get_contents($dataFile), true);
        if ($db) {
            if (!isset($db['transactions'])) $db['transactions'] = [];
            array_unshift($db['transactions'], $tx);
            file_put_contents($dataFile, json_encode($db, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
            echo json_encode(['ok' => true]);
            exit;
        }
    }
    echo json_encode(['ok' => false]);
    exit;
}

echo json_encode(['ok' => false, 'error' => 'Unknown action']);
