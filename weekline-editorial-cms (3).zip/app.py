#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WEEKLINE Editorial & CMS — Python 3 Backend Engine (Hostinger WSGI / CGI / Standalone Server)
A weekly publication by CSB NEWS USA LLC · 166-41 88th Ave, Jamaica, NY 11432, United States
"""
import base64
import datetime
import hashlib
import json
import mimetypes
import os
import re
import shutil
import smtplib
import sqlite3
import subprocess
import sys
import urllib.parse
from email.message import EmailMessage
from wsgiref.simple_server import make_server

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
STORE_FILE = os.path.join(DATA_DIR, "store.json")
SQLITE_FILE = os.path.join(DATA_DIR, "weekline_cms.sqlite3")
UPLOADS_DIR = os.path.join(BASE_DIR, "uploads")
BACKUPS_DIR = os.path.join(BASE_DIR, "backups")


def ensure_directories():
    for d in (DATA_DIR, UPLOADS_DIR, BACKUPS_DIR):
        os.makedirs(d, exist_ok=True)


def sync_to_sqlite(state_dict):
    ensure_directories()
    conn = sqlite3.connect(SQLITE_FILE)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS kv_store (
            k TEXT PRIMARY KEY,
            v TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS articles (
            id TEXT PRIMARY KEY,
            title TEXT,
            subtitle TEXT,
            primary_category TEXT,
            categories_json TEXT,
            author_id TEXT,
            pub_date TEXT,
            views INTEGER DEFAULT 0,
            status TEXT,
            is_hero INTEGER DEFAULT 0,
            raw_json TEXT
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            username TEXT,
            name TEXT,
            role TEXT,
            email TEXT,
            status TEXT,
            raw_json TEXT
        )
    """)
    now_iso = datetime.datetime.now(datetime.timezone.utc).isoformat()
    cur.execute(
        "INSERT OR REPLACE INTO kv_store (k, v, updated_at) VALUES (?, ?, ?)",
        ("full_state", json.dumps(state_dict, ensure_ascii=False), now_iso),
    )

    cur.execute("DELETE FROM articles")
    for a in state_dict.get("articles", []):
        cats = a.get("categories") or ([a["category"]] if a.get("category") else ["Analysis"])
        cur.execute(
            """INSERT OR REPLACE INTO articles
               (id, title, subtitle, primary_category, categories_json, author_id, pub_date, views, status, is_hero, raw_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                a.get("id", ""),
                a.get("title", ""),
                a.get("subtitle", ""),
                a.get("category", cats[0] if cats else ""),
                json.dumps(cats, ensure_ascii=False),
                a.get("authorId", ""),
                a.get("date", ""),
                int(a.get("views", 0) or 0),
                a.get("status", "published"),
                1 if a.get("isHero") else 0,
                json.dumps(a, ensure_ascii=False),
            ),
        )

    cur.execute("DELETE FROM users")
    for u in state_dict.get("users", []):
        cur.execute(
            """INSERT OR REPLACE INTO users (id, username, name, role, email, status, raw_json)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                u.get("id", ""),
                u.get("username", ""),
                u.get("name", ""),
                u.get("role", ""),
                u.get("email", ""),
                u.get("status", "active"),
                json.dumps(u, ensure_ascii=False),
            ),
        )

    conn.commit()
    conn.close()


def load_store():
    ensure_directories()
    if os.path.exists(STORE_FILE):
        with open(STORE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    if os.path.exists(SQLITE_FILE):
        conn = sqlite3.connect(SQLITE_FILE)
        cur = conn.cursor()
        cur.execute("SELECT v FROM kv_store WHERE k = 'full_state'")
        row = cur.fetchone()
        conn.close()
        if row:
            data = json.loads(row[0])
            save_store(data, create_rolling_backup=False)
            return data
    return None


def save_store(state_dict, create_rolling_backup=True):
    ensure_directories()
    for a in state_dict.get("articles", []):
        cats = a.get("categories")
        if not cats or not isinstance(cats, list):
            cats = [a.get("category", "Weekline Exclusive")]
        a["categories"] = cats
        a["category"] = cats[0]

    with open(STORE_FILE, "w", encoding="utf-8") as f:
        json.dump(state_dict, f, indent=2, ensure_ascii=False)

    try:
        sync_to_sqlite(state_dict)
    except Exception:
        pass

    if create_rolling_backup:
        try:
            latest_backup = os.path.join(BACKUPS_DIR, "auto_backup_latest.json")
            with open(latest_backup, "w", encoding="utf-8") as bf:
                json.dump(state_dict, bf, indent=2, ensure_ascii=False)
        except Exception:
            pass


def create_snapshot_backup(label="manual"):
    ensure_directories()
    data = load_store()
    if not data:
        return None
    ts = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%d_%H%M%S")
    safe_label = re.sub(r"[^a-zA-Z0-9_-]", "", label or "snapshot")[:24]
    fname = f"weekline_backup_{ts}_{safe_label}.json"
    fpath = os.path.join(BACKUPS_DIR, fname)
    with open(fpath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    if os.path.exists(SQLITE_FILE):
        shutil.copy2(SQLITE_FILE, os.path.join(BACKUPS_DIR, f"weekline_cms_{ts}.sqlite3"))
    return fname


def list_available_backups():
    ensure_directories()
    items = []
    for fn in sorted(os.listdir(BACKUPS_DIR), reverse=True):
        if fn.endswith((".json", ".sqlite3", ".zip")):
            p = os.path.join(BACKUPS_DIR, fn)
            st = os.stat(p)
            items.append({
                "filename": fn,
                "sizeKB": round(st.st_size / 1024.0, 1),
                "modifiedAt": datetime.datetime.fromtimestamp(st.st_mtime, datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
            })
    return items


def send_html_email(to_addr, subject, html_body, reply_to=None):
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = "WEEKLINE Editorial Desk <editorial@csbnewsusallc.news>"
    msg["To"] = to_addr
    if reply_to:
        msg["Reply-To"] = reply_to
    msg.set_content("Please view this message in an HTML-compatible email client.")
    msg.add_alternative(html_body, subtype="html")

    sendmail_bin = shutil.which("sendmail") or "/usr/sbin/sendmail"
    if os.path.exists(sendmail_bin):
        try:
            proc = subprocess.Popen([sendmail_bin, "-t", "-oi"], stdin=subprocess.PIPE)
            proc.communicate(msg.as_bytes(), timeout=8)
            if proc.returncode == 0:
                return True
        except Exception:
            pass
    try:
        with smtplib.SMTP("localhost", 25, timeout=5) as s:
            s.send_message(msg)
            return True
    except Exception:
        return False


def handle_api_action(action, method, raw_body):
    if action == "ping":
        return 200, {
            "ok": True,
            "engine": "python3",
            "server": "Hostinger Python 3 CMS & SQLite/JSON Backup Engine Ready",
            "pythonVersion": sys.version.split()[0],
        }

    if action == "load":
        data = load_store()
        if data:
            return 200, data
        return 404, {"ok": False, "error": "store.json not found"}

    if action == "save" and method == "POST":
        try:
            payload = json.loads(raw_body or "{}")
            if payload and "articles" in payload and "users" in payload:
                save_store(payload, create_rolling_backup=True)
                return 200, {
                    "ok": True,
                    "engine": "python3",
                    "savedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                }
        except Exception as e:
            return 400, {"ok": False, "error": str(e)}
        return 400, {"ok": False, "error": "Invalid payload"}

    if action == "increment_view" and method == "POST":
        try:
            payload = json.loads(raw_body or "{}")
            art_id = payload.get("articleId")
            data = load_store()
            if data and art_id:
                new_views = 0
                for a in data.get("articles", []):
                    if a.get("id") == art_id:
                        a["views"] = int(a.get("views", 0) or 0) + 1
                        new_views = a["views"]
                        break
                save_store(data, create_rolling_backup=False)
                return 200, {"ok": True, "articleId": art_id, "views": new_views}
        except Exception as e:
            return 400, {"ok": False, "error": str(e)}
        return 400, {"ok": False, "error": "Article not found"}

    if action == "upload" and method == "POST":
        try:
            payload = json.loads(raw_body or "{}")
            data_uri = payload.get("dataUri", "")
            up_type = payload.get("uploadType", "featured")
            m = re.match(r"^data:image/(\w+);base64,(.+)$", data_uri, re.DOTALL)
            if m:
                ext = m.group(1).lower()
                if ext == "jpeg":
                    ext = "jpg"
                binary = base64.b64decode(m.group(2))
                max_bytes = (300 * 1024) if up_type == "avatar" else (1024 * 1024)
                if len(binary) > max_bytes:
                    return 400, {"ok": False, "error": "File exceeds maximum allowed size"}
                ensure_directories()
                now_ts = int(datetime.datetime.now(datetime.timezone.utc).timestamp())
                digest = hashlib.md5(binary[:256] + str(now_ts).encode()).hexdigest()[:6]
                fname = f"{up_type}_{now_ts}_{digest}.{ext}"
                with open(os.path.join(UPLOADS_DIR, fname), "wb") as f:
                    f.write(binary)
                return 200, {"ok": True, "url": f"uploads/{fname}"}
            return 200, {"ok": True, "url": data_uri}
        except Exception as e:
            return 400, {"ok": False, "error": str(e)}

    if action == "send_editorial_mail" and method == "POST":
        try:
            sub = json.loads(raw_body or "{}")
            to_addr = sub.get("emailedTo") or "editorial@csbnewsusallc.news"
            cats = sub.get("categories") or [sub.get("category", "Analysis")]
            cat_str = ", ".join(cats)
            subj = f"[WEEKLINE Write for Us] {sub.get('headline', 'New Submission')} — by {sub.get('contributorName', 'Contributor')}"
            html = (
                f"<h2>New WEEKLINE Contributor Submission (Waiting for Approval)</h2>"
                f"<p><strong>Contributor Name (Bold):</strong> {sub.get('contributorName', '')}</p>"
                f"<p><strong>Short Biography (Non-Bold):</strong> {sub.get('contributorBio', '')}</p>"
                f"<p><strong>Email:</strong> {sub.get('contributorEmail', '')}</p>"
                f"<p><strong>Categories (Bold):</strong> <strong>{cat_str}</strong></p>"
                f"<p><strong>Headline:</strong> {sub.get('headline', '')}</p>"
                f"<p><strong>Subtitle:</strong> {sub.get('subtitle', '')}</p><hr/>"
                f"{sub.get('body', '')}"
            )
            sent = send_html_email(to_addr, subj, html, reply_to=sub.get("contributorEmail"))
            return 200, {"ok": True, "mailDispatched": sent, "to": to_addr, "engine": "python3"}
        except Exception as e:
            return 400, {"ok": False, "error": str(e)}

    if action == "send_verification_email" and method == "POST":
        try:
            req = json.loads(raw_body or "{}")
            to_addr = req.get("email", "")
            code = req.get("code", "")
            name = req.get("name", "WEEKLINE User")
            if to_addr and code:
                subj = f"Your WEEKLINE Account Verification Code: {code}"
                html = (
                    f"<div style='font-family:Georgia,serif;max-width:520px;padding:24px;border:1px solid #d4cbb8;background:#faf7f0;'>"
                    f"<h2 style='color:#060d3a;margin:0 0 12px;'>WEEKLINE — Email Verification</h2>"
                    f"<p>Hello <strong>{name}</strong>,</p>"
                    f"<p>Use the 6-digit confirmation code below to verify your email address on the WEEKLINE Python CMS:</p>"
                    f"<div style='background:#060d3a;color:#ffffff;font-size:28px;font-weight:700;letter-spacing:0.25em;padding:14px 20px;text-align:center;margin:18px 0;'>{code}</div>"
                    f"<p style='font-size:12px;color:#5a606d;'>A weekly publication by CSB NEWS USA LLC · 166-41 88th Ave, Jamaica, NY 11432</p>"
                    f"</div>"
                )
                sent = send_html_email(to_addr, subj, html)
                return 200, {"ok": True, "mailDispatched": sent, "to": to_addr}
        except Exception as e:
            return 400, {"ok": False, "error": str(e)}
        return 400, {"ok": False, "error": "Missing email or code"}

    if action == "save_transaction" and method == "POST":
        try:
            tx = json.loads(raw_body or "{}")
            data = load_store()
            if data and tx:
                data.setdefault("transactions", []).insert(0, tx)
                save_store(data, create_rolling_backup=True)
                return 200, {"ok": True, "engine": "python3"}
        except Exception as e:
            return 400, {"ok": False, "error": str(e)}
        return 400, {"ok": False}

    if action == "create_backup":
        fname = create_snapshot_backup("cms")
        return 200, {
            "ok": bool(fname),
            "createdBackup": fname,
            "backups": list_available_backups(),
            "engine": "python3",
        }

    if action == "list_backups":
        return 200, {"ok": True, "backups": list_available_backups(), "engine": "python3"}

    if action == "restore_backup" and method == "POST":
        try:
            req = json.loads(raw_body or "{}")
            fname = os.path.basename(req.get("filename", ""))
            fpath = os.path.join(BACKUPS_DIR, fname)
            if fname and os.path.exists(fpath) and fname.endswith(".json"):
                with open(fpath, "r", encoding="utf-8") as f:
                    restored = json.load(f)
                if restored and "articles" in restored and "users" in restored:
                    save_store(restored, create_rolling_backup=False)
                    return 200, {"ok": True, "restoredFrom": fname, "state": restored}
        except Exception as e:
            return 400, {"ok": False, "error": str(e)}
        return 400, {"ok": False, "error": "Backup file not found or invalid"}

    return 400, {"ok": False, "error": f"Unknown action: {action}"}


def application(environ, start_response):
    path = environ.get("PATH_INFO", "/")
    query_str = environ.get("QUERY_STRING", "")
    qs = urllib.parse.parse_qs(query_str)
    method = environ.get("REQUEST_METHOD", "GET").upper()

    if method == "OPTIONS":
        start_response("200 OK", [
            ("Content-Type", "application/json; charset=utf-8"),
            ("Access-Control-Allow-Origin", "*"),
            ("Access-Control-Allow-Methods", "GET, POST, OPTIONS"),
            ("Access-Control-Allow-Headers", "Content-Type"),
        ])
        return [b""]

    if path in ("/api", "/api.py", "/api.php") or "action" in qs:
        action = qs.get("action", ["ping"])[0]
        try:
            length = int(environ.get("CONTENT_LENGTH") or 0)
        except ValueError:
            length = 0
        raw_body = environ["wsgi.input"].read(length).decode("utf-8") if length > 0 else ""
        status_code, resp_obj = handle_api_action(action, method, raw_body)
        status_line = "200 OK" if status_code == 200 else f"{status_code} Bad Request"
        body_bytes = json.dumps(resp_obj, ensure_ascii=False).encode("utf-8")
        start_response(status_line, [
            ("Content-Type", "application/json; charset=utf-8"),
            ("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0"),
            ("Access-Control-Allow-Origin", "*"),
            ("Content-Length", str(len(body_bytes))),
        ])
        return [body_bytes]

    if path in ("/", "/cms", "/admin", "/dashboard"):
        rel_path = "index.html"
    else:
        rel_path = path.lstrip("/")

    safe_path = os.path.normpath(os.path.join(BASE_DIR, rel_path))
    if safe_path.startswith(BASE_DIR) and os.path.isfile(safe_path):
        mime, _ = mimetypes.guess_type(safe_path)
        with open(safe_path, "rb") as f:
            content = f.read()
        start_response("200 OK", [
            ("Content-Type", mime or "application/octet-stream"),
            ("Content-Length", str(len(content))),
        ])
        return [content]

    idx_path = os.path.join(BASE_DIR, "index.html")
    if os.path.isfile(idx_path):
        with open(idx_path, "rb") as f:
            content = f.read()
        start_response("200 OK", [
            ("Content-Type", "text/html; charset=utf-8"),
            ("Content-Length", str(len(content))),
        ])
        return [content]

    start_response("404 Not Found", [("Content-Type", "text/plain")])
    return [b"Not Found"]


def run_cgi():
    qs = urllib.parse.parse_qs(os.environ.get("QUERY_STRING", ""))
    action = qs.get("action", ["ping"])[0]
    method = os.environ.get("REQUEST_METHOD", "GET").upper()
    try:
        length = int(os.environ.get("CONTENT_LENGTH") or 0)
    except ValueError:
        length = 0
    raw_body = sys.stdin.read(length) if length > 0 else ""
    status_code, resp_obj = handle_api_action(action, method, raw_body)
    sys.stdout.write(f"Status: {status_code} OK\r\n")
    sys.stdout.write("Content-Type: application/json; charset=utf-8\r\n")
    sys.stdout.write("Cache-Control: no-store, no-cache, must-revalidate, max-age=0\r\n")
    sys.stdout.write("Access-Control-Allow-Origin: *\r\n\r\n")
    sys.stdout.write(json.dumps(resp_obj, ensure_ascii=False))
    sys.stdout.flush()


if __name__ == "__main__":
    if "GATEWAY_INTERFACE" in os.environ or "REQUEST_METHOD" in os.environ:
        run_cgi()
    else:
        port = 8080
        if len(sys.argv) > 1 and sys.argv[1].isdigit():
            port = int(sys.argv[1])
        data = load_store()
        if data:
            sync_to_sqlite(data)
        print(f"WEEKLINE Python 3 CMS Server listening on http://0.0.0.0:{port}")
        with make_server("0.0.0.0", port, application) as httpd:
            httpd.serve_forever()
